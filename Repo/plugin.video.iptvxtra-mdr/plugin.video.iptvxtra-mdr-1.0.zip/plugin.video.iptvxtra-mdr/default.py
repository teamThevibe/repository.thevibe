# -*- coding: utf-8 -*-
# please visit http://www.iptvxtra.net

import os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,urllib

plugin_handle = int(sys.argv[1])
addonID = 'plugin.video.iptvxtra-mdr'
addon = xbmcaddon.Addon(id = addonID)
addonPath = addon.getAddonInfo('path')
profilePath = addon.getAddonInfo('profile')
icon1 = xbmc.translatePath( os.path.join( addonPath , 'icons/ico1.png' ) )
icon2 = xbmc.translatePath( os.path.join( addonPath , 'icons/ico2.png' ) )
icon3 = xbmc.translatePath( os.path.join( addonPath , 'icons/ico3.png' ) )
icon4 = xbmc.translatePath( os.path.join( addonPath , 'icons/ico4.png' ) )
icon5 = xbmc.translatePath( os.path.join( addonPath , 'icons/ico5.png' ) )

def add_video(url, infolabels, img=''):
    url = url + '|X-Forwarded-For=93.221.77.124'
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

link1 = 'rtmp://mdr-tv-sachsenlivefs.fplive.net:1935/mdr-tv-sachsenlive-live playpath=stream_livetvmdrsachsen_de_1728 swfUrl=http://www.mdr.de/resources/flash/mdr_av_player.swf live=1 pageUrl=http://www.mdr.de/mediathek/livestreams/fernsehen/index.html'
link2 = 'rtmp://mdr-tv-sachsenanhaltlivefs.fplive.net:1935/mdr-tv-sachsenanhaltlive-live playpath=stream_livetvmdrsachsenanhalt_de_1728 swfUrl=http://www.mdr.de/resources/flash/mdr_av_player.swf live=1 pageUrl=http://www.mdr.de/mediathek/livestreams/fernsehen/livestream-sachsen-anhalt100.html'
link3 = 'rtmp://mdr-tv-thueringenlivefs.fplive.net:1935/mdr-tv-thueringenlive-live playpath=stream_livetvmdrthueringen_de_1728 swfUrl=http://www.mdr.de/resources/flash/mdr_av_player.swf live=1 pageUrl=http://www.mdr.de/mediathek/livestreams/fernsehen/livestream-thueringen102.html'
link4 = 'rtmp://mdr-tv-event1livefs.fplive.net:1935/mdr-tv-event1live-live playpath=stream_livetvmdrevent1_de_1728 swfUrl=http://www.mdr.de/resources/flash/mdr_av_player.swf live=1 pageUrl=http://www.mdr.de/mediathek/livestreams/fernsehen/livestream-mdr-plus100.html'
link5 = 'rtmp://mdr-tv-event2livefs.fplive.net:1935/mdr-tv-event2live-live playpath=stream_livetvmdrevent2_de_1728 swfUrl=http://www.mdr.de/resources/flash/mdr_av_player.swf live=1 pageUrl=http://www.mdr.de/mediathek/livestreams/fernsehen/livestream-mdr-plus102.html'

add_video('http://mdr_sachsen_hls-lh.akamaihd.net/i/livetvmdrsachsen_de@106902/master.m3u8',{ 'title': 'mdr Sachsen'}, icon1)  
add_video('http://mdr_sa_hls-lh.akamaihd.net/i/livetvmdrsachsenanhalt_de@106901/master.m3u8',{ 'title': 'mdr Sachsen - Anhalt'}, icon2)
add_video('http://mdr_th_hls-lh.akamaihd.net/i/livetvmdrthueringen_de@106903/master.m3u8',{ 'title': 'mdr Thueringen'}, icon3)
#add_video(link1,{ 'title': 'mdr Sachsen'}, icon1)
#add_video(link2,{ 'title': 'mdr Sachsen - Anhalt'}, icon2)
#add_video(link3,{ 'title': 'mdr Thueringen'}, icon3)
add_video(link4,{ 'title': 'mdr +'}, icon4)
add_video(link5,{ 'title': 'mdr + II'}, icon5)  




xbmcplugin.endOfDirectory(plugin_handle)
xbmc.executebuiltin("Container.SetViewMode(500)")
