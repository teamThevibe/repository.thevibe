# -*- coding: cp1254 -*-
# for more info please visit http://www.iptvxtra.net

import base64
import cookielib,sys
import urllib2,urllib,re,os

from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
import xbmcplugin,xbmcgui,xbmc,xbmcaddon 

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
Addon = xbmcaddon.Addon('plugin.video.iptvxtra-thpsi')
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
addonsettings = xbmcaddon.Addon(id='plugin.video.iptvxtra-thpsi')

__language__ = addonsettings.getLocalizedString
home = addonsettings.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
 
def main():
    bolumList=[]
    std_url = "http://www.iptvxtra.net/"
    file = "th-psi-streams.xml"
    link=get_url(std_url,file)

    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    if len(soup('channels')) > 0 :
        channels = soup('channel')
        for channel in channels:
            videoTitle = channel('name')[0].string
            bolumList.append(videoTitle)

        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()    
        
        dialog = xbmcgui.Dialog()
        ret = dialog.select(__language__(30008),bolumList)
        for i, name in enumerate(bolumList):
            if ret == i:
                channel = soup.find('channel', attrs={'name' : bolumList[i]})

                items = channel.findAll("item")
                for item in items:
                    try:
                        videoTitle=item.title.string
                    except:
                        pass
                    try:
                        url=item.link.string
                        
                    except:
                        pass
                    try:
                        thumbnail=item.thumbnail.string
                        
                    except:
                        thumbnail="https://www.google.de/logos/classicplus.png"
                    print videoTitle,url,thumbnail
                    listitem = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
                    listitem.setInfo('video', {'videoTitle': videoTitle } )
                    playList.add(url,listitem=listitem)
                    addLink(videoTitle,url,thumbnail)
        
            else:
                print ("secim iptal edildi",name)
                pass
    else:
        items = soup.findAll("item")
        for item in items:
            try:
                videoTitle=item.title.string
                
            except:
                pass
            try:
                url=item.link.string
                
            except:
                pass
            try:
                thumbnail=item.thumbnail.string
                
            except:
                thumbnail="https://www.google.de/logos/classicplus.png"
            listitem = xbmcgui.ListItem(videoTitle, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
            listitem.setInfo('video', {'videoTitle': videoTitle } )
            playList.add(url,listitem=listitem)
            addLink(videoTitle,url,thumbnail)

    xbmc.executebuiltin("Container.SetViewMode(500)")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_url(std_url,file):
        url = std_url + "xbmc/xml/" + file
        paman = urllib2.HTTPPasswordMgrWithDefaultRealm()
        paman.add_password(None, url, "xbmcuser", "user")
        authhandler = urllib2.HTTPBasicAuthHandler(paman)
        opener = urllib2.build_opener(authhandler)
        urllib2.install_opener(opener)
        response = urllib2.urlopen(url)
        link=response.read()
        response.close()
        return link


main()

