# -*- coding: utf-8 -*-

'''
Created on 23/12/2011
channel 5
@author: shai
'''

__base_url__ = 'http://www.sport5.co.il'
__NAME__ = 'branded'

import urllib,urllib2,re,os,sys
import xbmcplugin,xbmcgui,xbmcaddon
from common import *

__settings__ = xbmcaddon.Addon(id='plugin.video.sport5.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

class manager_branded:
 
    def episodes(self, url):
        # receive the block of shows that are a part of this genre
        page = getData(url)
        # print page
        blocks = re.compile('<td class="med_vid">(.*?)</td>').findall(page)
        for block in blocks:
            print 'BLOCK ' + block
            parsed = re.compile('<img class="lobby_video_picture" src="(.*?)".*?\(\'(.*?)\'').findall(block)
            for img, href in parsed:
                iconImage = img
                vidurl = href
            parsed = re.compile('class="lobby_video_title">(.*?)<.*?<P>(.*?)<').findall(block)
            if len(parsed) == 0:
                # try without the <P>
                parsed = re.compile('class="lobby_video_title">(.*?)<.*?">(.*?)<').findall(block)
            for t, d in parsed:
                title = t.replace('&quot;', '"').replace('&nbsp;', ' ')
                details = d.replace('&quot;', '"').replace('&nbsp;', ' ')
            parsed = None
            addVideoLink(title, vidurl, 2, __base_url__ + iconImage, details)
        
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(503)")# see the image view