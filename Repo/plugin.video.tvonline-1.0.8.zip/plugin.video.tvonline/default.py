import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
from t0mm0.common.net import Net

net=Net()
BASE_URL='http://tvonline.cc'
icon = 'http://a0.twimg.com/profile_images/1880386140/logo-square.jpg'
PLUGIN='plugin.video.tvonline'
ADDON = xbmcaddon.Addon(id=PLUGIN)
datapath = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('profile')))
cookie_path = os.path.join(datapath, 'cookies')
user    =ADDON.getSetting('user')
password =ADDON.getSetting('pass')

from metahandler import metahandlers
 
grab = metahandlers.MetaData()

        
def Reg_search(name):
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter '+str(name))
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            if search_entered == None:
                return False          
        return search_entered


def Sign_In():
        username=Reg_search('Username')
        password=Reg_search('Password')
        ADDON.setSetting('user',username)
        ADDON.setSetting('pass',password) 
        
        
def Register():
        username=Reg_search('Username')
        email=Reg_search('Email')
        password=Reg_search('Password')
        ADDON.setSetting('user',username)
        ADDON.setSetting('pass',password)
        loginurl = 'http://tvonline.cc/reg.php'
        html = net.http_GET(loginurl).content
        match=re.compile('name="Token(.+?)" value="(.+?)"').findall(html)
        data     = {'_method':'POST','Token'+match[0][0]:match[0][1],'UserUsername':username,'email':email,'subscriptionsPass':password,'subscriptionsPassword2':password}
        headers  = {'Host':'tvonline.cc',
                                            'Origin':'http://tvonline.cc',
                                            'Referer':'http://tvonline.cc/reg.php'}
                                            
        html = net.http_POST(loginurl, data, headers)


if user=='':
        dialog = xbmcgui.Dialog()
        if dialog.yesno("Tv Online",  'Registration is Free','Do you Wish To Register', "Or Sign In",'Register','Sign In'):
            Sign_In()
        else:
            Register()
        



loginurl = 'http://tvonline.cc/reg.php'
html = net.http_GET(loginurl).content
match=re.compile('name="Token(.+?)" value="(.+?)"').findall(html)

data     = {'subscriptionsPass': password,
                                    'UserUsername': user,
                                    'Token'+match[0][0]:'login'}
headers  = {'Host':'tvonline.cc',
                                    'Origin':'http://tvonline.cc',
                                    'Referer':'http://tvonline.cc/login.php',
                                            'X-Requested-With':'XMLHttpRequest'}
html = net.http_POST(loginurl, data, headers)
cookie_jar = os.path.join(cookie_path, "tvonline.lwp")
if os.path.exists(cookie_path) == False:
        os.makedirs(cookie_path)
net.save_cookies(cookie_jar)


icon = xbmc.translatePath(os.path.join('special://home/addons/'+PLUGIN, 'icon.png'))


def CATEGORIES():
        addDir('Main Page',BASE_URL,1,icon,'')
        addDir('Search','url',3,icon,'')
        addDir('A to Z',BASE_URL+'/tv/a.htm',1,icon,'')
        setView('movies', 'main') 
       
        
                                                          
def Main(name,url):
        dialog=xbmcgui.Dialog()
        net.set_cookies(cookie_jar)
        html = net.http_GET(url).content
        url_select=[]
        name_select=[]
        if 'A to Z' in name:
            split1 = html.split('<div class="tv_aes_l">')[1]
            split2 = split1.split('<br />')[0]
            match=re.compile('<a href="(.+?)">(.+?)</a>').findall (split2)
            for url, name in match:
                name_select.append(name.replace('&nbsp;',''))
                url_select.append(BASE_URL+url)
            new_url=url_select[xbmcgui.Dialog().select('Please Choose Catergory', name_select)]
            print new_url
            new_html = net.http_GET(new_url).content.encode('utf-8')
            print new_html
            match=re.compile(' "><img src="(.+?)".+?</a><p><a href="(.+?)" title=".+?">(.+?)</a>').findall (new_html)
            for iconimage,url, name in match:
                if ADDON.getSetting('meta')=='true':
                    infoLabels=GRABMETA(name,'tvshow',year=None,season=None,episode=None,imdb=None)
                    if infoLabels['title']=='':
                        name=name
                    else:
                        name=infoLabels['title']
                    if infoLabels['cover_url']=='':
                        iconimage=icon
                    else:
                        iconimage=infoLabels['cover_url']
                else:
                    infoLabels=None
                    iconimage=icon
                addDir(name,BASE_URL+url,2,iconimage,'',name,'',infoLabels=infoLabels)
        else:
            match=re.compile('<li><a href="(.+?)" title=".+?">(.+?)</a></li>').findall (html)
            for url, name in match:
                if ADDON.getSetting('meta')=='true':
                    infoLabels=GRABMETA(name,'tvshow',year=None,season=None,episode=None,imdb=None)
                    if infoLabels['title']=='':
                        name=name
                    else:
                        name=infoLabels['title']
                    if infoLabels['cover_url']=='':
                        iconimage=icon
                    else:
                        iconimage=infoLabels['cover_url']
                else:
                    infoLabels=None
                    iconimage=icon
                addDir(name,BASE_URL+url,2,iconimage,'',name,'',infoLabels=infoLabels)
        setView('movies', 'show') 
        
        
def Season(name,url,iconimage):
        showname=name
        dialog=xbmcgui.Dialog()
        net.set_cookies(cookie_jar)
        html = net.http_GET(url).content
        match=re.compile('<p><strong>(.+?)</strong></p>').findall (html)
        season_select=[]
        for season in match:
            season_select.append(season)
        split=season_select[xbmcgui.Dialog().select('Please Choose Season', season_select)]
        link = html.split(split)[1]
        link = link.split('</ul>')[0]
        match=re.compile('<li>(.+?)<a href="(.+?)">(.+?)</a></li>').findall (link)
        for first,url,second in match:
            if ADDON.getSetting('meta')=='true':
                season=first.split(',')[0]
                episode=first.split('Ep')[1]
                episode=episode.replace(':','')
                if episode.startswith('0'):
                    episode=episode.replace('0','')
                    
                infoLabels=GRABMETA(showname,'episode',year=None,season=season.replace('S',''),episode=episode)
                print infoLabels
                if infoLabels['title']=='':
                    name=first+' '+second
                else:
                    name=infoLabels['title']
                if infoLabels['cover_url']=='':
                    iconimage=iconimage
                else:
                    iconimage=infoLabels['cover_url']
            else:
                infoLabels=None
                name=first+' '+second
                iconimage=icon
            addDir(name,BASE_URL+url,200,iconimage,'',showname,'',infoLabels=infoLabels)
        setView('movies', 'episode') 
        
        
        
        
def Search():
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search Tv Online')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText()    
        html = net.http_POST('http://tvonline.cc/searchlist.php', {'keyword' : search_entered}).content.encode('utf-8')
        match=re.compile(' "><img src="(.+?)".+?</a><p><a href="(.+?)" title=".+?">(.+?)</a>').findall (html)
        for iconimage,url, name in match:
            if ADDON.getSetting('meta')=='true':
                infoLabels=GRABMETA(name,'tvshow',year=None,season=None,episode=None,imdb=None)
                if infoLabels['title']=='':
                    name=name
                else:
                    name=infoLabels['title']
                if infoLabels['cover_url']=='':
                    iconimage=icon
                else:
                    iconimage=infoLabels['cover_url']
            else:
                infoLabels=None
            addDir(name,BASE_URL+url,2,iconimage,'',name,'',infoLabels=infoLabels)
          
            
                     
def PLAY_STREAM(name,url,iconimage):
    net.set_cookies(cookie_jar)
    html = net.http_GET(url).content
    match=re.compile('"flow-(.+?)"',re.DOTALL).findall(html)
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    liz.setProperty("IsPlayable","true")
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    pl.add(match[0], liz)
    xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)        
        
        
 
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
    
def GRABMETA(name,types=None,year=None,season=None,episode=None,imdb=None,episode_title=None):
        if 'tvshow' in types:
            meta = grab.get_meta('tvshow',name,'','','')
        if 'episode' in types:
            meta = grab.get_episode_meta(name, '', season, episode)
        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'fanart': meta['backdrop_url'],'Episode': meta['episode'],'Aired': meta['premiered']}
        
        return infoLabels    
    
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
        
        
        

def addDir(name,url,mode,iconimage,description,showname='',season='',infoLabels=None):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&showname="+urllib.quote_plus(showname)+"&season="+urllib.quote_plus(season)
        ok=True
        if ADDON.getSetting('meta')=='true':
            try:
                liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels=infoLabels)
                if ADDON.getSetting('fanart')=='true':
                    liz.setProperty( "Fanart_Image", infoLabels['fanart'] )
            except:
                liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name })
        else:
            liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name })
        if mode==200:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
showname  = None
season  = None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        showname=urllib.unquote_plus(params["showname"])
except:
        pass
try:        
        season=urllib.unquote_plus(params["season"])
except:
        pass
        

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

   
        
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        Main(name,url)
        
elif mode==2:
        Season(name,url,iconimage)
        
elif mode==3:
        Search()
        
        
elif mode==200:
        PLAY_STREAM(name,url,iconimage)
       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
