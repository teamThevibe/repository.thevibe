from webutils import *
import re


base_url='http://www.nflhd.com'




def get_games(site):
	
	soup=get_soup(site)
	items=soup.findAll('div',{'class':'thumb'})
	out=[]
	for item in items:
		url=item.find('a')['href']
		title=item.find('a')['title']
		thumb=item.find('img')['src']

		out+=[[title,url,thumb]]
	try:
		next_page=soup.find('div',{'class':'wp-pagenavi'}).find('a',{'class':'nextpostslink'})['href']
	except:
		next_page='0'
	return out,next_page


def get_teams():
 	soup=get_soup(base_url)
 	tag=soup.findAll('center')[0]
 	a=tag.findAll('a')
 	team_links=[]
 	for i in range(len(a)):
 		link=a[i]['href']
 		img=a[i].findAll('img')[0]['src']
 		name=link.replace('http://nbahd.com/tag/','').replace('/','')
 		name=name.replace('-',' ').replace('http:nflhd.comteams','').title()
 		if 'http://' not in img:
 			img=base_url+img
 		team_links+=[[name,link,img]]
 	return team_links

def get_game_options(url):
	soup=get_soup(url)
	tags=soup.find('div',{'class':'entry-content rich-content'}).findAll('p')
	tags.pop(0)
	tags.pop(-1)
	options=[]
	for tag in tags:
		title=re.compile('src="http://nflhd.com/wp-content/uploads/(.+?).png"').findall(str(tag))[0].title()
		img=tag.find('img')['src']
		tmp=tag.findAll('a')
		urls=[]

		for t in tmp:
			urls+=[t['href']]

		options+=[(title,img,urls)]
	return options
def get_title(url):
	soup=get_soup(url)
	return soup.find('div',{'class':'entry-content rich-content'}).findAll('p')[0].getText().replace('Watch ','')
def get_urls(url,option):
    soup=get_soup(url)
    tags=soup.find('div',{'class':'entry-content rich-content'}).findAll('p')
    tags.pop(0)
    tags.pop(-1)
    print(tags)
    tag=tags[option]
    
    tmp=tag.findAll('a')
    urls=[]

    for t in tmp:
        urls+=[t['href']]

    return urls

def get_link_hd(url):
    html=read_url(url)
    soup=bs(html)
    link=soup.find('iframe',{'frameborder':'0'})['src']
    return link
