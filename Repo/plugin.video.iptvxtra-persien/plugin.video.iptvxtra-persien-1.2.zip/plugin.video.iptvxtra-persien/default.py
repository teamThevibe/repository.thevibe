# -*- coding: cp1254 -*-
# for more info please visit http://www.iptvxtra.net

import base64
import cookielib,sys
import urllib2,urllib,re,os

from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
import resources.lib.requests as requests
import xbmcplugin,xbmcgui,xbmc,xbmcaddon 

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
addonID = 'plugin.video.iptvxtra-persien'
addon = xbmcaddon.Addon(id = addonID)
addonPath = addon.getAddonInfo('path')
profilePath = addon.getAddonInfo('profile')
__settings__ = addon
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

 
def main():
    bolumList=[]
    repox = repo()
    std_url = "http://srv1.iptvxtra.net/"
    file = "persien-streams.xml"

    link=get_url(std_url,file)

    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try: videoTitle = item.title.string
            except: pass
            try: url = item.link.string
            except: pass
            try: thumbnail = item.thumbnail.string                
            except: thumbnail = icon
            if thumbnail == 'none': thumbnail = icon
	
            addLink(videoTitle,url,thumbnail)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

    try:
        if not os.path.isfile(xbmc.translatePath("special://temp/0_persien.fi")):
            open(xbmc.translatePath("special://temp/0_persien.fi"), "a").close()
            xbmc.executebuiltin("Container.SetViewMode(500)") 
    except: pass

    sys.exit(0)
    
def addLink(name,url,iconimage):
        ok=True
        if 'giniko' in url:
            url = ginico(url)
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", iconimage )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def get_url(std_url,file):
        url = std_url + "xbmc/xml/" + file
        response = urllib2.urlopen(url)
        link=response.read()
        response.close()
        return link

def repo():
    repos = xbmc.translatePath("special://home/addons/repository.iptvxtra")
    if not os.path.isdir(repos):
        xbmc.executebuiltin('XBMC.Notification(IPTVxtra Repo missing , the Repo of IPTVxtra is not installed - the addon can not be executed ,15000,'+icon+')')
        sys.exit(0)
    return 'ok'

def ginico(url):
    x = url.partition('---')
    url = x[0]
    id = x[2].replace('xxx','')
    r = requests.get("http://giniko.com/watch.php?id=" + id)
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=37")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    r = requests.get("http://giniko.com/watch.php?id=220")
    if r.text.find('m3u8?'):
        s = r.text.partition('m3u8?')
        s = s[2].partition('"')
        if len(s[0]) > 120 and len(s[0]) < 134:
            s = url + '?' + s[0]
            return s
    else: return url


main()

