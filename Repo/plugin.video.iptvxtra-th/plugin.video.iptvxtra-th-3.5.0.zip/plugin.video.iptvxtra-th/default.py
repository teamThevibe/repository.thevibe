# thai television plugin written by IPTVxtra
# -*- coding: utf-8 -*-

# for more info please visit http://www.iptvxtra.net

import sys,xbmc,xbmcaddon
if 'extrafanart' in sys.argv[2]: sys.exit(0)

mode = 'False'

if 'chainserver'in sys.argv[2]:
    serverhost = xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').getSetting("servhost")
    if   serverhost == '0': xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').setSetting('servhost','1')
    elif serverhost == '1': xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').setSetting('servhost','2')
    elif serverhost == '2': xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').setSetting('servhost','3')
    elif serverhost == '3': xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').setSetting('servhost','4')
    elif serverhost == '4': xbmcaddon.Addon(id = 'plugin.video.iptvxtra-th').setSetting('servhost','0')
    xbmc.executebuiltin('Container.Refresh')
    sys.exit(0)

if 'zapping'in sys.argv[2]:
    xbmc.Player().stop()      
    url = sys.argv[2].replace('plugin://plugin.video.iptvxtra-th/?zapping','')
    url = sys.argv[2].replace('plugin://plugin.video.iptvxtra-th/zapping','')
    pfadx = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-th/resources/lib/zapping.py")
    xbmc.executebuiltin('RunScript('+pfadx+',url='+url+')')
    sys.exit(0)

if '?'in sys.argv[2]:
    mode = sys.argv[2].replace('?','')
    if 'preview' in mode:
        title_ch = xbmc.getInfoLabel('Listitem.Label')
        icon_ch = xbmc.getInfoLabel('ListItem.Icon')
        xbmc.executebuiltin('XBMC.Notification('+title_ch+' , a moment the channel is loaded ,20000,'+icon_ch+')')
    if 'zapsidemenu'in mode:
        from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
        import pickle

else:
    from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP
    import base64,hashlib


import urllib2,urllib,re,os,time,random,pickle
import xbmcplugin,xbmcgui
import resources.lib.requests as requests
from datetime import date,datetime,timedelta
 
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
Addon = xbmcaddon.Addon('plugin.video.iptvxtra-th')
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
__settings__ = xbmcaddon.Addon(id="plugin.video.iptvxtra-th")
user = __settings__.getSetting("login").strip()
pwd = __settings__.getSetting("password").strip()

if __settings__.getSetting("firstrunx") <> "1" or not user or user == "xbmcuser":
        __settings__.setSetting("firstrunx", "1")
        Addon.openSettings()
        sys.exit(0)

servhost = __settings__.getSetting("servhost")
servchange = __settings__.getSetting("servchange")
temp = xbmc.translatePath("special://temp/") + '040264-180'+servhost+'.fi' #-220
viewfile = xbmc.translatePath("special://temp/0th.fi")
xmltv2 = xbmc.translatePath("special://temp/temp/xmltv_th_2.xmx")
setThai = __settings__.getSetting("setThai")
setHeader = __settings__.getSetting("setHeader")
setBack = __settings__.getSetting("setBack")
views = __settings__.getSetting("views")
epg_on = __settings__.getSetting("epg_on")
epg_now = __settings__.getSetting("epg_title")
epg_dl = __settings__.getSetting("epg_dl")
epg_info = __settings__.getSetting("epg_info")
timeshift = __settings__.getSetting("timeshift")
home = __settings__.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
net = xbmc.translatePath(home+"/resources/lib/net.png")
thumbs = xbmc.translatePath("special://temp/temp/iptvxtra_thumbs/")
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
exitcode = "0"
MainList=[]
xbmc.executebuiltin("Skin.SetString(iptvxtra_addon_aktuell, plugin://plugin.video.iptvxtra-th)") 
xbmc.executebuiltin("Skin.Reset(iptvxtra_replay_ok)")
try: os.makedirs(xbmc.translatePath("special://temp/temp/iptvxtra_thumbs/"))
except: pass

if __settings__.getSetting("timeshift0") == 'true' and epg_on  == 'true':
    try:
        import resources.lib.USTimeZone as USTimeZone
        LocalTimezone = USTimeZone.LocalTimezone()
        Europe = USTimeZone.GMT1()
        if '+01:00' in str(datetime.now(Europe)): euro = 1
        elif '+02:00' in str(datetime.now(Europe)): euro = 2
        thai = 7
        thaix = str(datetime.now(LocalTimezone))
        thaix = thaix.partition('.')
        if '+' in thaix[2] :  
            thaix = thaix[2].partition('+')
            thaix = thaix[2].partition(':')
            timeshift = str(int(thaix[0]) - thai)
        elif '-' in thaix[2] :
            thaix = thaix[2].partition('-')
            thaix = thaix[2].partition(':')
            timeshift = str(int('-'+thaix[0]) - thai)
        __settings__.setSetting("timeshift", timeshift)
    except:
        timeshift = __settings__.getSetting('timeshift')
        __settings__.setSetting('timeshift0','false')
        xbmc.executebuiltin('XBMC.Notification(autom. Zeitzonen Fehler , die Zeitzonenerkennung wurde auf manuell geschaltet ,8000,'+net+')')
else:
    timeshift= __settings__.getSetting("timeshift")




def main():

    mode = 'true'
    exitcode = "0"
    link=get_url()
    xmltv_dl()
    iptvepg = xmltv()

    if servchange == '0': positionServ()
   
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:	
                    try:
                        videoTitle = item.title.string
                        vTitle = videoTitle
                    except: pass

                    try:
                        name2 = ''
                        description = ''
                        xmlepg = ''
                        if epg_on == "true":
                            if not item.xmlepg.string or item.xmlepg.string == '': item.xmlepg.string = 'abcdefgh'
                            xmlepg=item.xmlepg.string.strip() 
                            zx = 0
                            for text in iptvepg:
                                text0 = text[0].strip() 
                                if xmlepg == text0 and int(text[4]) > (int(time.time())+(int(thai)*3600)):
                                    laenge = len(text[5]) + len(text[6]) + 3
                                    if name2 == '':
                                        name2 = text[5]
                                    if laenge < 60:
                                        description = description + timestamp(text[8]) +'  '+ text[5]
                                        if text[6] != 'no Info': description = description + ' - ' + text[6]
                                        description = description + '\n'
                                    else:
                                        description = description + timestamp(text[8]) +'  '+ text[5]
                                        if text[6] != 'no Info': 
                                            if len(text[6]) > 50 : 
                                                kuerz = len(text[6]) - 50
                                                text[6] = text[6][:-kuerz] + ' ...'
                                            description = description + '\n'+'             '+ text[6]
                                        description = description + '\n'
                                    if zx == 0 and epg_now == "true":
                                        if ' - ' in text[5]:
                                            text5 = text[5].partition(" - ")
                                            videoTitle = vTitle +' - '+ text5[0]
                                        else: 
                                            videoTitle = vTitle +' - '+ text[5]
                                    zx += 1
                                    if zx == int(epg_info):
                                        break
                    except: pass
	
                    try:
                        if epg_now == "true": name2 = ''
                    except: pass

                    try:
                        url=item.link.string
                        url= 'plugin://plugin.video.iptvxtra-th/?preview'+url
                    except: pass

                    try:
                        thumbnail= thumbs + os.path.basename(item.thumbnail.string)
                        if not os.path.isfile(thumbnail) or __settings__.getSetting("thumbupd") == 'true':
                            xbmc.executebuiltin('XBMC.Notification(Channel-Logos are updated, missing Logos are loaded,2000,'+net+')')
                            urllib.urlretrieve (item.thumbnail.string, thumbnail)
                    except: thumbnail=""

                    addLink(videoTitle,name2,url,thumbnail,description)

    write_listfile(xbmc.translatePath('special://temp/040264-1002.fi'),MainList)

    __settings__.setSetting("thumbupd", 'false')
    if servchange == '1': positionServ()

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

    try:
        if int(views) > 0 and not os.path.isfile(viewfile):
            open(viewfile, "a").close()
            xbmc.executebuiltin("Container.SetViewMode("+views+")") 
    except: pass
	
    sys.exit(0)

def positionServ():
    servtext = '[COLOR red]\nhere you can choose different servers\nthe server location is in the name\nfor example ...  Server 1 - Thailand\n\nnot always the next geographically is also the best[/COLOR]'
    if   servhost == '0': addDir('[COLOR orange]current Server 1 - Thai1 Thailand[/COLOR]', 'plugin://plugin.video.iptvxtra-th/?chainserver', icon,servtext)
    elif servhost == '1': addDir('[COLOR orange]current Server 2 - Thai3 Thailand[/COLOR]', 'plugin://plugin.video.iptvxtra-th/?chainserver', icon,servtext)
    elif servhost == '2': addDir('[COLOR orange]current Server 3 - Thai4 USA[/COLOR]', 'plugin://plugin.video.iptvxtra-th/?chainserver', icon,servtext)
    elif servhost == '3': addDir('[COLOR orange]current Server 4 - Thai4 Asia[/COLOR]', 'plugin://plugin.video.iptvxtra-th/?chainserver', icon,servtext)
    elif servhost == '4': addDir('[COLOR orange]current Server 4 - Thai4 Europe[/COLOR]', 'plugin://plugin.video.iptvxtra-th/?chainserver', icon,servtext)

def xmltv_dl():
    if epg_dl == '0': dltime = 3600*18
    elif epg_dl == '2': dltime = 3600*22
    elif epg_dl == '3': dltime = 3600*24
    else: dltime = 3600*20
    if not os.path.isfile(xmltv2) or os.stat(xmltv2)[8] < (time.time() - dltime) or os.path.getsize(xmltv2) < 1800000:
        xbmc.executebuiltin('XBMC.Notification(EPG Information !, the new EPG is loaded from server ,5000,'+net+')')
        urllib.urlretrieve ('http://srv1.iptvxtra.net/xmltv/xmltv_th_2.xmx', xmltv2)
    return

def xmltv():
    iptvepg=[]
    if os.path.isfile(xmltv2):
        iptvepg = read_listfile(xmltv2)
        return iptvepg
    else:
        iptvepg.append([' ','0','0','0','0',' ',' ',' ','0'])
        iptvepg.append([' ','0','0','0','0',' ',' ',' ','0'])
        write_listfile(xbmc.translatePath(xmltv2),iptvepg)
        return iptvepg

def write_listfile(datei,liste):
    output = open(datei, 'w')
    pickle.dump(liste, output)
    output.close()

def read_listfile(datei):
    try:
        f = open(datei)
        liste = pickle.load(f)
        return liste
    except: 
        xbmc.executebuiltin('XBMC.Notification(EPG Error!,can not decode the EPG file ,5000,'+net+')')

def addLink(name,name2,url,iconimage,description):
        ok=True
        timex = timenow("0000")   
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Label": name,"Title": name2, "Plot": description, "Genre": "Live Stream - EPG von " + timex[0], "Year": time.strftime("%Y") } )
        if setBack == "true":
            liz.setProperty( "Fanart_Image", iconimage )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,iconimage,desc):
    desc = desc.decode("iso-8859-1")
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Label": name,"Title": "", "Plot": desc } )
    liz.setProperty( "Fanart_Image", icon )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def get_url():
    file = "none.xml"
    if os.path.isfile(temp):
        if os.stat(temp)[8] < time.time() - 18000:
            os.remove(temp)
        else:
            link = ''
            fobj = open(temp, "r") 
            for line in fobj: 
                line = (line.decode("hex"))
                link += line.strip() 
            fobj.close()
            return link

    try:
        wert = hashlib.md5('#user='+user+'pass='+pwd).hexdigest()
        payload = {'loc': wert,'h':'0','sh':servhost,'la':'TH'}
        r = requests.get("http://www.iptvxtra.net/xbmc/_form/rsx.php", params=payload)
        urln = r.text
        if 'not allowed' in urln:
            xbmc.executebuiltin('XBMC.Notification(Login Fehler , der Zugang über einen Proxy oder Tor-IPs ist nicht erlaubt ,25000,'+net+')')
            sys.exit(0)
        respx = [x for x in urln.split("###")]
        __settings__.setSetting("data2", respx[2])
        __settings__.setSetting("data3", respx[3])
        __settings__.setSetting("data4", respx[4])
        xbmc.executebuiltin("Skin.SetString(iptvxtra_replaydata_aktuell, Replay active until "+respx[4]+")")
        url = respx[1]
        url = url.replace(' ','')

        if url == 'none.xml':
            xbmc.executebuiltin('XBMC.Notification(Netzwerkfehler HTTP-401 , Passwort oder User ist sehr wahrscheinlich verkehrt ,25000,'+net+')')
            sys.exit(0)
        if url == 'lockland.xml':
            xbmc.executebuiltin('XBMC.Notification(Login Fehler , dieses Addom ist in deinem Land nicht verfügbar ,25000,'+net+')')
            sys.exit(0)
        if url == 'proxy.xml':
            xbmc.executebuiltin('XBMC.Notification(Login Fehler , der Zugang über einen Proxy oder Tor-IPs ist nicht erlaubt ,25000,'+net+')')
            sys.exit(0)
        http = requests.packages.urllib3.PoolManager()
        headers = requests.packages.urllib3.util.make_headers(keep_alive= True, user_agent= 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0', basic_auth=None)
        link = http.request('GET', url, headers=headers)
       
        if '<epg>' in link.data:
            f = open(temp, "w")	
            hurl = link.data.encode("hex")
            f.write(hurl)
            f.close()
            return link.data
        elif '401 Authorization Required' in link.data:
            print '                                                                                    [IPTVxtra ERROR - 401]'
            exitcode = "401"
            xbmc.executebuiltin('XBMC.Notification(Network Error HTTP-401 , password or user is wrong ,10000,'+net+')')
            sys.exit(0)
        elif '404 Not Found' in link.data:
            print '                                                                                    [IPTVxtra ERROR - 404]'
            exitcode = "404"
            xbmc.executebuiltin('XBMC.Notification(Network Error HTTP-404 , IPTVxtra.net Server not found ,10000,'+net+')')
            sys.exit(0)
        elif '403 Forbidden' in link.data:
            print '                                                                                    [IPTVxtra ERROR - 403]'
            exitcode = "403"
            xbmc.executebuiltin('XBMC.Notification(Network Error HTTP-403 , Restricted Access to IPTVxtra.net ,10000,'+net+')')
            sys.exit(0)
        elif 'Internal Server Error' in link.data:
            print '                                                                                    [IPTVxtra ERROR - 500]'
            exitcode = "500"
            xbmc.executebuiltin('XBMC.Notification(Network Error HTTP-500 , Internal Server Error in IPTVxtra.net ,10000,'+net+')')
            sys.exit(0)
        else:
            print '                                                                                    [IPTVxtra ERROR - Allgemein]'
            exitcode = "501"
            xbmc.executebuiltin('XBMC.Notification(general Network Error , check your network or router configuration - take the router and cable modem for 10 min from the mains,20000,'+net+')')
            sys.exit(0)

    except requests.packages.urllib3.exceptions.MaxRetryError, e:
            print '                                                                                    [IPTVxtra ERROR - die angeforderter URL ist nicht erreichbar]'
            exitcode = "501"
            xbmc.executebuiltin('XBMC.Notification(general Network Error , check your network or router configuration - take the router and cable modem for 10 min from the mains,20000,'+net+')')
            sys.exit(0)


def timestamp(zeit):
    zeita = zeit.partition(":")
    zeitb = int(zeita[0]) + int(timeshift)
    if zeitb > 24:
        zeitb -= 24
    elif zeitb < 0:
        zeitb += 24       
    zeitc = str(zeitb)
    if zeitc == '24':
        zeitc = '00'
    if zeitb > 0 and zeitb < 10:
        zeitc = '0' + zeitc
    zeit = zeitc + '.' + zeita[2]  
    zeit = zeit.strip()
    return (zeit)

def timenow(timex):
    strloc_min = str(time.localtime()[4])
    if len(strloc_min) == 1:
        strloc_min = '0' + strloc_min
    strloc_std = str(time.localtime()[3])   
    if len(strloc_std) == 1:
        strloc_std = '0' + strloc_std
    strloc_day = str(time.localtime()[2])
    if len(strloc_day) == 1:
        strloc_day = '0' + strloc_day
    strloc_mon = str(time.localtime()[1])
    if len(strloc_mon) == 1:
        strloc_mon = '0' + strloc_mon

    timex = timex.partition(':')
    timea = str(time.localtime()[3]) + ":" + strloc_min
    timeb = str(time.localtime()[3]) + strloc_min
    timec = timex[0] + timex[2]
    timed = str(time.localtime()[0]) + strloc_mon + strloc_day + strloc_std + strloc_min + '00'
    timenow = [timea,timeb,timec,timed] # Sytemzeit / SysZeit ohne : / übergebene Zeit ohne : / xmltv Zeit
    return timenow

def zapsidemenu():
    iptvepg = xmltv()
    zaplist = read_listfile(xbmc.translatePath('special://temp/040264-1002.fi'))
    for entry in zaplist:
            try:
                videoTitle = entry[0].strip()
            except: videoTitle = ''
            try:
                thumbnail = entry[1].strip()
            except: thumbnail = ''
            try:
                url = entry[2].strip()
                url= 'plugin://plugin.video.iptvxtra-th/?zapping'+ url + '***' + videoTitle + '***' + thumbnail + '***'
            except: url = ''
            try:
               name2 = ''
               if epg_on == "true":
                    xmlepg = entry[3].strip() 
                    for text in iptvepg:
                        text0 = text[0].strip() 
                        if text0 == '' or text0 == 'abcdefgh' : break
                        if xmlepg == text0 and int(text[4]) > (int(time.time())-(int(timeshift)*3600)):
                            laenge = len(text[5]) + len(text[6]) + 3
                            name2 = text[5]
                            break
            except: name2 = 'no Info'
            addzaplink(videoTitle,name2,url,thumbnail)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    sys.exit(0)

def addzaplink(name,name2,url,iconimage):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Label": name, "Title": name2 } )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def preview():
    stream =  mode.replace("preview", "")
    full = 1
    if len(stream) == 4:
        xel = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        stream = xel.getControl(int(stream)).getLabel()
    if 'plugin://plugin' in stream:
        stream =  stream.replace('plugin://plugin.video.iptvxtra-th/?preview','')
        stream =  stream.replace('plugin://plugin.video.iptvxtra-th/preview','')
        full = 0

    if '3bb_stream' in stream: thai3(stream,full)
    chheader = 'User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'  
    if __settings__.getSetting("setHeader") == 'true' and __settings__.getSetting("setThai") == 'true': stream = stream + '|' + setFWX() + '&' + chheader
    elif __settings__.getSetting("setThai") == 'true': stream = stream + '|' + setFWX()
    elif __settings__.getSetting("setHeader") == 'true': stream = stream + '|' + chheader
    stream =  stream.replace("###", "|")
    stream =  stream.replace("m3u8channel", "m3u8?channel")
    stream =  stream.replace("m3u8channel", "m3u8?channel")

    try: __settingsreload__.setSetting("is_addon", "th")
    except: pass

    listitem = xbmcgui.ListItem( title_ch, iconImage=icon_ch, thumbnailImage=icon_ch)
    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
    playlist.clear()
    playlist.add( stream, listitem )

    if __settings__.getSetting("setFullx") == 'true' and full == 1: xbmcPlayer.play(playlist,None,False)
    else: xbmcPlayer.play(playlist,None,True)
    xbmc.executebuiltin( "Dialog.Close(infodialog)" )
    sys.exit(0)

def thai3(mode,full):
    mode = mode.replace("3bb_stream-", "").replace("preview", "")
    if mode <> '':
        url = 'http://cloudiptv.3bb.co.th/free_tv/showDetailByIdWowza/' + mode
        basicurl = 'http://110.164.95.226:1935/'
        picurl = 'http://cloudiptv.3bb.co.th/assets/3bb/default9/images/CH/'
        header = {"X-Forwarded-For":"110.77.240.80", "User-Agent":"Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16"}
 
        xbb = requests.get(url, headers=header)
        pattern = 'channel_id.*?name_en":".*?pic_icon":".*?wowza_appname_notlogin":"([^"]+)".*?wowza_filename_notlogin":"([^"]+)"'
        rResult = parse(xbb.text, pattern)
        sResult = rResult[1]
        x0 = sResult[0][0]
        x1 = sResult[0][1]
        playurl = basicurl + x0 + '/' + x1
        playurl = playurl.replace('\/','/') + '|X-Forwarded-For=' + setFWX()

    listitem = xbmcgui.ListItem( title_ch, iconImage=icon_ch, thumbnailImage=icon_ch)
    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
    playlist.clear()
    playlist.add( playurl, listitem )

    if __settings__.getSetting("setFullx") == 'true' and full == 1: xbmcPlayer.play(playlist,None,False)
    else: xbmcPlayer.play(playlist,None,True)
    xbmc.executebuiltin( "Dialog.Close(infodialog)" )
    sys.exit(0)

def setFWX():
    s1 = random.randint(77,78)
    if s1 == 77: 
        s2 = random.randint(128,255)
    elif s1 == 78:
        s2 = random.randint(0,255)
    s3 = random.randint(0,255)
    fwx = "X-Forwarded-For=110.%s.%s.%s" % (s1,s2,s3)
    return fwx

def parse(sHtmlContent, sPattern, iMinFoundValue = 1, ignoreCase = False):
        if ignoreCase:
            aMatches = re.compile(sPattern, re.DOTALL|re.I).findall(sHtmlContent)
        else:
            aMatches = re.compile(sPattern, re.DOTALL).findall(sHtmlContent)
        if (len(aMatches) >= iMinFoundValue):                
            return True, aMatches
        return False, aMatches

def gosetting():
    Addon.openSettings()
    xbmc.executebuiltin('Container.Refresh')
    sys.exit(0)


if 'zapsidemenu' in mode: zapsidemenu()
elif 'preview' in mode: preview()
elif 'gosetting' in mode: gosetting()
else: main()


