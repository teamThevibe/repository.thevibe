#!/bin/python
import xbmcaddon,xbmcgui,xbmc,os,sys

__settingszap__ = xbmcaddon.Addon(id="plugin.video.iptvxtra-th")
xbmcPlayer = xbmc.Player()
mode = sys.argv[1]

idx = mode.replace("url=?zapping", "").replace("###", "|").replace("#x#", "?").replace("#h#", "http://").replace("referer", "Referer")
idx = idx.split('***')
xbmc.executebuiltin('XBMC.Notification('+idx[1]+' , one moment the channel is loaded ,5000,'+idx[2]+')')

stream = __settingszap__.getSetting("code1") + idx[0] + idx[3] + '?pt=3&dt=1&ra=1&code=' + __settingszap__.getSetting("code2") + '&key='

if __settingszap__.getSetting("setHeader") == 'true':
    stream = stream + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0'

listitem = xbmcgui.ListItem( idx[1], iconImage=idx[2], thumbnailImage=idx[2])
playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
playlist.clear()
playlist.add( stream, listitem )

xbmcPlayer.play(playlist,None,False)
sys.exit(0)
