import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time

PLUGIN='plugin.video.mydropbox'
ADDON = xbmcaddon.Addon(id=PLUGIN)
dropboxnumber=ADDON.getSetting('dropbox')
base='http://dl.dropbox.com/u/129714017/hubmaintenance/'

foldername=ADDON.getSetting('foldername')
if ADDON.getSetting('dropbox')=='':
    ADDON.openSettings()
boxlist='https://dl.dropbox.com/u/%s/'%(dropboxnumber)
    
box='https://dl.dropbox.com/u/%s/%s/'%(dropboxnumber,foldername)
icon = 'http://a0.twimg.com/profile_images/1880386140/logo-square.jpg'




 #      addDir('name','url','mode','iconimage','description') mode is where it tells the plugin where to go scroll to bottom to see where mode is
def CATEGORIES():
        addDir('Get My Videos',boxlist+'list.txt',1,icon,'hello everyone this is the description')
        if ADDON.getSetting('listmake') == 'true': 
            addDir('Create List',box+'list.txt',2,icon,'hello everyone this is the description')
        addDir('Need Help??','url',2000,base+'images/help.jpg',base+'images/fanart/expert.jpg')
        setView('movies', 'default') 
       #setView is setting the automatic view.....first is what section "movies"......second is what you called it in the settings xml  
       
       
                      												  
        
def dropbox(url):
        link=OPEN_URL(url)
        match=re.compile('name=(.+?) url=(.+?)"').findall(link)
        for name ,url in match:
                url = box+urllib.quote(url)
                addLink(name,url,'','')        
                setView('movies', 'videos') 
         
 
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def writelist(url):
    publicpath = ADDON.getSetting('dir_path')
    videopath = os.path.join(ADDON.getSetting('dir_path'),foldername)
    txt = os.path.join(publicpath, 'list.txt')
    listtxt=[]
    for root, dirs, files in os.walk(videopath):
        for f in files:
            regex=re.compile('(.+?)\.(.+?)')
            match1=regex.search(f)
            name=match1.group(1)
            result='name=%s url=%s"'%(name,f)
            print result
            listtxt.append(result)
            mylist=str(listtxt)
            txtfile = open(txt,"w") 
            txtfile.write(mylist)
            txtfile.close()
    dialog = xbmcgui.Dialog()
    dialog.ok("TEAM MIKEY", "       Thats It All Done Please Come Visit Again", "          Brought To You By XBMCTALK.COM")
    
        


        
        
             
                    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

# this is the listing of the items        
def addDir(name,url,mode,iconimage,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
        if not mode==2000:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
#same as above but this is addlink this is where you pass your playable content so you dont use addDir you use addLink "url" is always the playable content         
def addLink(name,url,iconimage,description):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok 
 
        
#below tells plugin about the views                
def setView(content, viewType):
        # set content type so library shows more views and info
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        description=int(params["description"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        dropbox(url)
        
elif mode==2:
        print ""+url
        writelist(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
