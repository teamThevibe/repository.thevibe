# -*- coding: utf-8 -*-
'''
 
    Special Thanks to the following developers for their contribution to the current code,
	               any future modifications, and to the KODI XBMC Community as a whole.  AAA
				   Mikey1234 Mettlekettle Kinkin Lambda spoyser Voinage Jasonpc
				   Highways Eldorado Blazetamer eleazer coding The-one Coolwave Muckyduck
				   Please contact us via facebook.com/aaastream if you are to be included
				   
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Everyone should benefit from the GPL & opensource Programming
	
	H@k@M@c
	
'''

aaastreamversion = "V2.0"
aaastreamdate = "01/06/2015 11:00hrs  GMT"

import urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, time, base64
import re,urllib2, datetime
import xbmcplugin,random,urlparse,urlresolver
from t0mm0.common.addon import Addon
from metahandler import metahandlers
from addon.common.net import Net
from threading import Timer

PlaylistUrl = "http://aaastream.com"
AddonID = 'plugin.video.aaastream'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString

LocalisedReplay = 'aHR0cDovL2xpdmVmb290YmFsbHZpZGVvLmNvbS8='
Raw = base64.decodestring('aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcucGhwP2k9')
ChinaServer = base64.decodestring('aHR0cDovL2FhYXJlcG8ueHl6L2RvY3Mv')
LibDBLink = base64.decodestring('aHR0cDovL2ltdmRiLmNvbS8=')

EvoUrl = str(' http://aaarepo.xyz/evo/')

resolve_url=['180upload', 'my.mail.ru','streamin.to', '2gbhosting', 'alldebrid', 'allmyvideos', 'auengine', 'bayfiles', 'bestreams', 'billionuploads', 'castamp', 'cheesestream', 'clicktoview', 'cloudy', 'crunchyroll', 'cyberlocker', 'daclips', 'dailymotion', 'divxstage', 'donevideo', 'ecostream', 'entroupload', 'exashare', 'facebook', 'filebox', 'filenuke', 'flashx', 'gorillavid', 'hostingbulk', 'hostingcup', 'hugefiles', 'jumbofiles', 'lemuploads', 'limevideo', 'megarelease', 'megavids', 'mightyupload', 'mooshare_biz', 'movdivx', 'movpod', 'movreel', 'movshare', 'movzap', 'mp4stream', 'mp4upload', 'mrfile', 'muchshare', 'nolimitvideo', 'nosvideo', 'novamov', 'nowvideo', 'ovfile', 'play44_net', 'played', 'playwire', 'premiumize_me', 'primeshare', 'promptfile', 'purevid', 'putlocker', 'rapidvideo', 'realdebrid', 'rpnet', 'seeon', 'sharedsx', 'sharefiles', 'sharerepo', 'sharesix', 'sharevid', 'skyload', 'slickvid', 'sockshare', 'stagevu', 'stream2k', 'streamcloud', 'teramixer', 'thefile', 'thevideo', 'trollvid', 'tubeplus', 'tunepk', 'ufliq', 'uploadc', 'uploadcrazynet', 'veeHD', 'veoh', 'vidbull', 'vidcrazynet', 'video44', 'videobb', 'videoboxone', 'videofun', 'videomega', 'videoraj', 'videotanker', 'videovalley', 'videoweed', 'videozed', 'videozer', 'vidhog', 'vidpe', 'vidplay', 'vidspot', 'vidstream', 'vidto', 'vidup_org', 'vidxden', 'vidzi', 'vidzur', 'vimeo', 'vk', 'vodlocker', 'vureel', 'watchfreeinhd', 'xvidstage', 'yourupload', 'youwatch', 'zalaa', 'zooupload', 'zshare']
g_ignoreSetResolved=['plugin.video.dramasonline','plugin.video.f4mTester','plugin.video.shahidmbcnet','plugin.video.SportsDevil','plugin.stream.vaughnlive.tv','plugin.video.ZemTV-shani']

FacebookLink = 'tea3JfeMGzw'
DirectoryMSG = "[B][COLOR gold]FACEBOOK[/COLOR][/B]"

net = Net(user_agent='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36')
headers = {
    'Accept'    :   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
    }
AddonName = Addon.getAddonInfo("name")
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.aaastream/fanart.jpg'))
artpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.aaastream/resources/art/'))
icon = Addon.getAddonInfo('icon')
addonDir = Addon.getAddonInfo('path').decode("utf-8")
LibCommon = len(PlaylistUrl)
libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
custurltv = str(base64.decodestring('aHR0cDovL3d3dy50dm9ubGluZS50dy8='))
trans_table = ''.join( [chr(i) for i in range(128)] + [' '] * 128 )
datapath = xbmc.translatePath(Addon.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, "football.lwp")
if os.path.exists(cookie_path) == False:
        os.makedirs(cookie_path)
        net.save_cookies(cookie_jar)
		
import common

metaget = metahandlers.MetaData(preparezip=False)
metaset = 'true'
Freeview_url = 'http://www.filmon.com/' 
session_url = 'http://www.filmon.com/api/init/'
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

ChildLockStatus = ''	
ChildLockFile = os.path.join(libDir,"childlock.txt")
if not (os.path.isfile(ChildLockFile)):
    ChildLockStatus = 'OFF'
else:
    ChildLockStatus = 'ON'
channels = ''	  
tmpListFile = os.path.join(addonDir, 'tempList.txt')
favoritesFile = os.path.join(addonDir, 'favorites.txt')
if  not (os.path.isfile(favoritesFile)):
	f = open(favoritesFile, 'w') 
	f.write('[]') 
	f.close() 

def Categories():
    Version = '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]'
    try: Version = net.http_GET('http://aaastream.com/version.php').content
    except: AddDir("[COLOR red][B] BAD CONNECTION [/B][/COLOR]", "Update" ,98, "http://s5.postimg.org/rru49d087/appgraphic.png")
    if Version != aaastreamdate and Version != '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]':
           UpdateMe()
           xbmc.executebuiltin("UpdateLocalAddons")

   
    AddDir("[COLOR white][B] "+aaastreamversion+" [/B][/COLOR]", "Update" ,98, "http://s5.postimg.org/rru49d087/appgraphic.png")
    links = ''
    try: links = net.http_GET(Raw + 'ECMKuYkS').content
    except: pass
    if links.find('AAAMENU') < 1:
        try: links = net.http_GET(ChinaServer + 'homealpha').content
        except: links = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*SERVER DOWN*[/B][/COLOR]" C:"http://s5.postimg.org/rru49d087/appgraphic.png"'
		
    AddFacebookLink()
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        url = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')
        AddDir('[COLOR lime]'+name+'[/COLOR]',url, mode, icon)
		   
    AddDir("[COLOR white][B] UPDATE[/B][/COLOR]", "Update" ,50, "http://s5.postimg.org/pgtpss09z/update.png")   
    xbmc.executebuiltin("Container.SetViewMode(500)") 
    
def AddFacebookLink():
    AddDir(DirectoryMSG,FacebookLink, 60, "http://s5.postimg.org/7hz1vjzaf/facebook.png", isFolder=False)

	
def XMLRead500(url):
    StreamlistURL = ''
    if url[:4].lower() == "evo-":
        StreamlistURL = EvoUrl
    elif url[:5].lower() == "chin-":
        StreamlistURL = ChinaServer
    else:
        StreamlistURL = Raw
		
    try: links = net.http_GET(StreamlistURL + url).content
    except: return
	
    links = links.encode('ascii', 'ignore').decode('ascii')
	
    if url[:4].lower() == "evo-":
       links = links.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\r\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
       links = links.replace('<a href="','').replace('</a>&#8220;#','"')	   
	   
    SetViewLayout = "50"
     
    LayoutType = re.compile('FORMAT"(.+?)"').findall(links)
    if LayoutType:
       SetViewLayout = str(LayoutType)
       SetViewLayout = SetViewLayout.replace('[u\'','').replace(']','').replace('\'','')
    
    AddFacebookLink()
    links = links.encode('ascii', 'ignore').decode('ascii')	
	
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        vurl = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')

        AddDir('[COLOR lime]'+name+'[/COLOR]',vurl, mode, icon)
		   
    
    all_videos = regex_get_all(links, '<item>', '</item>')
    for a in all_videos:
        background = ''
        vurl = regex_from_to(a, '<link>', '</link>').replace('  ', ' ')
        name = regex_from_to(a, '<title>', '</title>')
        icon = regex_from_to(a, '<thumbnail>', '</thumbnail>')
        background = regex_from_to(a, '<fanart>', '</fanart>')
        if len(background) < 5:
            background = icon

        AddDir('[COLOR lime]'+name+'[/COLOR]',vurl, 3, icon,isFolder=False, background=background)
    list = common.m3u2list(StreamlistURL + url)
    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
        mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3

        AddDir(name ,channel["url"], mode, "http://s5.postimg.org/rru49d087/appgraphic.png", isFolder=False)
		
    xbmc.executebuiltin("Container.SetViewMode("+str(SetViewLayout)+")")	

				
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("AAA Stream","Downloading")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()
						   
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
            smallicon= "http://s5.postimg.org/ycy0pxt9j/appmovies.jpg"
            xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","+smallicon+")")
     elif typeq == 'big':
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ')

def PlxCategory(url):
	tmpList = []
	list = common.plx2list(url)
	background = list[0]["background"]
	for channel in list[1:]:
		iconimage = "" if not channel.has_key("thumb") else common.GetEncodeString(channel["thumb"])
		name = common.GetEncodeString(channel["name"])
		if channel["type"] == 'playlist':
			AddDir("[COLOR blue][{0}][/COLOR]".format(name) ,channel["url"], 1, iconimage, background=background)
		else:
			AddDir(name, channel["url"], 3, iconimage, isFolder=False, background=background)
			tmpList.append({"url": channel["url"], "image": iconimage, "name": name.decode("utf-8")})
			
	common.SaveList(tmpListFile, tmpList)
			
		
def AddDir(name, url, mode, iconimage, description='', isFolder=True, background=None):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)

    if background == None:
       background=iconimage
	
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
    liz.setProperty('fanart_image', background)
    if mode == 1 or mode == 2:
       liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
    elif mode == 3:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
    elif mode == 32:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
		
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text =  "" if not keyboard.isConfirmed() else keyboard.getText()
	return text

def GetSourceLocation(title, list):
	dialog = xbmcgui.Dialog()
	answer = dialog.select(title, list)
	return answer
	
def AddFavorites(url, iconimage, name):
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
			return
    
	list = common.ReadList(tmpListFile)	
	for channel in list:
		if channel["name"].lower() == name.lower():
			url = channel["url"]
			iconimage = channel["image"]
			break
			
	if not iconimage:
		iconimage = ""
		
	data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
	favList.append(data)
	common.SaveList(favoritesFile, favList)
	xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))

def cleanlink(link):
    data=link.replace('\u00a0',' ').replace('\u00ae','').replace('\u00e9','').replace('\u00e0','').replace('\u2013','').replace('\u00e7','').replace('\u00f1','')
    return data
	
def UpdateMe():
    dp = xbmcgui.DialogProgress()
    dp.create('UPDATING AAASTREAM')
    dp.update(10)
    url = "http://kodi.xyz/updateaaa.php"
    localfile = os.path.join(addonDir,"default.py")
    urllib.urlretrieve(url,localfile)
    url = "http://kodi.xyz/updateaddon.php"
    localfile = os.path.join(addonDir,"addon.xml")
    urllib.urlretrieve(url,localfile)
    dp.update(30)	
    localfile = os.path.join(libDir,"repobuild.py")
    url = "http://kodi.xyz/reporebuild.php"
    urllib.urlretrieve(url,localfile)
    
    dp.update(75)	
    import repobuild
    repobuild.UpdateRepo()
	
    dp.update(90)	
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
	
    dp.update(100)
    dp.close()
	
 #   xbmcgui.Dialog().ok('AAASTREAM', 'Updated. A reboot of Kodi/XBMC may be required', '   ', 'Donation website: http://tvip.xyz')

def RemoveFavorties(url):
	list = common.ReadList(favoritesFile) 
	for channel in list:
		if channel["url"].lower() == url.lower():
			list.remove(channel)
			break
			
	common.SaveList(favoritesFile, list)
	xbmc.executebuiltin("XBMC.Container.Refresh()")

def YouTubeCode(url):
    try:
        url = "PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid="+url+")"
        xbmc.executebuiltin(url)
    except:
        xbmc.executebuiltin("XBMC.Notification(AAA STREAM,This host is not supported or resolver is broken::,10000)")

def m3uCategory(url):
    url = Raw + url
    list = common.m3u2list(url)
    AddFacebookLink()
    for channel in list:
		name = common.GetEncodeString(channel["display_name"])
		mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3
		AddDir(name ,channel["url"], mode, "http://s5.postimg.org/rru49d087/appgraphic.png", isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(50)")

def Newsletter(url):
    list = common.m3u2list(ChinaServer+url)
    AddFacebookLink()
    for channel in list:
		name = common.GetEncodeString(channel["display_name"])
		mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3
		AddDir(name ,channel["url"], mode, "http://s5.postimg.org/mmv5t2nhj/newsletter.png", isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(50)")
	
def ListFavorites():
    AddDir('[B][COLOR yellow]YOUR FAVOURITES LIST[/COLOR][/B]','BLANK',999,"http://s5.postimg.org/60906955z/favorite.png")	
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
    list = common.ReadList(favoritesFile)
    for channel in list:
		name = channel["name"].encode("utf-8")
		iconimage = channel["image"].encode("utf-8")
		AddDir(name, channel["url"], 32, iconimage, isFolder=False) 

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)

    xbmc.executebuiltin("Container.SetViewMode(true)")		
						
def AddNewFavortie():
	chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
	if len(chName) < 1:
		return
	chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
	if len(chUrl) < 1:
		return
		
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
			return
			
	data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
	
	favList.append(data)
	if common.SaveList(favoritesFile, favList):
		xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))

def PlayUrl(name, url, iconimage=None):
	print '--- Playing "{0}". {1}'.format(name, url)
	listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
	listitem.setInfo(type="Video", infoLabels={ "Title": name })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
def PlayURLResolver(name,url,iconimage):
    import commonresolvers
    resolved = commonresolvers.get(url).result
    if resolved:
        if isinstance(resolved,list):
            for k in resolved:
                quality = 'HD'
                if k['quality'] == 'HD'  :
                    resolver = k['url']
                    break
                elif k['quality'] == 'SD' :
                    resolver = k['url']        
                elif k['quality'] == '1080p' and addon.getSetting('1080pquality') == 'true' :
                    resolver = k['url']
                    break
        else:
            resolver = resolved        
        playsetresolved(resolver,name,iconimage)
    else: 
        xbmc.executebuiltin("XBMC.Notification(AAA STREAM,This host is not supported or resolver is broken::,10000)")  

def playsetresolved(url,name,iconimage):
    liz = xbmcgui.ListItem(name, iconImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':name})
    liz.setProperty("IsPlayable","true")
    	
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	
def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
	   try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
	   except: r = ''
    else:
       try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
       except: r = ''
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
	
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0].lower()] = splitparams[1]
	return param

	
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
channels=None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
try:        
	mode = int(params["mode"])
except:
	pass
try:        
	description = urllib.unquote_plus(params["description"])
except:
	pass

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: channels=urllib.unquote_plus(params["channels"])
except: pass

	
if mode == None or url == None or len(url) < 1:
	Categories()
elif mode == 1:
	PlxCategory(url)
elif mode == 2:
    XMLRead500(url)
#	m3uCategory(url)
elif mode == 3 or mode == 32:
     print 'test'
elif mode == 4:
    Newsletter(url)
elif mode == 11:
	YouTube_List(url)
elif mode == 20:
	XMLRead500(url)
elif mode == 30:
	ListFavorites()
elif mode == 31: 
	AddFavorites(url, iconimage, name) 
elif mode == 33:
	RemoveFavorties(url)
elif mode == 34:
	AddNewFavortie()
elif mode == 35:
    x1Channels(url)
elif mode == 41:
	common.DelFile(favoritesFile)
elif mode == 50:
    UpdateMe()
    sys.exit()
elif mode == 60 or mode == 46:	
    PlayYoutubeView(url)
elif mode == 98 and LibCommon == 20:
    sys.exit()
elif mode == 99 and LibCommon == 20:
	Categories()
elif mode == 200 and LibCommon == 20: 	
	YouTube_List(url)
elif mode == 210 and LibCommon == 20: 	
	YouTubeCode(url)
elif mode == 520:
    StreamM3U(url)
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#       xbmcgui.Dialog().ok(str(name), url)
# h@k@M@c Code