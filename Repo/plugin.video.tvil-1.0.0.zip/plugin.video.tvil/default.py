# -*- coding: utf-8 -*-
import urlresolver,plugintools,urllib,xbmcplugin,xbmc,xbmcgui,requests,hybresolver,re
from bs4 import BeautifulSoup

def main_menu():
    plugintools.add_item(title=u'חיפוש',action='search')
    plugintools.add_item(title=u'כל הסדרות',action='allseries')
    plugintools.add_item(title=u'נוספו לאחרונה',action='latest',url='http://www.tvil.me/?num=1')
    plugintools.add_item(title=u"ז'אנרים",action='genres')
    plugintools.close_item_list()

def checkNext(soup):
    page = soup.find('a',{'class':'current'})
    if page.text == u'הבא':
        return False
    else: return True
    
def latest(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')
    
    div = soup.find('div',{'id':'explode-right'})
    items = div.findAll('div',{'class':'begin-frame'})
    for item in items:
        titleandurl = item.find('div',{'class':'begin-frame-caption'}).find('a')
        image = item.find('table').find('img')
        plugintools.add_item(title=titleandurl.text,action='streams',url='http://www.tvil.me/'+titleandurl.get('href'),thumbnail=image.get('src'))
    page = re.compile('[0-9]+').findall(url)[0]
    if checkNext(soup):
        plugintools.add_item(title=u'[COLOR RED]עמוד הבא[/COLOR]',action='latest',url='http://www.tvil.me/?num='+str(int(page)+1))
    plugintools.close_item_list()
    
def allSeries(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text,'html.parser')
    links =  soup.find('div', {"class": "begin-frame"})

    links = links.findAll('div', id=lambda x: x and x.startswith('show-details'))
    resultsList = []
    
    for link in links :
         thumb = re.compile("background:url\\('(.*)'\\)").findall(link.get('style'))[0]
         titles = link.findAll('a')
         try:
             title = titles[0].text+' / '+titles[1].text
         except:
             title = titles[0].text
         url = 'http://www.tvil.me/'+titles[0].get('href')
         resultsList.append({'url':url,'title':title,'thumbnail':thumb})
    return resultsList
            
def getSeasons(url,title,thumbnail):
    r = requests.get(url)
    soup = BeautifulSoup(r.text,'html.parser')
    links = soup.find('div', {'class': "begin-frame"})
    div = links.findAll('div', {"style": ""})
    for link in div:
        if link.a!=None:
            plugintools.add_item(title=link.a.text,action='episodes',url='http://www.tvil.me/'+link.a.get('href'),thumbnail=thumbnail,extra=title)
    plugintools.close_item_list()

    
def getEpisodes(url,title,thumbnail):
    r = requests.get(url)
    soup = BeautifulSoup(r.text,'html.parser')
    links = soup.find('div', {'class': "begin-frame"})
    div = links.findAll('div', {"style": ""})
    for link in div:
        if link.a!=None:
            if 'עונה' not in link.a.text.encode('utf-8'):
                plugintools.add_item(title=link.a.text,action='streams',url='http://www.tvil.me/'+link.a.get('href'),thumbnail=thumbnail,extra=title)
    plugintools.close_item_list()
                
def getGenres():
    url = 'http://www.tvil.me/?page=allseries'
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')
    
    table = soup.findAll('table', {'class': "table-1"})
    rows = table[2].findAll('tr')
    for tr in rows:
        cols = tr.findAll('td') 
        a =  cols[0].find('a')
        plugintools.add_item(title=a.text,action='genre',url=a.get('href'))
    plugintools.close_item_list()
             
def getGenre(url):
    seriesList = allSeries('http://www.tvil.me/'+url)
    for item in seriesList:
        plugintools.add_item(title=item.get('title'),action='series',url=item.get('url'),thumbnail=item.get('thumbnail'))
    plugintools.close_item_list()
    
def getAllSeries():
    seriesList = allSeries('http://www.tvil.me/index.php?page=allseries')
    for item in seriesList:
        plugintools.add_item(title=item.get('title'),action='series',url=item.get('url'),thumbnail=item.get('thumbnail'))
    plugintools.close_item_list()
    
def getStreams(url):
    
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')
    
    table = soup.find('div', {'id': "show-links-t"})
    sourcesList = []
    for item in table.findAll('a'):
        sourcesList.append({'url':item.get('href').replace('\r','').replace('\n',''),'title':item.text})
         
    return sourcesList

def streams(url,title,thumbnail):
    slist = getStreams(url)
    for item in slist:
        plugintools.add_item(title=item.get('title'),action='play',url=item.get('url'),thumbnail=thumbnail,extra=title)
    plugintools.close_item_list()
    
def stream(url,title,thumbnail):
    li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail,path=url)
    li.setInfo(type='Video', infoLabels={ "Title": str(title) })
    xbmc.Player().play(url,li)
    
def getDataFormSearchUrl(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')    
    div = soup.find('div', {'class': "begin-frame"})
    table = div.find('table')    
    
    tds = table.findAll('td')    
    desc = tds[1].text.replace('<br>','\n')
    
    seasons = []
    a = tds[2].findAll('a')    
    for link in a:        
        seasons.append([link.text,'http://www.tvil.me/' + link['href']])
    
    trs = table.findAll('tr')     
    img = trs[0].find('img')  
    imgSrc = img['src']
    
    return {'thumbnail':imgSrc,'description':desc,'seasons':seasons}

def getSearch(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')    
    a = soup.findAll('a')
    resultList = []
    for link in a:
        url = 'http://www.tvil.me/' + link['href']
        details = getDataFormSearchUrl(url)
        resultList.append({'title':link.text,'url':url,'thumbnail':details.get('thumbnail')})
    return resultList
        
def doSearch(str):   
    return getSearch('http://www.tvil.me/ajax.php?action=search&module=' + str.replace(' ','+'))
    
def search():
    searchtext=""
    keyboard = xbmc.Keyboard(searchtext,u'הכנס שם של סדרה')
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        results = doSearch(keyboard.getText())
        for series in results:
            plugintools.add_item(title=series.get('title'),action='series',url=series.get('url'),thumbnail=series.get('thumbnail'))
        plugintools.close_item_list()
   
def play(url,title,thumbnail): 
    final=urlresolver.HostedMediaFile(url)
    new_url=final.get_url()
    if 'upf' in new_url:
        resolved_url = hybresolver.upf(new_url)
    elif 'wholecloud' in new_url:
        resolved_url = hybresolver.wholecloud(new_url)
    else:
        resolved_url=urlresolver.resolve(new_url)
    stream(resolved_url,title,thumbnail)
    
def run():
    params = plugintools.get_params()
    action = params.get('action')
    if action == None:
        main_menu()
    elif action == 'search':
        search()
    elif action == 'allseries':
        getAllSeries()
    elif action == 'series':
        getSeasons(urllib.unquote_plus(params.get('url')),urllib.unquote_plus(params.get('title')),urllib.unquote_plus(params.get('thumbnail')))
    elif action == 'episodes':
        getEpisodes(urllib.unquote_plus(params.get('url')),urllib.unquote_plus(params.get('title')),urllib.unquote_plus(params.get('thumbnail')))
    elif action == 'latest':
        latest(params.get('url'))
    elif action == 'genres':
        getGenres()
    elif action == 'genre':
        getGenre(urllib.unquote_plus(params.get('url')))
    elif action == 'streams':
        streams(urllib.unquote_plus(params.get('url')),urllib.unquote_plus(params.get('title')),urllib.unquote_plus(params.get('thumbnail')))
    elif action == 'play':
        try:
            play(urllib.unquote_plus(params.get('url')),urllib.unquote_plus(params.get('extra')),urllib.unquote_plus(params.get('thumbnail')))
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok(u"שגיאה", u" מקור זה אינו זמין")
    
run()