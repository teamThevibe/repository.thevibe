import requests,re

def upf(url):
    s = requests.Session()
    s.headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}
    r=s.get(url)
    preview = re.compile('window.open\\("(.*)","_blank"').findall(r.text)[0]
    r=s.get(preview)
    return re.compile("video src='(.*)' controls").findall(r.text)[0]

def wholecloud(url):
    url = url.replace('video/','embed/?v=')
    s = requests.Session()
    s.headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}
    r=s.get(url)
    key = re.compile('var fkzd="(.*)";').findall(r.text)[0]
    file = re.compile('flashvars.file="(.*)";').findall(r.text)[0]
    api_url = 'http://www.wholecloud.net/api/player.api.php?key='+key+'&numOfErrors=0&user=undefined&cid=0&file='+file
    r=s.get(api_url)
    return re.compile('url=(.*).flv').findall(r.text)[0]+'.flv'