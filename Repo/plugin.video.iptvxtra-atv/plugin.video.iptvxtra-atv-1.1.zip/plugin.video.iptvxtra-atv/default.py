# -*- coding: utf-8 -*-
# please visit http://www.iptvxtra.net

import os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon,urllib

plugin_handle = int(sys.argv[1])
addonID = 'plugin.video.iptvxtra-atv'
addon = xbmcaddon.Addon(id = addonID)
addonPath = addon.getAddonInfo('path')
profilePath = addon.getAddonInfo('profile')
icon1 = xbmc.translatePath( os.path.join( addonPath , 'icons/icon1.png' ) )
icon2 = xbmc.translatePath( os.path.join( addonPath , 'icons/icon2.png' ) )
icon3 = xbmc.translatePath( os.path.join( addonPath , 'icons/icon3.png' ) )
icon4 = xbmc.translatePath( os.path.join( addonPath , 'icons/icon4.png' ) )

def add_video(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)


add_video('rtmp://augsburgtv.iptv-playoutcenter.de:1935/augsburgtv/ playpath=augsburgtv.stream_1 swfUrl=http://flowcenter2.flowworks.de/channelmanager/templates/default/template/jwplayer/jwplayer.flash.swf pageUrl=http://www.augsburg.tv/livestream/livestream-augsburg_tv.html live=1',{ 'title': 'a.tv 960x540'}, icon1)
add_video('rtmp://augsburgtv.iptv-playoutcenter.de:1935/augsburgtv/ playpath=augsburgtv.stream_2 swfUrl=http://flowcenter2.flowworks.de/channelmanager/templates/default/template/jwplayer/jwplayer.flash.swf pageUrl=http://www.augsburg.tv/livestream/livestream-augsburg_tv.html live=1',{ 'title': 'a.tv 704x576'}, icon1)
add_video('rtmp://augsburgtv.iptv-playoutcenter.de:1935/augsburgtv/ playpath=augsburgtv.stream_3 swfUrl=http://flowcenter2.flowworks.de/channelmanager/templates/default/template/jwplayer/jwplayer.flash.swf pageUrl=http://www.augsburg.tv/livestream/livestream-augsburg_tv.html live=1',{ 'title': 'a.tv 512x288'}, icon1)
add_video('http://edge.live.mp3.mdn.newmedia.nacamar.net/ps-hitradiort1/livestream.mp3',{ 'title': 'RT1 Hitradio'}, icon2)
add_video('http://edge.live.mp3.mdn.newmedia.nacamar.net/ps-rt1suedschwaben/livestream.mp3',{ 'title': 'RT1 S�d Schwaben'}, icon2)
add_video('http://edge.live.mp3.mdn.newmedia.nacamar.net/ps-rt1nordschwaben/livestream.mp3',{ 'title': 'RT1 Nord Schwaben'}, icon2)
add_video('http://edge.live.mp3.mdn.newmedia.nacamar.net/ps-inthemix/livestream.mp3',{ 'title': 'RT1 in the mix'}, icon2)
add_video('http://80.237.158.63/fantasy.mp3',{ 'title': 'Radio Fantasy'}, icon3)
add_video('http://streamplus36.leonex.de:15440',{ 'title': 'Radio Augsburg'}, icon4)


xbmcplugin.endOfDirectory(plugin_handle)
xbmc.executebuiltin("Container.SetViewMode(500)")
