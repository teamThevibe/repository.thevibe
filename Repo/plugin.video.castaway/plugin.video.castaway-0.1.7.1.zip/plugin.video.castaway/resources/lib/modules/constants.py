def flash_ver():
      return 'WIN\\2021,0,0,182'

def get_shockwave():
      return 'ShockwaveFlash/21.0.0.182'


adult = ['adult','xxx', 'erotic', 'porn', 'sex']