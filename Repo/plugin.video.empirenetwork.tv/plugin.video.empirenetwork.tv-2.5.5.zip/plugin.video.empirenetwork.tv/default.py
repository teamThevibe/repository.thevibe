import urllib , urllib2 , sys , re , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os
import datetime
from datetime import date
import time
from t0mm0 . common . net import Net
from t0mm0 . common . addon import Addon
from threading import Timer
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.empirenetwork.tv'
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = Addon ( OO0o , sys . argv )
if 5 - 5: iiI / ii1I
ooO0OO000o = 'http://sportsmafia.tv/'
if 4 - 4: IiII1IiiIiI1 / iIiiiI1IiI1I1
# get parameters
o0OoOoOO00 = O0O0OO0O0O0 . queries [ 'mode' ]
I11i = O0O0OO0O0O0 . queries . get ( 'play' , None )
O0O = O0O0OO0O0O0 . queries . get ( 'img' , '' )
Oo = O0O0OO0O0O0 . queries . get ( 'title' , None )
I1ii11iIi11i = O0O0OO0O0O0 . queries . get ( 'dir_end' , 'true' )
I1IiI = O0O0OO0O0O0 . queries . get ( 'dir_update' , 'false' )
o0OOO = O0O0OO0O0O0 . queries . get ( 'url' , '' )
iIiiiI = O0O0OO0O0O0 . queries . get ( 'referer' , ooO0OO000o )
if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
if 68 - 68: o00ooo0 / Oo00O0
def ooO0oooOoO0 ( ) :
 xbmc . executebuiltin ( "XBMC.Container.Update(path,replace)" )
 xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
 if 21 - 21: IiIii1Ii1IIi / O0Oooo00 . oo00 * I11
if Oo0Ooo . getSetting ( 'user' ) == '' :
 Oo0o0000o0o0 = xbmcgui . Dialog ( )
 if Oo0o0000o0o0 . yesno ( "Sports Mafia" , "Please sign up for an account at:" , "[COLOR royalblue]http://www.sportsmafia.tv/[/COLOR]" , "" , "Exit" , "Continue" ) :
  if 86 - 86: iiiii11iII1 % O0o
  Oo0o0000o0o0 . ok ( "Sports Mafia" , "Please provide your username" )
  oO0 = xbmc . Keyboard ( "" , "Sports Mafia - Please provide your username" )
  oO0 . doModal ( )
  if oO0 . isConfirmed ( ) :
   IIIi1i1I = oO0 . getText ( )
  Oo0Ooo . setSetting ( 'user' , IIIi1i1I )
  if 72 - 72: iii11iiII % ii1I / O0o + O0o % Oo00O0
  Oo0o0000o0o0 . ok ( "Sports Mafia" , "Please provide your password" )
  oO0 = xbmc . Keyboard ( "" , "Sports Mafia - Please provide your password" )
  oO0 . doModal ( )
  if oO0 . isConfirmed ( ) :
   Ii = oO0 . getText ( )
  Oo0Ooo . setSetting ( 'pass' , Ii )
 else :
  ooO0oooOoO0 ( )
  if 43 - 43: oO0o0ooO0 - iIiiiI1IiI1I1 + O0o + oo00
iII111ii = Oo0Ooo . getSetting ( 'user' )
i1iIIi1 = Oo0Ooo . getSetting ( 'pass' )
if 50 - 50: i11iIiiIii - oo00
oo0Ooo0 = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
I1I11I1I1I = os . path . join ( oo0Ooo0 , "sportsmafiatv.lwp" )
if 90 - 90: iii1II11ii + Oo00O0 / iiIIIII1i1iI % iii1II11ii - iiI
if 29 - 29: iiIIIII1i1iI / ii1I
IiIIIiI1I1 = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36'
OoO000 = { 'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8' ,
 'Accept-Encoding' : 'gzip,deflate,sdch' ,
 'Accept-Language' : 'en-US,en;q=0.8' ,
 'Host' : 'sportsmafia.tv' ,
 'Origin' : ooO0OO000o ,
 'User-Agent' : IiIIIiI1I1 ,
 'Connection' : 'keep-alive'
 }
if 42 - 42: Oo00O0 - iIiiiI1IiI1I1 / i11iIiiIii + IiIii1Ii1IIi + ii1II11I1ii1I
import cookielib
def iIi ( cookiejar , filename ) :
 II = cookielib . LWPCookieJar ( )
 for iI in cookiejar :
  iI11iiiI1II = dict ( vars ( iI ) . items ( ) )
  iI11iiiI1II [ 'rest' ] = iI11iiiI1II [ '_rest' ]
  del iI11iiiI1II [ '_rest' ]
  iI = cookielib . Cookie ( ** iI11iiiI1II )
  II . set_cookie ( iI )
 II . save ( filename , ignore_discard = True )
 if 79 - 79: O0o % i11iIiiIii / ii1I . IiIii1Ii1IIi
def o0oO0o00oo ( filename ) :
 II = cookielib . LWPCookieJar ( )
 II . load ( filename , ignore_discard = True )
 return II
 if 32 - 32: iI1Ii11111iIi * iiI % Oo00O0 % oo00 . iiiii11iII1
def o0OOOOO00o0O0 ( requests2 ) :
 o0o0OOO0o0 = '%sforum.php' % ooO0OO000o
 ooOOOo0oo0O0 = requests2 . get ( o0o0OOO0o0 , headers = OoO000 ) . text
 o0 = { }
 import re
 for I11II1i in re . finditer ( '<input.+?type=[\'"]{1}hidden[\'"]{1}(.+?)>' , ooOOOo0oo0O0 ) :
  IIIII = I11II1i . group ( 1 )
  ooooooO0oo = re . search ( 'name=[\'"]{1}([^\'"]*)[\'"]{1}' , IIIII )
  IIiiiiiiIi1I1 = re . search ( 'value=[\'"]{1}([^\'"]*)[\'"]{1}' , IIIII )
  if IIiiiiiiIi1I1 :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . group ( 1 )
  else :
   IIiiiiiiIi1I1 = ""
  ooooooO0oo = ooooooO0oo . group ( 1 )
  o0 . update ( { ooooooO0oo : IIiiiiiiIi1I1 } )
  if 13 - 13: iiiii11iII1 + oO0o0ooO0 - IiII1IiiIiI1 + O0o . I11 + ii1II11I1ii1I
 import hashlib
 Iioo0O0oOOO00oO = hashlib . md5 ( i1iIIi1 ) . hexdigest ( )
 if 61 - 61: iIiiiI1IiI1I1 * IiIii1Ii1IIi / IiII1IiiIiI1 . i11iIiiIii . oO0o0ooO0
 import random
 if 60 - 60: O0Oooo00 / O0Oooo00
 o0 . update ( { 'vb_login_username' : iII111ii } )
 o0 . update ( { 'vb_login_password' : '' } )
 o0 . update ( { 'vb_login_md5password' : Iioo0O0oOOO00oO } )
 o0 . update ( { 'vb_login_md5password_utf' : Iioo0O0oOOO00oO } )
 o0 . update ( { 'cookieuser' : '1' } )
 o0 . update ( { 'do' : 'login' } )
 o0 . update ( { 's' : '' } )
 o0 . update ( { 'x' : random . randint ( 1 , 800 ) } )
 o0 . update ( { 'y' : random . randint ( 1 , 600 ) } )
 o0 . update ( { 'vb_login_password_hint' : 'Password' } )
 if 46 - 46: oo00 * IiIii1Ii1IIi - ii1II11I1ii1I * Oo00O0 - O0o
 oo0 = '%slogin.php?do=login' % ooO0OO000o
 o00 = OoO000
 o00 . update ( { 'Referer' : o0o0OOO0o0 } )
 o00 . update ( { 'Content-Type' : 'application/x-www-form-urlencoded' } )
 requests2 . post ( oo0 , data = o0 , headers = o00 , cookies = requests2 . cookies )
 if 95 - 95: iiI + ii1II11I1ii1I . iii1II11ii / iiI
 O000oo0O = '%sforum.php' % ooO0OO000o
 OOOO = OoO000
 OOOO . update ( { 'Referer' : oo0 } )
 ooOOOo0oo0O0 = requests2 . get ( O000oo0O , headers = OOOO , cookies = requests2 . cookies ) . text
 i11i1 = re . search ( "document.cookie.indexOf\('sucuri_uidc=(.+?)'\)" , ooOOOo0oo0O0 )
 if i11i1 :
  i11i1 = i11i1 . group ( 1 )
  requests2 . cookies . update ( { 'sucuri_uidc' : i11i1 } )
  ooOOOo0oo0O0 = requests2 . get ( O000oo0O , headers = OOOO , cookies = requests2 . cookies ) . text
  if 29 - 29: o00ooo0 % i11iII1iiI + iii11iiII / iiIIIII1i1iI + IiIii1Ii1IIi * iiIIIII1i1iI
 while 'The administrators want you to view a thread before you continue to browse the forum.' in ooOOOo0oo0O0 :
  i1I1iI = re . search ( 'showthread\.php\?t=(.+?)"' , ooOOOo0oo0O0 ) . group ( 1 )
  oo0OooOOo0 = '%sshowthread.php?t=%s' % ( ooO0OO000o , i1I1iI )
  o0O = OoO000
  OOOO . update ( { 'Referer' : O000oo0O } )
  ooOOOo0oo0O0 = requests2 . get ( oo0OooOOo0 , headers = o0O , cookies = requests2 . cookies ) . text
  if 72 - 72: I11 / iIiiiI1IiI1I1 * iI1Ii11111iIi - O0o
  OOOO . update ( { 'Referer' : oo0OooOOo0 } )
  ooOOOo0oo0O0 = requests2 . get ( O000oo0O , headers = OOOO , cookies = requests2 . cookies ) . text
  if 51 - 51: iii1II11ii * ii1II11I1ii1I % iiIIIII1i1iI * iii1II11ii % o00ooo0 / iii11iiII
 iIIIIii1 = re . search ( '<h2 class=[\'"]{1}forumtitle[\'"]{1}><a href=[\'"]{1}(.+?)[\'"]{1}>SM TV FREE</a></h2>' , ooOOOo0oo0O0 )
 oo000OO00Oo = re . search ( '<h2 class=[\'"]{1}forumtitle[\'"]{1}><a href=[\'"]{1}(.+?)[\'"]{1}>LIVE PREMIUM CHANNELS</a></h2>' , ooOOOo0oo0O0 )
 if 51 - 51: iiiii11iII1 * iiIIIII1i1iI + O0Oooo00 + ii1II11I1ii1I
 if not iIIIIii1 and not oo000OO00Oo :
  O0O0OO0O0O0 . add_directory ( { 'mode' : 'DUMMY' , 'dir_end' : 'false' } , { 'title' : 'Sign up @ [COLOR blue]%s[/COLOR]' % ooO0OO000o } )
 else :
  if iIIIIii1 :
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'live_free' , 'title' : 'Free Streams' , 'url' : '%s%s' % ( ooO0OO000o , iIIIIii1 . group ( 1 ) ) } , { 'title' : 'Free Streams' } )
   if 66 - 66: oO0o0ooO0
  if oo000OO00Oo :
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'live_elite' , 'title' : 'ELiTE Streams' , 'url' : '%s%s' % ( ooO0OO000o , oo000OO00Oo . group ( 1 ) ) } , { 'title' : 'ELiTE Streams' } )
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'vod_elite' , 'title' : 'Video On-Demand' , 'url' : '%s%s' % ( ooO0OO000o , 'forum.php' ) } , { 'title' : 'Video On-Demand' } )
  else :
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'DIALOG' , 'dlg_title' : 'Sports Mafia - [COLOR red]ELiTE+ Pass Required.[/COLOR]' ,
 'dlg_line1' : '[COLOR gold]ELiTE+ Pass[/COLOR] is required to watch ELiTE Streams.' , 'dlg_line2' : 'Please purchase ELiTE+ Pass at: [COLOR blue]http://sportsmafia.tv/[/COLOR]' ,
 'title' : 'ELiTE Streams' , 'dir_end' : 'false' } , { 'title' : 'ELiTE Streams' } )
   if 97 - 97: Oo00O0 % iiiii11iII1 * iiiii11iII1
def i11iiI111I ( requests2 , cookies ) :
 ooOOOo0oo0O0 = requests2 . get ( o0OOO , headers = OoO000 , cookies = cookies ) . text
 return ooOOOo0oo0O0
 if 10 - 10: ii1II11I1ii1I * O0o % oo00 . iii1II11ii
def iI1ii1Ii ( requests2 , cookies ) :
 oooo000 = OoO000
 oooo000 . update ( { 'Referer' : iIiiiI } )
 if 16 - 16: o00ooo0 + ii1II11I1ii1I - iii1II11ii
 ooOOOo0oo0O0 = requests2 . get ( o0OOO , headers = oooo000 , cookies = cookies ) . text
 if 85 - 85: oO0o0ooO0 + iIiiiI1IiI1I1
 return ooOOOo0oo0O0
 if 58 - 58: iii1II11ii * IiIii1Ii1IIi * o00ooo0 / IiIii1Ii1IIi
def oO0o0OOOO ( text ) :
 text = re . sub ( '&nbsp;' , ' ' , text )
 text = re . sub ( '\s+' , ' ' , text )
 text = re . sub ( '[ ]{2,}' , ' ' , text )
 return text
 if 68 - 68: I11 - O0o - i11iII1iiI - o00ooo0 + O0Oooo00
 if 10 - 10: IiII1IiiIiI1 % ii1I
def O00o0O00 ( ) :
 import time
 ii111111I1iII = time . time ( )
 if 68 - 68: I11 - ii1I * i11iIiiIii / o00ooo0 * O0o
 i1iIi1iIi1i = 0
 if 46 - 46: O0o % O0Oooo00 + ii1II11I1ii1I . oO0o0ooO0 . ii1II11I1ii1I
 if time . localtime ( ii111111I1iII ) . tm_isdst and time . daylight :
  i1iIi1iIi1i = time . altzone
 else :
  i1iIi1iIi1i = time . timezone
  if 96 - 96: iI1Ii11111iIi
 i1iIi1iIi1i = i1iIi1iIi1i / 60 / 60 * - 1
 if 45 - 45: iiI * iiIIIII1i1iI % iI1Ii11111iIi * IiII1IiiIiI1 + I11 . oO0o0ooO0
 return i1iIi1iIi1i
 if 67 - 67: i11iIiiIii - iIiiiI1IiI1I1 % o00ooo0 . iiI
def o0oo ( ) :
 if 91 - 91: iiiii11iII1
 import htmlcleaner
 import requests as requests2
 ooOOOo0oo0O0 = htmlcleaner . clean2 ( requests2 . get ( 'http://sportsmafiashedule.weebly.com/shedule.html' ) . text , True , True )
 if 15 - 15: iii1II11ii
 Iiooo0O = '%d.%m.%Y %H:%M'
 if 75 - 75: iiIIIII1i1iI % iiIIIII1i1iI . O0o
 III1iII1I1ii = Oo0Ooo . getSetting ( 'timeformat' )
 oOOo0 = Oo0Ooo . getSetting ( 'timezonesource' )
 oo00O00oO = O00o0O00 ( ) if oOOo0 == '0' else int ( Oo0Ooo . getSetting ( 'timezone' ) )
 iIiIIIi = '%I:%M %p' if III1iII1I1ii == '0' else '%H:%M'
 if 93 - 93: I11
 i1IIIiiII1 = [ ]
 if 87 - 87: Oo00O0 * o00ooo0 + IiIii1Ii1IIi / ii1I / I11
 ooOOOo0oo0O0 = re . search ( '(?s)<body(.*)' , ooOOOo0oo0O0 ) . group ( 1 )
 ooOOOo0oo0O0 = oO0o0OOOO ( ooOOOo0oo0O0 )
 if 37 - 37: I11 - iii11iiII * Oo00O0 % i11iIiiIii - O0o
 for o0oO in re . finditer ( '([0-9]{2}\.[0-9]{2}\.[0-9]{4} [0-9]{2}:[0-9]{2}) \- ([0-9]{2}\.[0-9]{2}\.[0-9]{4} [0-9]{2}:[0-9]{2}) \| \#([0-9]+) \| (.+?)<' , ooOOOo0oo0O0 ) :
  if 1 - 1: ii1II11I1ii1I - Oo00O0 . O0Oooo00 . ii1II11I1ii1I / iI1Ii11111iIi + O0Oooo00
  Ooo = o0oO . group ( 1 )
  OOOOo = o0oO . group ( 2 )
  if 76 - 76: ii1II11I1ii1I
  if 29 - 29: IiIii1Ii1IIi + iI1Ii11111iIi . i11iIiiIii - iIiiiI1IiI1I1 / ii1I
  try :
   i1 = ( datetime . datetime . strptime ( Ooo , Iiooo0O ) + datetime . timedelta ( hours = oo00O00oO ) )
  except TypeError :
   i1 = ( datetime . datetime . fromtimestamp ( time . mktime ( time . strptime ( Ooo , Iiooo0O ) ) ) + datetime . timedelta ( hours = oo00O00oO ) )
   if 18 - 18: iiIIIII1i1iI % I11 * iiI
  try :
   o0O0Oooo0O = ( datetime . datetime . strptime ( OOOOo , Iiooo0O ) + datetime . timedelta ( hours = oo00O00oO ) )
  except TypeError :
   o0O0Oooo0O = ( datetime . datetime . fromtimestamp ( time . mktime ( time . strptime ( OOOOo , Iiooo0O ) ) ) + datetime . timedelta ( hours = oo00O00oO ) )
   if 84 - 84: I11 . o00ooo0 / iI1Ii11111iIi - i11iII1iiI / IiII1IiiIiI1 / iiIIIII1i1iI
  II111iiiI1Ii = i1 . strftime ( '%A, %B %d' )
  o0O0OOO0Ooo = i1 . time ( ) . strftime ( iIiIIIi )
  iiIiI = o0O0Oooo0O . time ( ) . strftime ( iIiIIIi )
  I1 = 'Channel %d' % int ( o0oO . group ( 3 ) . strip ( ) )
  OOO00O0O = o0oO . group ( 4 ) . strip ( )
  if 33 - 33: iiI . iiiii11iII1 . i11iII1iiI
  i1IIIiiII1 . append ( ( II111iiiI1Ii , i1 , o0O0OOO0Ooo , o0O0Oooo0O , iiIiI , I1 , OOO00O0O ) )
  if 72 - 72: iIiiiI1IiI1I1 / ii1II11I1ii1I + IiII1IiiIiI1 - iI1Ii11111iIi
 return i1IIIiiII1
 if 29 - 29: o00ooo0 + Oo00O0 % iiI
def I1I11 ( requests2 , cookies ) :
 II1 = requests2 . get ( o0OOO , headers = OoO000 , cookies = cookies )
 ooOOOo0oo0O0 = II1 . text
 import re
 o0oO00000 = False
 for OOOOoo0Oo in re . finditer ( '(?s)<div class=[\'"]{1}(forumrow.+?)[\'"]{1}.+?<h2 class=[\'"]{1}forumtitle[\'"]{1}><a href=[\'"]{1}(.+?)[\'"]{1}>(.+?)</a>' , ooOOOo0oo0O0 ) :
  o0oO00000 = True
  ii111iI1iIi1 = OOOOoo0Oo . group ( 1 )
  OOO = ''
  if 'table' in ii111iI1iIi1 :
   OOO = '>> '
  oo0OOo0 = '%s%s' % ( ooO0OO000o , OOOOoo0Oo . group ( 2 ) )
  I11IiI = OOOOoo0Oo . group ( 3 )
  O0O0OO0O0O0 . add_directory ( { 'mode' : 'vod_section' , 'title' : I11IiI , 'url' : oo0OOo0 } , { 'title' : OOO + I11IiI } )
  if 53 - 53: I11 % iii1II11ii . iiiii11iII1 - ii1I - iiiii11iII1 * iii1II11ii
 if o0oO00000 :
  O0O0OO0O0O0 . add_directory ( { 'mode' : 'DUMMY' , 'dir_end' : 'false' } , { 'title' : '' } )
  if 77 - 77: ii1I * ii1II11I1ii1I
 for OOOOoo0Oo in re . finditer ( '(?s)<a class=[\'"]{1}title[\'"]{1} href=[\'"]{1}(.+?)[\'"]{1}.+?>(.+?)</a>' , ooOOOo0oo0O0 ) :
  oo0OOo0 = '%s%s' % ( ooO0OO000o , OOOOoo0Oo . group ( 1 ) )
  I11IiI = OOOOoo0Oo . group ( 2 )
  if 95 - 95: i11iII1iiI + i11iIiiIii
  O0O0OO0O0O0 . add_video_item ( { 'mode' : 'vod' , 'play' : 'true' , 'url' : oo0OOo0 , 'title' : I11IiI } , { 'title' : I11IiI } )
  if 6 - 6: iii11iiII / i11iIiiIii + I11 * Oo00O0
def o00o0 ( requests2 , cookies ) :
 II1 = requests2 . get ( o0OOO , headers = OoO000 , cookies = cookies )
 ooOOOo0oo0O0 = II1 . text
 import re
 OOOOoo0Oo = re . search ( '(?s)>SM ELiTE SECTiON<(.+?)<span class="forumtitle">' , ooOOOo0oo0O0 )
 if OOOOoo0Oo :
  OOOOoo0Oo = OOOOoo0Oo . group ( 1 )
  for ii in re . finditer ( '<h2 class=[\'"]{1}forumtitle[\'"]{1}><a href=[\'"]{1}(.+?)[\'"]{1}>(.+?)</a>' , OOOOoo0Oo ) :
   oo0OOo0 = '%s%s' % ( ooO0OO000o , ii . group ( 1 ) )
   I11IiI = ii . group ( 2 )
   OOooooO0Oo = I11IiI . lower ( )
   if 91 - 91: iiIIIII1i1iI . ii1I / Oo00O0 + iIiiiI1IiI1I1
   if 'channels' in OOooooO0Oo or 'streams' in OOooooO0Oo or 'request' in OOooooO0Oo or 'html' in OOooooO0Oo : continue
   if 42 - 42: iii11iiII . iiIIIII1i1iI . iii11iiII - o00ooo0
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'vod_section' , 'title' : I11IiI , 'url' : oo0OOo0 } , { 'title' : I11IiI } )
   if 40 - 40: iii11iiII - i11iIiiIii / oo00
   if 35 - 35: oo00 - i11iII1iiI % iiIIIII1i1iI . IiII1IiiIiI1 % oo00
def I1i1Iiiii ( requests2 , cookies ) :
 if 94 - 94: iiIIIII1i1iI * oo00 / iI1Ii11111iIi / oo00
 oO0O0OO0O = { }
 OO = { }
 OoOoO = { }
 Ii1I1i = { }
 if 99 - 99: Oo00O0 . I11 + iii11iiII % Oo00O0 . i11iIiiIii % iiI
 oOO00O = datetime . datetime . now ( )
 i1IIIiiII1 = o0oo ( )
 for II111iiiI1Ii , OOOoo0OO , o0O0OOO0Ooo , oO0o0 , iiIiI , I1 , OOO00O0O in i1IIIiiII1 :
  if oOO00O > OOOoo0OO and oOO00O > oO0o0 : continue
  if oO0O0OO0O . get ( I1 + ' - ' , None ) != None : continue
  if oOO00O >= OOOoo0OO and oOO00O <= oO0o0 :
   oO0O0OO0O . update ( { I1 + ' - ' : OOO00O0O } )
   OO . update ( { I1 + ' - ' : ( II111iiiI1Ii , OOOoo0OO , o0O0OOO0Ooo , oO0o0 , iiIiI , I1 , OOO00O0O ) } )
   if 50 - 50: iiiii11iII1
 II1 = requests2 . get ( o0OOO , headers = OoO000 , cookies = cookies )
 ooOOOo0oo0O0 = II1 . text
 import re
 Ii11iIi = re . search ( '<iframe src=[\'"]{1}(.+?)[\'"]{1}' , ooOOOo0oo0O0 )
 if Ii11iIi :
  O00O0Oooo0oO = Ii11iIi . group ( 1 )
  IIii11I1 = OoO000
  if 83 - 83: iii11iiII
  IIii11I1 . update ( { 'Referer' : II1 . url } )
  oO00Oo0O0o = requests2 . get ( O00O0Oooo0oO , headers = IIii11I1 , cookies = cookies ) . text
  oO00Oo0O0o = oO0o0OOOO ( oO00Oo0O0o )
  if 13 - 13: IiII1IiiIiI1
  for I1 in re . finditer ( '<a href=[\'"]{1}(http\://sportsmafia\.tv/view\.php\?pg=.+?)[\'"]{1}>(.+?)</a>' , oO00Oo0O0o ) :
   I111iI = re . sub ( '<.+?>' , '' , I1 . group ( 2 ) )
   I111iI = I111iI + '[COLOR gold]' + oO0O0OO0O . get ( I111iI , '' ) + '[/COLOR]'
   O0O0OO0O0O0 . add_video_item ( { 'mode' : 'live' , 'play' : 'true' , 'url' : I1 . group ( 1 ) , 'referer' : O00O0Oooo0oO , 'title' : I111iI } , { 'title' : I111iI } )
   if 56 - 56: i11iII1iiI
   if 54 - 54: O0o / IiIii1Ii1IIi . Oo00O0 % I11
def OoO0OOOOo0O ( ) :
 if 81 - 81: iiI / ii1II11I1ii1I . iIiiiI1IiI1I1 + i11iII1iiI - O0Oooo00
 oOO00O = datetime . datetime . now ( )
 if 74 - 74: ii1I * o00ooo0 + oO0o0ooO0 / iIiiiI1IiI1I1 / iii1II11ii . iI1Ii11111iIi
 i1IIIiiII1 = o0oo ( )
 if 62 - 62: IiII1IiiIiI1 * i11iII1iiI
 oOOOoo0O0oO = ''
 for II111iiiI1Ii , OOOoo0OO , o0O0OOO0Ooo , oO0o0 , iiIiI , I1 , OOO00O0O in i1IIIiiII1 :
  if oOO00O > OOOoo0OO and oOO00O > oO0o0 : continue
  if II111iiiI1Ii . lower ( ) != oOOOoo0O0oO :
   if len ( oOOOoo0O0oO ) > 0 :
    O0O0OO0O0O0 . add_directory ( { 'mode' : 'DUMMY' , 'dir_end' : 'false' } , { 'title' : '' } )
    if 6 - 6: IiIii1Ii1IIi * iiIIIII1i1iI + I11
   oOOOoo0O0oO = II111iiiI1Ii . lower ( )
   O0O0OO0O0O0 . add_directory ( { 'mode' : 'DUMMY' , 'dir_end' : 'false' } , { 'title' : '[B][COLOR white]%s[/COLOR][/B]' % II111iiiI1Ii } )
   if 44 - 44: oo00 % ii1II11I1ii1I + IiII1IiiIiI1 - iiI - oo00 - iii1II11ii
  O0O0OO0O0O0 . add_directory ( { 'mode' : 'DUMMY' , 'dir_end' : 'false' } ,
 { 'title' : '+- [COLOR gold][%s-%s] [/COLOR][COLOR white][B]- %s -[/B][/COLOR][COLOR grey] %s[/COLOR]' % ( o0O0OOO0Ooo , iiIiI , I1 , OOO00O0O ) } )
  if 99 - 99: iii11iiII . oo00 + O0o + IiII1IiiIiI1 % iiIIIII1i1iI
import requests as req
requests2 = req . Session ( )
if o0OoOoOO00 != 'main' :
 ooO = o0oO0o00oo ( I1I11I1I1I )
 if 46 - 46: i11iII1iiI - IiII1IiiIiI1 - O0Oooo00 * iii1II11ii
if I11i :
 if o0OoOoOO00 == 'live' : ooOOOo0oo0O0 = iI1ii1Ii ( requests2 , ooO )
 elif o0OoOoOO00 == 'vod' : ooOOOo0oo0O0 = i11iiI111I ( requests2 , ooO )
 if 34 - 34: O0Oooo00 - I11 / IiIii1Ii1IIi + o00ooo0 * oo00
 import re
 import urllib
 if 73 - 73: oO0o0ooO0 . oo00 * o00ooo0 % o00ooo0 % IiII1IiiIiI1
 if 63 - 63: ii1I * i11iIiiIii % ii1I * i11iIiiIii
 if 32 - 32: IiIii1Ii1IIi
 if 42 - 42: iiiii11iII1 * iiI % iIiiiI1IiI1I1 . IiIii1Ii1IIi / iiIIIII1i1iI
 if 32 - 32: i11iII1iiI * iI1Ii11111iIi
 if 78 - 78: IiIii1Ii1IIi - IiII1IiiIiI1 - o00ooo0 / iii11iiII / iii1II11ii
 if 29 - 29: i11iII1iiI % i11iII1iiI
 if 94 - 94: ii1I / iI1Ii11111iIi % I11 * I11 * iii1II11ii
 if 29 - 29: ii1II11I1ii1I + oO0o0ooO0 / iiIIIII1i1iI / IiIii1Ii1IIi * ii1I
 if 62 - 62: IiIii1Ii1IIi / Oo00O0 - ii1II11I1ii1I . O0Oooo00
 if 11 - 11: o00ooo0 . ii1II11I1ii1I * iiiii11iII1 * IiII1IiiIiI1 + iii11iiII
 if 33 - 33: iiI * iiIIIII1i1iI - O0o % O0o
 if 18 - 18: O0o / iI1Ii11111iIi * O0o + O0o * i11iIiiIii * o00ooo0
 I1II1 = re . search ( 'playlist: [\'"](.+?)[\'"]' , ooOOOo0oo0O0 )
 if I1II1 :
  I1II1 = urllib . unquote ( I1II1 . group ( 1 ) )
  oooo000 = OoO000
  oooo000 . update ( { 'Referer' : iIiiiI } )
  ooOOOo0oo0O0 = requests2 . get ( I1II1 , headers = oooo000 , cookies = ooO ) . text
  if 86 - 86: ii1I / oO0o0ooO0 . iii1II11ii
  Oo0o0000o0o0 = xbmcgui . Dialog ( )
  II1i111Ii1i = [ ]
  iii1 = [ ]
  for ooO0oooOO0 in re . finditer ( '(?s)<item>.+?<title>(.+?)</title>.+?<jwplayer:source file=[\'"](.+?)[\'"] />.+?</item>' , ooOOOo0oo0O0 ) :
   II1i111Ii1i . append ( ooO0oooOO0 . group ( 1 ) )
   iii1 . append ( ooO0oooOO0 . group ( 2 ) )
  o0o = len ( II1i111Ii1i )
  oo0oOOOoo00 = None
 else :
  o0o = 0
  iiIiIIIiiI = re . search ( '(http://[^\'",&;]+?\.mp4)' , ooOOOo0oo0O0 )
  if iiIiIIIiiI :
   oo0oOOOoo00 = iiIiIIIiiI . group ( 1 )
  else :
   iiI1IIIi = re . search ( 'streamer=(.+?)&' , ooOOOo0oo0O0 )
   if iiI1IIIi :
    iiI1IIIi = iiI1IIIi . group ( 1 )
    II11IiIi11 = re . search ( 'file=(.+?)&' , ooOOOo0oo0O0 )
    if II11IiIi11 :
     II11IiIi11 = II11IiIi11 . group ( 1 )
     IIOOO0O00O0OOOO = o0OOO
     I1iiii1I = re . search ( '(http://[^\'",&;]+?\.swf)' , ooOOOo0oo0O0 )
     if I1iiii1I :
      I1iiii1I = I1iiii1I . group ( 1 )
      oo0oOOOoo00 = '%s playpath=%s pageUrl=%s swfUrl=%s live=false' % ( iiI1IIIi , II11IiIi11 , IIOOO0O00O0OOOO , I1iiii1I )
     else :
      oo0oOOOoo00 = 'NOTFOUND'
    else :
     oo0oOOOoo00 = 'NOTFOUND'
   else :
    oo0oOOOoo00 = 'NOTFOUND'
    if 54 - 54: i11iII1iiI / O0o / ii1I % ii1II11I1ii1I % oo00
 if ( o0o == 1 ) :
  oo0oOOOoo00 = iii1 [ 0 ]
 elif ( o0o > 1 ) :
  oooO = Oo0o0000o0o0 . select ( 'Please select a server' , II1i111Ii1i )
  if oooO >= 0 :
   oo0oOOOoo00 = iii1 [ oooO ]
 if oo0oOOOoo00 :
  if oo0oOOOoo00 == 'NOTFOUND' :
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , False , xbmcgui . ListItem ( ) )
  else :
   if oo0oOOOoo00 . startswith ( 'rtmp' ) and 'timeout' not in oo0oOOOoo00 :
    oo0oOOOoo00 = oo0oOOOoo00 + ' timeout=20'
   oOoo0oOo00 = xbmcgui . ListItem ( path = oo0oOOOoo00 , iconImage = O0O , thumbnailImage = O0O )
   if Oo :
    oOoo0oOo00 . setInfo ( "Video" , { 'title' : Oo } )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOoo0oOo00 )
elif o0OoOoOO00 == 'main' :
 O0O0OO0O0O0 . add_directory ( { 'mode' : 'schedule' } , { 'title' : '[COLOR yellow]*** Schedule ***[/COLOR]' } )
 o0OOOOO00o0O0 ( requests2 )
 iIi ( requests2 . cookies , I1I11I1I1I )
elif o0OoOoOO00 == 'DIALOG' :
 Oo0o0000o0o0 = xbmcgui . Dialog ( )
 Oo0o0000o0o0 . ok ( O0O0OO0O0O0 . queries . get ( 'dlg_title' , "Sports Mafia" ) , O0O0OO0O0O0 . queries . get ( 'dlg_line1' , '' ) ,
 O0O0OO0O0O0 . queries . get ( 'dlg_line2' , '' ) , O0O0OO0O0O0 . queries . get ( 'dlg_line3' , '' ) )
elif o0OoOoOO00 . startswith ( 'live_' ) :
 I1i1Iiiii ( requests2 , ooO )
elif o0OoOoOO00 == 'schedule' :
 OoO0OOOOo0O ( )
elif o0OoOoOO00 == 'vod_elite' :
 o00o0 ( requests2 , ooO )
elif o0OoOoOO00 == 'vod_section' :
 I1I11 ( requests2 , ooO )
 if 32 - 32: i11iII1iiI % ii1I / iIiiiI1IiI1I1 - i11iII1iiI
if I1ii11iIi11i == 'true' :
 try : xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) , updateListing = ( I1IiI == 'true' ) )
 except : pass
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
