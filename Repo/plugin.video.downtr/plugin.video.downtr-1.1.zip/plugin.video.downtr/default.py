import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,settings,urlresolver
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
from metahandler import metahandlers
from metahandler import metacontainers
from universal import favorites
from universal import _common as univ_common
from universal import playbackengine
from settings import *
import time,datetime
import base64

############################################################################################################################################################

icon = 'icon.png'
fanart = 'fanart.png'
fav = favorites.Favorites('plugin.video.downtr', sys.argv)
grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.downtr'
local = xbmcaddon.Addon(id=addon_id)
downtrpath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = downtrpath+'/art'
net = Net()
cookie_path = os.path.join(datapath, 'cookies')                 
cookie_jar = os.path.join(cookie_path, "cookiejar.lwp")
if os.path.exists(cookie_path) == False:                        
    os.makedirs(cookie_path)
#SUBSCRIPTION_FILE = settings.subscription_file()
#SUBSCRIPTIONS_ACTIVATED = settings.subscription_update()
strdomain ="http://www.vidics.ch"
############################################################################################################################################################

IMDb_url = 'http://akas.imdb.com'
IMDbIT_url = 'http://akas.imdb.com/movies-in-theaters/?ref_=nb_mv_2_inth'
IMDb250_url = 'http://akas.imdb.com/search/title?groups=top_250&sort=user_rating&my_ratings=exclude'
kidzone_url = 'http://akas.imdb.com/search/title?genres=animation,family&title_type=feature,tv_movie'
kidzonetv_url = 'http://akas.imdb.com/search/title?genres=animation,family&title_type=tv_series,tv_special,mini_series'
IMDBTV_WATCHLIST = settings.imdbtv_watchlist_url()
IMDB_LIST = settings.imdb_list_url()

downtr_url = 'http://www.downtr.co/'
downtrtv_url = 'http://www.downtr.co/tv-shows/'
downtrmovies_url = 'http://www.downtr.co/movies/'
downtrmusic_url = 'http://www.downtr.co/music/'

#Metahandler
def GRABMETA(name,types,year=None):
        type = types
        if year=='': year=None
        EnableMeta = local.getSetting('Enable-Meta')
        #
        if year==None:
                try: year=re.search('\s*\((\d\d\d\d)\)',name).group(1)
                except: year=None
        if year is not None: name=name.replace(' ('+year+')','').replace('('+year+')','')
        #
        if EnableMeta == 'true':
                if 'Movie' in type:
                        ### grab.get_meta(media_type, name, imdb_id='', tmdb_id='', year='', overlay=6)
                        meta = grab.get_meta('movie',name,'',None,year,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                elif 'tvshow' in type:
                        meta = grab.get_meta('tvshow',name,'','',year,overlay=6)
                        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],'backdrop_url': meta['backdrop_url'],'status': meta['status']}
        else: infoLabels=[]
        return infoLabels

def get_html(page_url):

        html = net.http_GET(page_url).content

        import HTMLParser
        h = HTMLParser.HTMLParser()
        html = h.unescape(html)
        return html.encode('utf-8')

def _FixText(t):
        if ("&amp;"  in t): t=t.replace('&amp;'  ,'&')#&amp;#x27;
        if ("&nbsp;" in t): t=t.replace('&nbsp;' ," ")
        if ('&#' in t) and (';' in t):
                t=t.replace("&#8211;",";").replace("&#8216;","'").replace("&#8217;","'").replace('&#8220;','"').replace('&#8221;','"').replace('&#215;' ,'x').replace('&#x27;' ,"'").replace('&#xF4;' ,"o").replace('&#xb7;' ,"-").replace('&#xFB;' ,"u").replace('&#xE0;' ,"a").replace('&#xE9;' ,"e").replace('&#xE2;' ,"a").replace('&#0421;',"")
                if ('&#' in t) and (';' in t):
                        try:            matches=re.compile('&#(.+?);').findall(t)
                        except: matches=''
                        if (matches is not ''):
                                for match in matches:
                                        if (match is not '') and (match is not ' ') and ("&#"+match+";" in t): t=t.replace("&#"+match+";" ,"")
        for i in xrange(127,256): t=t.replace(chr(i),"")
        try: t=t.encode('ascii', 'ignore'); t=t.decode('iso-8859-1')
        except: t=t
        return t



######################################################################################################################################################

 #      addDir(name,url,mode,iconimage,types,favtype) mode is where it tells the plugin where to go scroll to bottom to see where mode is
def CATEGORIES():
        addDir('Movies',downtrmovies_url,1,art_('Movies','Main Menu'),None,'')
        addDir('TV Shows',downtrtv_url,1,art_('TV Shows','Sub Menus'),None,'')
        addDir('Music',downtrmusic_url,1,art_('Music','Sub Menus'),None,'')
        addDir('Search',downtr_url,5,art_('Search','Sub Menus'),None,'')
        fav.add_my_fav_directory(img=art_('Favorites','Main Menu'))
        addDir('Settings','http://',309,art_('Settings','Main Menu'),None,'')
        addDir('Resolver Settings',downtr_url,310,'',None,'')
        set_view('list') 
       
       
##############################################################################################################################

def downtrIndex(url):
        html = get_html(url)
        match =  re.compile('<div class="title"><a href="(.+?)">(.+?)</a></div>.+?<img src=".+?" data-original="(.+?)"',re.DOTALL).findall(html)
        for url, name, iconimage in match:
                addDir(name,url,30,iconimage,None,'Movies')
        nextpage = re.compile('<span class="next"><a href="(.+?)">Next</a></span>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'',None,'')

def URLLINKS(url,name):
        html = get_html(url)
        match=re.compile('<div align="center"><!--colorstart:#800080--><span style="color:#800080"><!--/colorstart--><b><u>Download From (.+?)</u></b><!--colorend--></span><!--/colorend--></div><br /><br /><!--QuoteBegin--><div class="quote"><!--QuoteEBegin--><div align="center">(.+?)</div>').findall(html)
        match2=re.compile('<b>Download (.+?)</b><br /><a href="(.+?)" target="_blank">.+?</a>').findall(html)
        match3=re.compile('<b>.+?</b>:<br /><a href="(.+?)">(.+?)</a><br />').findall(html)
        match4=re.compile('<b>Download From (.+?)</b><br /><br />(.+?)<br />').findall(html)
        for name, url in match+match2+match3+match4:
            name=removeCollectiveText(name)
            addDir(name,url,31,'',None,'')
                

        
####################################################################################################################################################################################                
                         
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link

def removeCollectiveText(text):
        text= re.sub('\[COLOR.*?\[/COLOR\]','',text,re.I|re.DOTALL).strip()
        return re.sub('[(\d{4})]','',text)#name=removeCollectiveText(name)

def add_contextsearchmenu(title, video_type):
    contextmenuitems = []

    if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.collective'):
        contextmenuitems.append(('Search [COLOR blue]The Collective[/COLOR] (Movies)', 'XBMC.Container.Update(%s?mode=12&url=url&name=%s)' % (
            'plugin://plugin.video.collective/', title)))
    if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.collective'):
        contextmenuitems.append(('Search [COLOR blue]The Collective[/COLOR] (TV)', 'XBMC.Container.Update(%s?mode=30&url=url&name=%s)' % (
            'plugin://plugin.video.collective/', title)))
        

    return contextmenuitems

###########################################################################################################################################################################

def resolve_url(url):
        return resolvers.resolve_url(url)

def STREAM(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
	print streamlink
	addLink('Click to [COLOR blue]Play[/COLOR]',streamlink,'')
	set_view('list')

##############################################################################################################################################################################

################################################################################################################################################################
        
def SEARCHTITLES(url):
        searchStr = ''
        keyboard = xbmc.Keyboard(searchStr, "Search")
        keyboard.doModal()
        if (keyboard.isConfirmed() == False):
                return
        searchstring = keyboard.getText()
        if len(searchstring) == 0:
                return
        newStr = searchstring.replace(' ','+')
        html = get_html(downtr_url+'?do=search&subaction=search&story='+newStr)#http://www.downtr.co/?do=search&subaction=search&story=man+of+steel
        
        match =  re.compile('<div class="name"><h2>.+?: <a href="(.+?)" >(.+?)</a></h2></div>.+?src=".+?" data-original="(.+?)"',re.DOTALL).findall(html)
        for url, name, iconimage in match:
                addDir(name,url,30,iconimage,None,'Movies')
        nextpage = re.compile('<span class="next"><a href="(.+?)">Next</a></span>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'',None,'')


def UNIVERSALSEARCH(name):
        EnableMeta = local.getSetting('Enable-Meta')
        newStr = searchstring.replace(' ','+')
        html = get_html(viooz_url+'?do=search&subaction=search&story='+newStr)#http://www.downtr.co/?do=search&subaction=search&story=man+of+steel
        
        match =  re.compile('<a href=".+?"><img src="(.+?)".+?<h3 class="title_grid" title="(.+?)">.+?</h3>.+?<span class="title_list"><a href="(.+?)" title=".+?">.+?</a></span>',re.DOTALL).findall(html)
        for iconimage, name, url in match:
                if EnableMeta == 'true':  addDir(name,url,25,'','Movie','Movies')
                if EnableMeta == 'false': addDir(name,url,25,iconimage,None,'Movies')
        nextpage = re.compile('<span class="pagination-actif">.+?</span> <a href="(.+?)">.+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'',None,'')

def SEARCH():
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search Music...XBMCHUB.COM')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText() .replace(' ','+')  # sometimes you need to replace spaces with + or %20
                if search_entered == None:
                        return False
        return search_entered 

#######################################################################################################################################################################

def create_strm_file(name, data, imdb_id, mode, dir_path):
    try:
        strm_string = create_url(name, mode, data=data, imdb_id=imdb_id)
        filename = clean_file_name("%s.strm" % name)
        path = os.path.join(dir_path, filename)
        stream_file = open(path, 'w')
        stream_file.write(strm_string)
        stream_file.close()
    except:
        xbmc.log("Error while creating strm file for : " + name)

def remove_strm_file(name, dir_path):
    try:
        filename = "%s.strm" % (clean_file_name(name, use_blanks=False))
        path = os.path.join(dir_path, filename)
        os.remove(path)
    except:
        xbmc.log("[Was unable to remove movie: %s" % (name)) 

#######################################################################################################################################################################

def smart_unicode(s):
        """credit : sfaxman"""
        if not s:
                return ''
        try:
                if not isinstance(s, basestring):
                        if hasattr(s, '__unicode__'):
                                s = unicode(s)
                        else:
                                s = unicode(str(s), 'UTF-8')
                elif not isinstance(s, unicode):
                        s = unicode(s, 'UTF-8')
        except:
                if not isinstance(s, basestring):
                        if hasattr(s, '__unicode__'):
                                s = unicode(s)
                        else:
                                s = unicode(str(s), 'ISO-8859-1')
                elif not isinstance(s, unicode):
                        s = unicode(s, 'ISO-8859-1')
        return s

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	return ok

def RemoveHTML(strhtml):
            html_re = re.compile(r'<[^>]+>')
            strhtml=html_re.sub('', strhtml)
            return strhtml

def addDirContext(name,url,mode,iconimage,plot="",vidtype="", cm=[]):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&vidtype="+vidtype
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
        if(len(cm)==0):
                contextMenuItems = AddFavContext(vidtype, url, name, iconimage)
        else:
                contextMenuItems=cm
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDirsehedule(name,url,mode,iconimage,plot=""):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addDir(name,url,mode,iconimage,types,favtype):
        ok=True
        type = types
        if type != None: infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        try: liz.setProperty( "Fanart_Image", infoLabels['backdrop_url'] )
        except: t=''
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        #Universal Favorites
        if 'Movies' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Movies')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        elif 'TV-Shows' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='TV-Shows')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        else:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Other Favorites')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

#####################################################################################################################################################################

params=get_params()
url=None; name=None; mode=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        downtrIndex(url)

elif mode==2:
        print ""+url
        Mostviewsmovies(url)
        
elif mode==3:
        print ""+url
        Randommovies(url)

elif mode==4:
        print ""+url
        OPEN_URL(url)

elif mode==5:
        print ""+url
        SEARCHTITLES(url)

elif mode==6:
        print ''+url
        add_executeaddons(name)

elif mode==7:
        print ''+url
        IMDB_LISTS(url)

elif mode==8:
        print ''+url
        WATCH_TV_LIST(url)

elif mode==9:
        print ''+url
        IMDbInTheaters(url)

elif mode==10:
        print ''+url
        IMDbcat()

elif mode==11:
        print ''+url
        add_executeaddonstv(name)

elif mode==12:
        print ''+url
        ALLTIMEIMDB(url)

elif mode==13:
        print ''+url
        WATCH_LIST_SEARCH(name,url)

elif mode==14:
        print ''+url
        IMDB_SEARCHTV(url)

elif mode==15:
        print ''+url
        IMDBGENRETV(url)

elif mode==16:
        print ''+url
        IMDbtvcat()

elif mode==17:
        print ''+url
        WATCH_MOVIE_LIST(url)

elif mode==18:
        print ''+url
        ALLTIMEIMDBTV(url)

elif mode==19:
        print ''+url
        UNIVERSALSEARCH(name)

elif mode==20:
        print ''+url
        UNIVERSALSEARCHTV(name)

elif mode==21:
        print ''+url
        IMDB_LISTSTV(url)

elif mode==22:
        print ''+url
        add_testexecuteaddons(name)

elif mode==23:
        print ''+url
        SEASONS(url)

elif mode==24:
        print ''+url
        EPISODES(url)

elif mode==25:
        print ''+url
        GetLinks(url)

elif mode==26:
        print ''+url
        STREAM(url)

elif mode==27:
        print ''+url
        WatchedCallback(name,url)

elif mode==28:
        print ''+url
        linkstr(url)

elif mode==29:
        print ''+url
        GetLinks3(name,url,infoLabels=None)

elif mode==30:
        print ''+url
        URLLINKS(url,name)

elif mode==31:
        print ''+url
        STREAM(url)

elif mode==309:
        print ''+url
        addon.addon.openSettings()

elif mode==310:
        print ''+url
        urlresolver.display_settings()

                
xbmcplugin.endOfDirectory(int(sys.argv[1]))
