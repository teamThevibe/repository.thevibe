# -*- coding: cp1254 -*-
# please visit http://www.iptvxtra.net

import xbmc,xbmcgui,xbmcplugin,sys
icondir = xbmc.translatePath("special://home/addons/plugin.audio.radiothai/icons/")
plugin_handle = int(sys.argv[1])

def add_video_item(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

add_video_item('http://203.150.224.142:8000/;stream.mp3',{ 'title': 'COOL Fahrenheit 93'},img=icondir + 'th_coolfahrenheit.png')
add_video_item('http://203.150.225.77:8200/;stream.mp3',{ 'title': 'COOL Celsius 93'},img=icondir + 'th_coolcelsius.png')
add_video_item('http://61.47.2.70:8014/;audio.mp3',{ 'title': 'City Radio Pattaya'},img=icondir + 'th_cityradiopattaya.png')
add_video_item('http://61.47.2.70:8064/;66154927294701stream.nsv',{ 'title': 'Fung Fung Fung'},img=icondir + 'th_fungfungfung.png')
add_video_item('http://radio.dwebsalehost.com:8066/;stream.nsv;93170808441937stream.nsv',{ 'title': 'Isaan Radio'},img=icondir + 'th_isaanradio.png')
add_video_item('http://atlanticthai.primcast.com:5898/;stream.mp3;97480614017695stream.nsv',{ 'title': 'Capitol.fm'},img=icondir + 'th_capitolfm.png')

xbmcplugin.endOfDirectory(plugin_handle)
xbmc.executebuiltin("Container.SetViewMode(500)")