script.module.trakt
======================

Python trakt.py library packed for Kodi.

See https://github.com/fuzeman/trakt.py
