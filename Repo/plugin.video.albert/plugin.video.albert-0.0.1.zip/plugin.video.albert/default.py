import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time


from threading import Timer
import json

PLUGIN='plugin.video.albert'
ADDON = xbmcaddon.Addon(id=PLUGIN)




def CATEGORIES():
        try:
            import random
            text=''
            twit = 'http://twitrss.me/twitter_user_to_rss/?user=@albertn198'
            #twit += '?%d' % (random.randint(1, 999999999999999999))
            link = OPEN_URL(twit)
            
            match=re.compile("<description><!\[CDATA\[(.+?)\]\]></description>",re.DOTALL).findall(link)
            status = cleanHex(match[0])
            addDir('[COLOR blue]***[/COLOR] [COLOR yellow]Twitter STATUS[/COLOR] [COLOR blue]***[/COLOR] - [COLOR orange]'+status.strip()+'[/COLOR]','url','','','','','')
        except:pass    
        link=OPEN_URL('https://raw.githubusercontent.com/albertn198/Albertn198Playlist/master/main.xml')
        match=re.compile('<name>(.+?)</name>.+?thumbnail>(.+?)</thumbnail.+?<link>(.+?)</link>',re.DOTALL).findall(link)
        for name , iconimage ,url in match:
            addDir(name,url,5,iconimage,'','','')


def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
        
        

       

  
          
        


def OnDemand(url):
    link = OPEN_URL(url)
    if '<poster>' in link:
        message=re.compile('<poster>(.+?)</poster.+?\n<fanart>.+?</fanart><thumbnail>(.+?)</thumbnail>').findall (link)
        for name , fanart ,iconimage in message:
            addLink(name,'url',iconimage,fanart)


    if '<name>' in link:
        LINK=link.split('<name')
        for p in LINK:
            try:
                name=re.compile('>(.+?)</name>').findall(p)[0]
                iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(p)[0]
                url=re.compile('<link>(.+?)</link>').findall(p)[0]
                addDir(name,url,5,iconimage,'','','','')        
            except:pass
            
    if '<item>' in link:
        LINKS=link.split('<item>')
        for p in LINKS:
            
            try:
                name=re.compile('title>(.+?)<').findall(p)[0]
                iconimage=re.compile('thumbnail>(.+?)<').findall(p)[0]
                p=p.replace('\n','').replace(' ','')
                url=re.compile('<link>(.+?)</link>').findall(p)[0]
                addDir(name,url,7,iconimage,'','','','')        
            except:pass


def GrabVK(url):
    html=OPEN_URL(url)
    r      ='"url(\d+)":"(.+?)"'
    name=[]
    url=[]
    match = re.compile(r,re.DOTALL).findall(html)
    for quality,stream in match:
        name.append(quality.replace('\\','')+'p')
        url.append(stream.replace('\/','/'))
    return url[xbmcgui.Dialog().select('Please Select Resolution', name)]
    


def PlayOnDemand(name,url,iconimage):

    
    if 'sublink' in url:
        match=re.compile('<sublink>(.+?)</sublink>').findall (url)
        
        names=[]
        urls=[]
        for URL in match:
            try:
                name=URL.split('http://')[1]
                title=name.split('/')[0]
                names.append(title.upper())
                urls.append(URL)
            except:pass
        url= urls[xbmcgui.Dialog().select('Please Select Source', names)]
        
        
    if not 'googlevideo' in url:
        if 'http://vk' in url:
            url=GrabVK(url)

        elif 'movreel' in url:
            import movreel
            url=movreel.solve(url)
        else:
            import urlresolver
            url=urlresolver.resolve(url)
            
         
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

 
    
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent' , "Magic Browser")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

            
            
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage,play,date,description,page=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
       
        if mode==7 :
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
          
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addLink(name,url,iconimage, fanart):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty("Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)

        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
date=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        play=urllib.unquote_plus(params["play"])
except:
        pass
try:
        date=urllib.unquote_plus(params["date"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        CATEGORIES()
               
elif mode==2:
        PLAY_STREAM(name,url,iconimage,play,description)
        
elif mode==3:
        REPLAY()
        
elif mode==4:
        GENRES(name,url)

elif mode==5:
        OnDemand(url)


elif mode==6:
        OnDemandLinks(url)

elif mode==7:
        PlayOnDemand(name,url,iconimage)         
        
elif mode==200:
        schedule(name,url,iconimage)
        
elif mode==201:
        fullguide(name,url,iconimage,description)
        
elif mode==202:
        Login()
        Show_Dialog()
        
elif mode==203:
        os.remove(cookie_jar)
        Show_Dialog()

elif mode==204:
        downloadchannel()      
        
elif mode==205:
        LOGOUT()

elif mode==1999:
        EVENTS()        
        
elif mode==2001:
        ADDON.openSettings()

elif mode==2003:
        GetMikey(url)     
        
elif mode==2004:
        PlayMikey(name,url,iconimage)        
        
else:
        #just in case mode is invalid 
        CATEGORIES()

               
xbmcplugin.endOfDirectory(int(sys.argv[1]))

