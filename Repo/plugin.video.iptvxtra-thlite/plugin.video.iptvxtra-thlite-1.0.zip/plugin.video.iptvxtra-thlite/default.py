# -*- coding: cp1254 -*-
# for more info please visit http://www.iptvxtra.net

import urllib2,xbmcplugin,xbmcgui,xbmc
from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSOAP

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
 
def main():
    link=get_url()
    soup = BeautifulSOAP(link, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
    items = soup.findAll("item")
    for item in items:
            try: videoTitle=item.title.string
            except: pass
            try: url=item.link.string + '|X-Forwarded-For=110.77.207.213'
            except: pass
            try: thumbnail=item.thumbnail.string                
            except: pass
            addLink(videoTitle,url,thumbnail)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    try:
        if not os.path.isfile(xbmc.translatePath("special://temp/0_thlite.fi")):
            open(xbmc.translatePath("special://temp/0_thlite.fi"), "a").close()
            xbmc.executebuiltin("Container.SetViewMode(500)") 
    except: pass
    sys.exit(0)
    
def addLink(name,url,iconimage):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", iconimage )
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def get_url():
        url = "http://srv1.iptvxtra.net/xbmc/xml/th-lite-streams.xml"
        response = urllib2.urlopen(url)
        link=response.read()
        response.close()
        return link

main()

