# -*- coding: utf-8 -*-
# please visit http://www.iptvxtra.net

import os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon

plugin_handle = int(sys.argv[1])
addonID = 'plugin.video.iptvxtra-servustv'
addon = xbmcaddon.Addon(id = addonID)
addonPath = addon.getAddonInfo('path')
icon1 = xbmc.translatePath( os.path.join( addonPath , 'icons/de.png' ) )
icon2 = xbmc.translatePath( os.path.join( addonPath , 'icons/at.png' ) )

def add_video(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

add_video('http://hdiosstv-f.akamaihd.net/i/servustvhdde_1@75540/master.m3u8|X-Forwarded-For=195.176.146.85',{ 'title': 'Servus TV - DE'}, icon1)
add_video('http://hdiosstv-f.akamaihd.net/i/servustvhd_1@51229/master.m3u8|X-Forwarded-For=195.176.146.85',{ 'title': 'Servus TV - AT'}, icon2)

xbmcplugin.endOfDirectory(plugin_handle)
sys.exit(0)
