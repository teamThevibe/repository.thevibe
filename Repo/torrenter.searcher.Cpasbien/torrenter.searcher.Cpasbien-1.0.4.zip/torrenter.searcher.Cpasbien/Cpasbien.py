# -*- coding: utf-8 -*-
'''
    Torrenter v2 plugin for XBMC/Kodi
    Copyright (C) 2012-2015 Vadim Skorba v1 - DiMartino v2
    http://forum.kodi.tv/showthread.php?tid=214366

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmcaddon
import os
import socket

import SearcherABC

import time
import re
import requests
from requests.adapters import HTTPAdapter
import execjs

try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse

DEFAULT_USER_AGENT = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:39.0) Gecko/20100101 Firefox/39.0"
JS_ENGINE = execjs.get().name

class Cpasbien(SearcherABC.SearcherABC):

    __torrenter_settings__ = xbmcaddon.Addon(id='plugin.video.torrenter')
    #__torrenter_language__ = __settings__.getLocalizedString
    #__torrenter_root__ = __torrenter_settings__.getAddonInfo('path')

    ROOT_PATH=os.path.dirname(__file__)
    addon_id=ROOT_PATH.replace('\\','/').rstrip('/').split('/')[-1]
    __settings__ = xbmcaddon.Addon(id=addon_id)
    __addonpath__ = __settings__.getAddonInfo('path')
    __version__ = __settings__.getAddonInfo('version')
    __plugin__ = __settings__.getAddonInfo('name') + " v." + __version__

    username = __settings__.getSetting("username")
    password = __settings__.getSetting("password")
    baseurl = 'www.cpasbien.pw' # TODO: change this!

    '''
    Setting the timeout
    '''
    torrenter_timeout_multi=int(sys.modules["__main__"].__settings__.getSetting("timeout"))
    timeout_multi=int(__settings__.getSetting("timeout"))

    '''
    Weight of source with this searcher provided. Will be multiplied on default weight.
    '''
    sourceWeight = 1

    '''
    Full path to image will shown as source image at result listing
    '''
    searchIcon = os.path.join(__addonpath__,'icon.png')

    '''
    Flag indicates is this source - magnet links source or not.
    '''

    @property
    def isMagnetLinkSource(self):
        return False

    '''
    Main method should be implemented for search process.
    Receives keyword and have to return dictionary of proper tuples:
    filesList.append((
        int(weight),# Calculated global weight of sources
        int(seeds),# Seeds count
        int(leechers),# Leechers count
        str(size),# Full torrent's content size (e.g. 3.04 GB)
        str(title),# Title (will be shown)
        str(link),# Link to the torrent/magnet
        str(image),# Path to image shown at the list
    ))
    '''

    def __init__(self):
        self.logout()

        if self.timeout_multi==0:
            socket.setdefaulttimeout(10+(10*self.torrenter_timeout_multi))
        else:
            socket.setdefaulttimeout(10+(10*(self.timeout_multi-1)))

        if self.__settings__.getSetting("usemirror")=='true':
            self.baseurl = self.__settings__.getSetting("baseurl")

        #self.debug=self.log

    def check_login(self, response, url):
        if not response:
            cookie = get_cookie_string(url)
            if cookie:
                sys.modules["__main__"].__settings__.setSetting("cpasbien-auth", str(cookie[0]))
            else:
                self.log('No cookie, cloudfail')
            return False
        else:
            return True


    def search(self, keyword):
        filesList = []
        response = None
        url = "http://%s/recherche/%s.html" % (self.baseurl, urllib.quote_plus(keyword).replace('&nbsp;', '-'))

        headers = [('User-Agent', DEFAULT_USER_AGENT),
                   ('Referer', 'http://%s' % self.baseurl), ('Accept-encoding', 'gzip'),
                   ('Cookie', str(sys.modules["__main__"].__settings__.getSetting("cpasbien-auth")))]
        response = self.makeRequest(url, headers=headers)
        self.debug(response)

        if not self.check_login(response, url):
            headers = [('User-Agent', DEFAULT_USER_AGENT),
                   ('Referer', 'http://%s' % self.baseurl), ('Accept-encoding', 'gzip'),
                   ('Cookie', str(sys.modules["__main__"].__settings__.getSetting("cpasbien-auth")))]
            response = self.makeRequest(url, headers=headers)
            self.debug(response)

        if None != response and 0 < len(response):
            regex = '<div class="ligne.+?</div></div>'
            regex_tr = r'/dl-torrent/films/.+?/(.+?).html" title=".+? class="titre">(.+?)</a><div class="poid">(.+?)</div><div class="up"><span class="seed_ok">(.+?)</span></div><div class="down">(.+?)</div></div>'
            for tr in re.compile(regex, re.DOTALL).findall(response):
                result=re.compile(regex_tr, re.DOTALL).findall(tr)
                self.debug(tr+' -> '+str(result))
                if result:
                    (link, title, size, seeds, leechers)=result[0]
                    torrentTitle = "%s [S\L: %s\%s]" % (title, seeds, leechers)
                    size = size.replace('&nbsp;', ' ')
                    link = 'http://'+self.baseurl + "/telechargement/" + link + ".torrent"
                    filesList.append((
                        int(int(self.sourceWeight) * int(seeds)),
                        int(seeds), int(leechers), size,
                        self.unescape(self.stripHtml(torrentTitle)),
                        self.__class__.__name__ + '::' + link,
                        self.searchIcon,
                    ))
        return filesList

    def getTorrentFile(self, url):
        headers = [('User-Agent',
                    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:39.0) Gecko/20100101 Firefox/39.0'),
                   ('Referer', 'http://%s' % self.baseurl), ('Accept-encoding', 'gzip'),
                   ('Cookie', str(sys.modules["__main__"].__settings__.getSetting("cpasbien-auth")))]
        content = self.makeRequest(url, headers=headers)

        return self.saveTorrentFile(url, content)

class CloudflareAdapter(HTTPAdapter):
    def send(self, request, **kwargs):
        domain = request.url.split("/")[2]
        resp = super(CloudflareAdapter, self).send(request, **kwargs)

        # Check if we already solved a challenge
        if request._cookies.get("cf_clearance", domain="." + domain):
            return resp

        # Check if Cloudflare anti-bot is on
        if ( "URL=/cdn-cgi/" in resp.headers.get("Refresh", "") and
             resp.headers.get("Server", "") == "cloudflare-nginx" ):
            return self.solve_cf_challenge(resp, request.headers, resp.cookies, **kwargs)

        # Otherwise, no Cloudflare anti-bot detected
        return resp

    def add_headers(self, request):
        # Spoof Chrome on Linux if no custom User-Agent has been set
        if "requests" in request.headers["User-Agent"]:
            request.headers["User-Agent"] = DEFAULT_USER_AGENT

    def format_js(self, js):
        js = re.sub(r"[\n\\']", "", js)
        if "Node" in JS_ENGINE:
            return "return require('vm').runInNewContext('%s');" % js
        return js.replace("parseInt", "return parseInt")

    def solve_cf_challenge(self, resp, headers, cookies, **kwargs):
        time.sleep(5) # Cloudflare requires a delay before solving the challenge

        headers = headers.copy()
        url = resp.url
        parsed = urlparse(url)
        domain = parsed.netloc
        page = resp.text
        kwargs.pop("params", None) # Don't pass on params
        try:
            challenge = re.search(r'name="jschl_vc" value="(\w+)"', page).group(1)
            challenge_pass = re.search(r'name="pass" value="(.+?)"', page).group(1)

            # Extract the arithmetic operation
            builder = re.search(r"setTimeout\(function\(\){\s+(var t,r,a,f.+?\r?\n[\s\S]+?a\.value =.+?)\r?\n", page).group(1)
            builder = re.sub(r"a\.value =(.+?) \+ .+?;", r"\1", builder)
            builder = re.sub(r"\s{3,}[a-z](?: = |\.).+", "", builder)

        except Exception as e:
            # Something is wrong with the page. This may indicate Cloudflare has changed their
            # anti-bot technique. If you see this and are running the latest version,
            # please open a GitHub issue so I can update the code accordingly.
            print ("[!] Unable to parse Cloudflare anti-bots page. Try upgrading cloudflare-scrape, or submit "
                   "a bug report if you are running the latest version. Please read "
                   "https://github.com/Anorov/cloudflare-scrape#updates before submitting a bug report.\n")
            raise

        # Safely evaluate the Javascript expression
        js = self.format_js(builder)
        answer = str(int(execjs.exec_(js)) + len(domain))

        params = {"jschl_vc": challenge, "jschl_answer": answer, "pass": challenge_pass}
        submit_url = "%s://%s/cdn-cgi/l/chk_jschl" % (parsed.scheme, domain)
        headers["Referer"] = url

        resp = requests.get(submit_url, params=params, headers=headers, cookies=cookies, **kwargs)
        resp.cookies.set("__cfduid", cookies.get("__cfduid"))
        return resp

def create_scraper(session=None):
    """
    Convenience function for creating a ready-to-go requests.Session object.
    You may optionally pass in an existing Session to mount the CloudflareAdapter to it.
    """
    sess = session or requests.session()
    adapter = CloudflareAdapter()
    sess.mount("http://", adapter)
    sess.mount("https://", adapter)
    return sess

def get_tokens(url, user_agent=None):
    scraper = create_scraper()
    user_agent = user_agent or DEFAULT_USER_AGENT
    scraper.headers["User-Agent"] = user_agent

    try:
        resp = scraper.get(url)
        resp.raise_for_status()
    except Exception:
        print("'%s' returned error %d, could not collect tokens.\n" % (url, resp.status_code))
        raise

    return ( {
                 "__cfduid": resp.cookies.get("__cfduid", ""),
                 "cf_clearance": scraper.cookies.get("cf_clearance", "")
             },
             user_agent
           )

def get_cookie_string(url, user_agent=None):
    tokens, user_agent = get_tokens(url, user_agent=user_agent)
    return "; ".join("=".join(pair) for pair in tokens.items()), user_agent