# -*- coding: utf-8 -*-

# easy live tv plugin written by IPTVxtra
# for more info please visit http://www.iptvxtra.net


import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys

if 'runstream' in sys.argv[2]:
    url = sys.argv[2].replace('?runstream=','')
    px = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-easylive/resources/lib/zapping.py")
    xbmc.executebuiltin('RunScript('+px+',url='+url+')')
    sys.exit(0)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
Addon = xbmcaddon.Addon('plugin.video.iptvxtra-easylive')
profile = xbmc.translatePath(Addon.getAddonInfo('profile'))
__settings__ = xbmcaddon.Addon(id="plugin.video.iptvxtra-easylive")
xbox = xbmc.getCondVisibility("System.Platform.xbox")
icons = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-easylive/icon_s.png") 
iconq = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-easylive/icon_q.png") 
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def gosetting():
    Addon.openSettings()
    xbmc.executebuiltin('Container.Refresh')

def main():
	
    if xbmcPlayer.isPlaying():
        xbmcPlayer.stop()
    playList.clear() 

    if __settings__.getSetting("pos_set") == "0": 
        add_video_item('plugin://plugin.video.iptvxtra-easylive/?settings', { 'title': 'Settings'}, icons, 'false')
    if __settings__.getSetting("quick_set") == "0": 
        add_video_item('plugin://plugin.video.iptvxtra-easylive/?quicktest', { 'title': 'Quick Test'}, iconq, 'false')

    if __settings__.getSetting("url_01") != "" and __settings__.getSetting("title_01") != "":
        add_video_item(__settings__.getSetting("url_01"), { 'title': __settings__.getSetting("title_01")}, __settings__.getSetting("picture_01"), 'true')
    if __settings__.getSetting("url_02") != "" and __settings__.getSetting("title_02") != "":
        add_video_item(__settings__.getSetting("url_02"), { 'title': __settings__.getSetting("title_02")}, __settings__.getSetting("picture_02"), 'true')
    if __settings__.getSetting("url_03") != "" and __settings__.getSetting("title_03") != "":
        add_video_item(__settings__.getSetting("url_03"), { 'title': __settings__.getSetting("title_03")}, __settings__.getSetting("picture_03"), 'true')
    if __settings__.getSetting("url_04") != "" and __settings__.getSetting("title_04") != "":
        add_video_item(__settings__.getSetting("url_04"), { 'title': __settings__.getSetting("title_04")}, __settings__.getSetting("picture_04"), 'true')
    if __settings__.getSetting("url_05") != "" and __settings__.getSetting("title_05") != "":
        add_video_item(__settings__.getSetting("url_05"), { 'title': __settings__.getSetting("title_05")}, __settings__.getSetting("picture_05"), 'true')
    if __settings__.getSetting("url_06") != "" and __settings__.getSetting("title_06") != "":
        add_video_item(__settings__.getSetting("url_06"), { 'title': __settings__.getSetting("title_06")}, __settings__.getSetting("picture_06"), 'true')
    if __settings__.getSetting("url_07") != "" and __settings__.getSetting("title_07") != "":
        add_video_item(__settings__.getSetting("url_07"), { 'title': __settings__.getSetting("title_07")}, __settings__.getSetting("picture_07"), 'true')
    if __settings__.getSetting("url_08") != "" and __settings__.getSetting("title_08") != "":
        add_video_item(__settings__.getSetting("url_08"), { 'title': __settings__.getSetting("title_08")}, __settings__.getSetting("picture_08"), 'true')
    if __settings__.getSetting("url_09") != "" and __settings__.getSetting("title_09") != "":
        add_video_item(__settings__.getSetting("url_09"), { 'title': __settings__.getSetting("title_09")}, __settings__.getSetting("picture_09"), 'true')
    if __settings__.getSetting("url_10") != "" and __settings__.getSetting("title_10") != "":
        add_video_item(__settings__.getSetting("url_10"), { 'title': __settings__.getSetting("title_10")}, __settings__.getSetting("picture_10"), 'true')
    if __settings__.getSetting("url_11") != "" and __settings__.getSetting("title_11") != "":
        add_video_item(__settings__.getSetting("url_11"), { 'title': __settings__.getSetting("title_11")}, __settings__.getSetting("picture_11"), 'true')
    if __settings__.getSetting("url_12") != "" and __settings__.getSetting("title_12") != "":
        add_video_item(__settings__.getSetting("url_12"), { 'title': __settings__.getSetting("title_12")}, __settings__.getSetting("picture_12"), 'true')
    if __settings__.getSetting("url_13") != "" and __settings__.getSetting("title_13") != "":
        add_video_item(__settings__.getSetting("url_13"), { 'title': __settings__.getSetting("title_13")}, __settings__.getSetting("picture_13"), 'true')
    if __settings__.getSetting("url_14") != "" and __settings__.getSetting("title_14") != "":
        add_video_item(__settings__.getSetting("url_14"), { 'title': __settings__.getSetting("title_14")}, __settings__.getSetting("picture_14"), 'true')
    if __settings__.getSetting("url_15") != "" and __settings__.getSetting("title_15") != "":
        add_video_item(__settings__.getSetting("url_15"), { 'title': __settings__.getSetting("title_15")}, __settings__.getSetting("picture_15"), 'true')
    if __settings__.getSetting("url_16") != "" and __settings__.getSetting("title_16") != "":
        add_video_item(__settings__.getSetting("url_16"), { 'title': __settings__.getSetting("title_16")}, __settings__.getSetting("picture_16"), 'true')
    if __settings__.getSetting("url_17") != "" and __settings__.getSetting("title_17") != "":
        add_video_item(__settings__.getSetting("url_17"), { 'title': __settings__.getSetting("title_17")}, __settings__.getSetting("picture_17"), 'true')
    if __settings__.getSetting("url_18") != "" and __settings__.getSetting("title_18") != "":
        add_video_item(__settings__.getSetting("url_18"), { 'title': __settings__.getSetting("title_18")}, __settings__.getSetting("picture_18"), 'true')
    if __settings__.getSetting("url_19") != "" and __settings__.getSetting("title_19") != "":
        add_video_item(__settings__.getSetting("url_19"), { 'title': __settings__.getSetting("title_19")}, __settings__.getSetting("picture_19"), 'true')
    if __settings__.getSetting("url_20") != "" and __settings__.getSetting("title_20") != "":
        add_video_item(__settings__.getSetting("url_20"), { 'title': __settings__.getSetting("title_20")}, __settings__.getSetting("picture_20"), 'true')
    if __settings__.getSetting("url_21") != "" and __settings__.getSetting("title_21") != "":
        add_video_item(__settings__.getSetting("url_21"), { 'title': __settings__.getSetting("title_21")}, __settings__.getSetting("picture_21"), 'true')
    if __settings__.getSetting("url_22") != "" and __settings__.getSetting("title_22") != "":
        add_video_item(__settings__.getSetting("url_22"), { 'title': __settings__.getSetting("title_22")}, __settings__.getSetting("picture_22"), 'true')
    if __settings__.getSetting("url_23") != "" and __settings__.getSetting("title_23") != "":
        add_video_item(__settings__.getSetting("url_23"), { 'title': __settings__.getSetting("title_23")}, __settings__.getSetting("picture_23"), 'true')
    if __settings__.getSetting("url_24") != "" and __settings__.getSetting("title_24") != "":
        add_video_item(__settings__.getSetting("url_24"), { 'title': __settings__.getSetting("title_24")}, __settings__.getSetting("picture_24"), 'true')
    if __settings__.getSetting("url_25") != "" and __settings__.getSetting("title_25") != "":
        add_video_item(__settings__.getSetting("url_25"), { 'title': __settings__.getSetting("title_25")}, __settings__.getSetting("picture_25"), 'true')
    if __settings__.getSetting("url_26") != "" and __settings__.getSetting("title_26") != "":
        add_video_item(__settings__.getSetting("url_26"), { 'title': __settings__.getSetting("title_26")}, __settings__.getSetting("picture_26"), 'true')
    if __settings__.getSetting("url_27") != "" and __settings__.getSetting("title_27") != "":
        add_video_item(__settings__.getSetting("url_27"), { 'title': __settings__.getSetting("title_27")}, __settings__.getSetting("picture_27"), 'true')
    if __settings__.getSetting("url_28") != "" and __settings__.getSetting("title_28") != "":
        add_video_item(__settings__.getSetting("url_28"), { 'title': __settings__.getSetting("title_28")}, __settings__.getSetting("picture_28"), 'true')
    if __settings__.getSetting("url_29") != "" and __settings__.getSetting("title_29") != "":
        add_video_item(__settings__.getSetting("url_29"), { 'title': __settings__.getSetting("title_29")}, __settings__.getSetting("picture_29"), 'true')
    if __settings__.getSetting("url_30") != "" and __settings__.getSetting("title_30") != "":
        add_video_item(__settings__.getSetting("url_30"), { 'title': __settings__.getSetting("title_30")}, __settings__.getSetting("picture_30"), 'true')
    if __settings__.getSetting("url_31") != "" and __settings__.getSetting("title_31") != "":
        add_video_item(__settings__.getSetting("url_31"), { 'title': __settings__.getSetting("title_31")}, __settings__.getSetting("picture_31"), 'true')
    if __settings__.getSetting("url_32") != "" and __settings__.getSetting("title_32") != "":
        add_video_item(__settings__.getSetting("url_32"), { 'title': __settings__.getSetting("title_32")}, __settings__.getSetting("picture_32"), 'true')
    if __settings__.getSetting("url_33") != "" and __settings__.getSetting("title_33") != "":
        add_video_item(__settings__.getSetting("url_33"), { 'title': __settings__.getSetting("title_33")}, __settings__.getSetting("picture_33"), 'true')
    if __settings__.getSetting("url_34") != "" and __settings__.getSetting("title_34") != "":
        add_video_item(__settings__.getSetting("url_34"), { 'title': __settings__.getSetting("title_34")}, __settings__.getSetting("picture_34"), 'true')
    if __settings__.getSetting("url_35") != "" and __settings__.getSetting("title_35") != "":
        add_video_item(__settings__.getSetting("url_35"), { 'title': __settings__.getSetting("title_35")}, __settings__.getSetting("picture_35"), 'true')
    if __settings__.getSetting("url_36") != "" and __settings__.getSetting("title_36") != "":
        add_video_item(__settings__.getSetting("url_36"), { 'title': __settings__.getSetting("title_36")}, __settings__.getSetting("picture_36"), 'true')
    if __settings__.getSetting("url_37") != "" and __settings__.getSetting("title_37") != "":
        add_video_item(__settings__.getSetting("url_37"), { 'title': __settings__.getSetting("title_37")}, __settings__.getSetting("picture_37"), 'true')
    if __settings__.getSetting("url_38") != "" and __settings__.getSetting("title_38") != "":
        add_video_item(__settings__.getSetting("url_38"), { 'title': __settings__.getSetting("title_38")}, __settings__.getSetting("picture_38"), 'true')
    if __settings__.getSetting("url_39") != "" and __settings__.getSetting("title_39") != "":
        add_video_item(__settings__.getSetting("url_39"), { 'title': __settings__.getSetting("title_39")}, __settings__.getSetting("picture_39"), 'true')
    if __settings__.getSetting("url_40") != "" and __settings__.getSetting("title_40") != "":
        add_video_item(__settings__.getSetting("url_40"), { 'title': __settings__.getSetting("title_40")}, __settings__.getSetting("picture_40"), 'true')

    if __settings__.getSetting("quick_set") == "1": 
        add_video_item('plugin://plugin.video.iptvxtra-easylive/?quicktest', { 'title': 'Quick Test'}, iconq, 'false')
    if __settings__.getSetting("pos_set") == "1": 
        add_video_item('plugin://plugin.video.iptvxtra-easylive/?settings', { 'title': 'Settings'}, icons, 'false')

    xbmcplugin.endOfDirectory(addon_handle)

def find_between(s,first,last):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def add_video_item(url, infolabels, img='', playbar=''):

    if url.find("youtube.com") > 0:
        yout = 1
        urlx = url.partition('=')
        img = "http://i1.ytimg.com/vi/" + urlx[2] + "/hqdefault.jpg"
        url = "plugin://plugin.video.iptvxtra-easylive/?runstream=http://youtube/"+ urlx[2] + '***' + infolabels['title'] + '***' + img + '***' + str(addon_handle)
    elif '.m3u' in url and '.m3u8' not in url:
        if '#sb' in url or __settings__.getSetting("setHeader") == "true":
            url = url.replace('#sb','')
            url = url + '|User-Agent=Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'
        else: url = url
    elif playbar == 'true':
        url= 'plugin://plugin.video.iptvxtra-easylive/?runstream=' + url + '***' + infolabels['title'] + '***' + img + '***' + str(addon_handle)


    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    #listitem.setProperty('IsPlayable', playbar)
    xbmcplugin.addDirectoryItem(addon_handle, url, listitem, isFolder=False)

def quicktest():	
    keyboard = xbmc.Keyboard()
    keyboard.setHiddenInput(False)
    keyboard.setHeading('Set Stream Adresse und Sonderfunktionen ')
    keyboard.doModal()
    if keyboard.isConfirmed():   
        if keyboard.getText().strip() == '': sys.exit(0)
        px = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-easylive/resources/lib/zapping.py")
        xbmc.executebuiltin('RunScript('+px+',url='+keyboard.getText()+'***Quick Test***'+iconq+'***'+str(addon_handle)+')')
        sys.exit(0)
    else: sys.exit(0)

if 'settings'in sys.argv[2]:
    gosetting()
elif 'quicktest'in sys.argv[2]:
    quicktest()
else:
    main()