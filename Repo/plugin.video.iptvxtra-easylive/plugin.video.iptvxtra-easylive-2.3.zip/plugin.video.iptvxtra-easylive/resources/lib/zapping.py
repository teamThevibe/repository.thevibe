#!/bin/python
import xbmcgui,xbmc,os,sys,xbmcplugin,xbmcaddon
xbmcPlayer = xbmc.Player()
mode = sys.argv[1]
idx = mode.replace("url=", "").split('***') # 0 =url 1=titel 2=icon
addon_handle = int(idx[3])
link = idx[0].split('#')
url = link[0]
xbmc.executebuiltin('XBMC.Notification('+idx[1]+' , einen Moment der Sender wird geladen ,5000,'+idx[2]+')')

def zapp(url,link):
    lesen = 0
    simBrowser = 0
    forward = 0
    refer = 0
    ipx = ''
    hdx = ''
    refx = ''
    urlx = ''
    if xbmcaddon.Addon(id = 'plugin.video.iptvxtra-easylive').getSetting("setHeader") == 'true': simBrowser = 1
    if xbmcaddon.Addon(id = 'plugin.video.iptvxtra-easylive').getSetting("setRTMP") == 'true' and 'rtmp' in url: simBrowser = 0
	
    for i in link:
        if i == 'sb': simBrowser = 1
        if i == 'ls': lesen = 1
        if 'fw*' in i : 
            forward = 1
            ipx = i.replace('fw*','').strip()
        if 're*' in i : 
            refer = 1
            refx = i.replace('re*','').strip() 

    if simBrowser == 1: hdx = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'
    if 'rtmp://' in url or 'rtmpt://' in url or 'rtmpte://' in url and 'live=1' not in url: url = url + ' live=1'

    if lesen == 1:
        import requests as requests
        if simBrowser == 0 and forward == 0: r = requests.get(url)
        if simBrowser == 1 and forward == 0: r = requests.get(url, headers={'User-Agent':hdx})
        if simBrowser == 0 and forward == 1: r = requests.get(url, headers={'X-Forwarded-For':ipx})
        if simBrowser == 1 and forward == 1: r = requests.get(url, headers={'User-Agent':hdx, 'X-Forwarded-For':ipx})
        r = r.text.replace('\n',' ')
        url = find_between(r,'http://','.m3u8')
        url = 'http://'+url+'.m3u8' 

    if simBrowser == 0 and forward == 0 and refer == 0: url = url
    else:
        if simBrowser == 1: urlx = urlx + '&User-Agent=' + hdx
        if forward == 1: urlx = urlx + '&X-Forwarded-For=' + ipx
        if refer == 1: urlx = urlx + '&Referer=' + refx
        url = url + '|' + urlx
        url = url.replace('|&','|')


    listitem = xbmcgui.ListItem( idx[1], iconImage=idx[2], thumbnailImage=idx[2])
    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
    playlist.clear()
    playlist.add( url, listitem )
    xbmcPlayer.play(playlist,None,False)
    sys.exit(0)

def find_between(s,first,last):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

zapp(url,link)
