#!/bin/python
import xbmcgui,xbmc,os,sys,re,urllib2
import requests as requests

xbmcPlayer = xbmc.Player()
mode = sys.argv[1]
idx = mode.replace("url=", "").split('***')

xbmc.executebuiltin('XBMC.Notification('+idx[1]+' , einen Moment der Sender wird geladen ,5000,'+idx[2]+')')
url = idx[0]

def zapp():
    if '.m3u8' in idx[0] or '.php?' in idx[0] or 'rtmp://' in idx[0]: url = idx[0]
    else:
        data = urllib2.urlopen(idx[0]).read()
        url = find_between(data,'&file=','&st=')
        if url == '': url = find_between(data,'value="src=','&')
    if 'rtmp' in url and 'live=1' not in url: url = url + ' live=1'
    if 'parse_divan_tv' in url:
        urlx = url.split('+++')
        url = urlx[0]
        link = get_url(urlx[1])
        ix = find_between(link,'http','m3u8')
        ix = ix.split('/')
        for x in ix:
            if len(x) > 29 and len(x) < 35:
                url = url.replace('---',x) + '|User-Agent=Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'
                #url = url.replace('cosmo.divan.tv','95.67.10.221')
                break

    if '?lesen' in url or '&lesen' in url or '?lesen&' in url:        
        url = url.replace('?lesen&','?').replace('?lesen','').replace('&lesen','')

        r=requests.get(url, headers={"User-Agent":"Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16"})
        r = r.text.replace('\n',' ')
        url = find_between(r,'http://','.m3u8')
        url = 'http://'+url+'.m3u8' + '|User-Agent=Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'



    listitem = xbmcgui.ListItem( idx[1], iconImage=idx[2], thumbnailImage=idx[2])
    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
    playlist.clear()
    playlist.add( url, listitem )
    xbmcPlayer.play(playlist,None,True)
    sys.exit(0)

def parse(sHtmlContent, sPattern, iMinFoundValue = 1, ignoreCase = False):
    if ignoreCase:
        aMatches = re.compile(sPattern, re.DOTALL|re.I).findall(sHtmlContent)
    else:
        aMatches = re.compile(sPattern, re.DOTALL).findall(sHtmlContent)
    if (len(aMatches) >= iMinFoundValue):                
        return True, aMatches
    return False, aMatches

def find_between(s,first,last):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def get_url(url):
        response = urllib2.urlopen(url)
        link=response.read()
        response.close()
        return link

zapp()