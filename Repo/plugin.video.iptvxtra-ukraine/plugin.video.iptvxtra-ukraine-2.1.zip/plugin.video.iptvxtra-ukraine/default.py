# -*- coding: cp1254 -*-
# for more info please visit http://www.iptvxtra.net


import sys,xbmc,xbmcaddon,xbmcgui

if 'extrafanart' in sys.argv[2]: sys.exit(0)

if 'runstream' in sys.argv[2] and 'preview' not in sys.argv[2]:
    url = sys.argv[2].replace('?runstream=','')
    px = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-ukraine/resources/lib/zapping.py")
    xbmc.executebuiltin('RunScript('+px+',url='+url+')')
    sys.exit(0)

if 'preview'in sys.argv[2]:
    mode = sys.argv[2].replace('?preview','')
    xel = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    url = xel.getControl(int(mode)).getLabel().replace('plugin://plugin.video.iptvxtra-ukraine/?runstream=','').encode('utf-8')
    px = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-ukraine/resources/lib/preview.py")
    xbmc.executebuiltin('RunScript('+px+',url='+url+')')
    sys.exit(0)


import urllib2,urllib,re,os,xbmcplugin,time
import resources.lib.requests as requests
from datetime import date, datetime,timedelta
from resources.lib.BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
Addon = xbmcaddon.Addon('plugin.video.iptvxtra-ukraine')
home = Addon.getAddonInfo('path')
icon = xbmc.translatePath( os.path.join( home, 'icon.png' ) )
net = xbmc.translatePath( os.path.join( home, 'resources/lib/net.png') )
fanart = xbmc.translatePath( os.path.join( home, 'fanart.jpg' ) )
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
xmltv2 = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-ukraine/resources/epg/epg.xmx")
viewfile = xbmc.translatePath("special://temp/tvukr.fi")
__settings__ = xbmcaddon.Addon(id="plugin.video.iptvxtra-ukraine")
md5 = 'hex'
setBack = __settings__.getSetting("setBack")
views_s = __settings__.getSetting("views_s")
epg_on = __settings__.getSetting("epg_on")
epg_dl = __settings__.getSetting("epg_dl")
epg_title = __settings__.getSetting("epg_title")
epg_info = __settings__.getSetting("epg_info")


if __settings__.getSetting("timeshift0") == 'true' and epg_on == 'true':
    try:
        import resources.lib.USTimeZone as USTimeZone	
        LocalTimezone = USTimeZone.LocalTimezone()
        Europe = USTimeZone.GMT2()
        #print str(datetime.now(Europe))
        if '+02:00' in str(datetime.now(Europe)): euro = 2
        elif '+03:00' in str(datetime.now(Europe)): euro = 3
        else: euro = 3
        eurox = str(datetime.now(LocalTimezone))
        eurox = eurox.partition('.')
        if '+' in eurox[2] :  
            eurox = eurox[2].partition('+')
            eurox = eurox[2].partition(':')
            timeshift = str(int(eurox[0]) - euro)
        elif '-' in eurox[2] :
            eurox = eurox[2].partition('-')
            eurox = eurox[2].partition(':')
            timeshift = str(int('-'+eurox[0]) - euro)
        __settings__.setSetting("timeshift", timeshift)
    except:
        timeshift = __settings__.getSetting('timeshift')
        xbmc.executebuiltin('XBMC.Notification(autom. Zeitzonen Fehler , die Zeitzone wurde mit dem manuell Wert gesetzt ,8000,'+icon+')')
else:
    timeshift = __settings__.getSetting("timeshift")
    if timeshift == '': timeshift = '0'
	


def main():	
    repo()
    link = get_url()
    linktn = link[2]
    if epg_on == 'true': 
        xmltv_dl(link[0])
        iptvepg = xmltv()

    description = 'keine EPG Information'	
    soup = BeautifulSOAP(link[1], convertEntities=BeautifulStoneSoup.XML_ENTITIES)

    quelle1 = soup.findAll("quelle1")
    for q in quelle1: quelle1 = q.string
    quelle2 = soup.findAll("quelle2")
    for q in quelle2: quelle2 = q.string

    items = soup.findAll("item")
    for item in items:
            try:
                videoTitle=item.title.string
            except: pass
            try:
                thumbnail= linktn.strip() + item.thumbnail.string   
                if item.thumbnail.string == 'none': thumbnail = icon
            except:
                thumbnail = icon
            try:
                url= 'plugin://plugin.video.iptvxtra-ukraine/?runstream=' + item.link.string.replace('|','%%') + '***' + videoTitle + '***' + thumbnail
                if 'divan_id' in item.link.string:
                    chn = item.link.string.replace('divan_id_','')
                    url = 'plugin://plugin.video.iptvxtra-ukraine/?runstream=' + quelle2.replace('---',chn).replace('***','---') + '+++' + quelle1 + '+++' + 'parse_divan_tv' + '***' + videoTitle + '***' + thumbnail
                if '.m3u' in item.link.string and not '.m3u8' in item.link.string:
                    url = item.link.string
            except: pass

            try:
                xmlepg = item.xmlepg.string
                if xmlepg != '' and xmlepg != 'none'and xmlepg != 'None':
                    if epg_on == "true":
                        description = ''
                        zx = 0
                        for text in iptvepg:
                            text0 = text[0].strip() 
                            if xmlepg == text0 and int(text[4])-10800 > int(time.time()):
                                text[5] = text[5].replace('http://teleguide.info/article205.html','').strip()
                                laenge = len(text[5]) + len(text[6]) + 3
                                if laenge < 60:
                                    description = description + timestamp(text[8]) +'  '+ text[5]
                                    if text[6] != 'no Info': description = description + ' - ' + text[6]
                                    description = description + '\n'
                                else:
                                    description = description + timestamp(text[8]) +'  '+ text[5]
                                    if text[6] != 'no Info': 
                                        if len(text[6]) > 50 : 
                                            kuerz = len(text[6]) - 50
                                            text[6] = text[6][:-kuerz] + ' ...'
                                        description = description + '\n'+''+ text[6]
                                    description = description + '\n'
                                if zx == 0 and epg_title == "true":
                                    if ' - ' in text[5]:
                                        text5 = text[5].partition(" - ")
                                        videoTitle = videoTitle +'   - '+ text5[0]
                                    else: 
                                        videoTitle = videoTitle +'   - '+ text[5]
                                zx += 1
                            if zx == int(epg_info): break

            except: description = 'keine EPG Information'

            addLink(videoTitle,url,thumbnail,description)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    try:
        if int(views_s) > 0 and not os.path.isfile(viewfile):
            open(viewfile, "a").close()
            xbmc.executebuiltin("Container.SetViewMode("+views_s+")") 
    except: pass
    sys.exit(0)
    
def addLink(name,url,thumbnail,description):	
    try: name = name.encode('utf-8')
    except: pass
    try: description = description.encode('utf-8')
    except: pass
    namex = name.split('  - ')
    liz=xbmcgui.ListItem(name, iconImage=thumbnail, thumbnailImage=thumbnail)
    liz.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": description, "Genre": namex[0] + " -  EPG aktualisiert um " + str(time.strftime("%H:%M"))} )
    if setBack == "true": liz.setProperty( "Fanart_Image", thumbnail )
    else: liz.setProperty( "Fanart_Image", icon )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def get_url():
    r = requests.get("http://www.iptvxtra.net/xbmc/_form/rsx.php", params={'la':'UKRx'}).text.replace('.','7').replace('/','A').strip().decode(md5).split('***')
    try:
        t = requests.get(r[1]+r[3],timeout=20).text
        s = 'http://srv1.iptvxtra.net/xbmc/senderlogos_ukr/'
    except:
        t = requests.get(r[2]+r[3]).text
        s = 'http://srv3.iptvxtra.net/xbmc/senderlogos_ukr/'
    return r,t,s

def find_between(s,trennzeichen):
    try:
        first = '<' + trennzeichen + '>'
        last = '</' + trennzeichen + '>'
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def repo():
    record_folder = xbmc.translatePath("special://home/addons/repository.iptvxtra")
    if not os.path.isdir(record_folder):
        xbmc.executebuiltin('XBMC.Notification(IPTVxtra Repo missing , the Repo of IPTVxtra is not installed - the addon can not be executed ,15000,'+icon+')')
        sys.exit(0)

def read_listfile(datei):
    import pickle
    f = open(datei)
    liste = pickle.load(f)
    return liste

def timestamp(zeit):
    zeita = zeit.partition(":")
    zeitb = int(zeita[0]) + int(timeshift)
    if zeitb > 24:
        zeitb -= 24
    elif zeitb < 0:
        zeitb += 24       
    zeitc = str(zeitb)
    if zeitc == '24':
        zeitc = '00'
    if zeitb > 0 and zeitb < 10:
        zeitc = '0' + zeitc
    zeit = zeitc + '.' + zeita[2]  
    zeit = zeit.strip()
    return (zeit)

def xmltv_dl(fil):
    dltime = 3600*18
    if not os.path.isfile(xmltv2) or os.stat(xmltv2)[8] < (time.time() - dltime) or os.path.getsize(xmltv2) < 20000 or epg_dl == 'true':
        xbmc.executebuiltin('XBMC.Notification(EPG Information !, das neue EPG wird von Server geladen ,8000,'+icon+')')
        if epg_dl == 'true': __settings__.setSetting("epg_dl", "false")
        try: urllib.urlretrieve (fil[1]+fil[4], xmltv2)
        except: urllib.urlretrieve (fil[2]+fil[4], xmltv2)
    return

def xmltv():
    iptvepg=[]
    if os.path.isfile(xmltv2):
        iptvepg = read_listfile(xmltv2)
        return iptvepg
    else:
        iptvepg.append([' ','0','0','0','0',' ',' ',' ','0'])
        iptvepg.append([' ','0','0','0','0',' ',' ',' ','0'])
        write_listfile(xbmc.translatePath(xmltv2),iptvepg)
        return iptvepg

main()

