# TheWiz Addon Installer
# Thanks to Blazetamer, Eleazar Coding, Showgun, TheHighway, ....
import requests,shutil, json, sys, os, xbmcgui, time, xbmc, urllib, urllib2, re, zipfile ,xbmcaddon
from xml.dom import minidom

def AddonInstaller(id):
	#if id == "script.module.buggalo":
	#	return 0
	if id in repo_addons:
		url = repo_addons[id]
		local_filename = url.split('/')[-1]
	else:
		print "*** {0}: ERROR: {1} don't exist in Repo".format(AddonName,id)
		return 0
	addonsfolder = xbmc.translatePath(os.path.join('special://','home','addons'))
	if os.path.isdir(os.path.join(addonsfolder,id)):
		print "*** {0}: Exist {1} in Kodi".format(AddonName,id)
		return 0
	packfolder = xbmc.translatePath(os.path.join('special://','home','addons','packages'))
	dp = xbmcgui.DialogProgress(); 
	dp.create("TheWiz Kodi Wizard","Downloading "+id,'','Please Wait')
	addon_zip = os.path.join(packfolder,local_filename)
	try: os.remove(addon_zip)
	except: pass
	print "*** {0}: Downloading {1}".format(AddonName,id)
	download_try=0
	while True:
		AddonDownload(url,addon_zip,dp)
		try:
			test_zip_file = zipfile.ZipFile(addon_zip)
			ret = test_zip_file.testzip()
			if ret is None:
				break
		except:pass
		download_try += 1
		SleepFor(4)
		if download_try>4:
			OKmsg("Server Error",localizedString(33000).encode('utf-8'),localizedString(33001).encode('utf-8'))
			print "*** {0}: Error Downloading {1}".format(AddonName,id)
			return 0
	time.sleep(2)
	print "*** {0}: Extracting {1}".format(AddonName,local_filename)
	dp.update(0,"Extracting Zip {0}".format(local_filename),"",'Please Wait')
	AddonExtract(addon_zip,addonsfolder,dp)
	time.sleep(2)
	try:
		depends = xbmc.translatePath(os.path.join(addonsfolder,id,'addon.xml')); 
		source = open(depends,mode='r'); line=source.read(); source.close();
		regex =ur'import addon="(.+?)"'
		addon_requires = re.findall(regex, line)
		for addon_require in addon_requires:
			if not 'xbmc.' in addon_require:
				dependspath = xbmc.translatePath(os.path.join('special://home/addons',addon_require))
				if not os.path.exists(dependspath): 
					AddonInstaller(addon_require)
	except:pass

def AddonDownload(source, target,dp = None):
	if not dp:
		dp = xbmcgui.DialogProgress()
		dp.create("Status...","Checking Installation",' ', ' ')
	dp.update(0)
	r = requests.get(source, stream=True, timeout=10)
	try:
		total_size = r.headers['content-length'].strip()
		total_size = int(total_size)
	except:
		return
	bytes_so_far = 0

	with open(target, 'wb') as fp:
		try:
			for chunk in r.iter_content(chunk_size=(1024*8)):
				if chunk:
					bytes_so_far += len(chunk)
					percent = min((100*bytes_so_far/total_size), 100)
					dp.update(percent)

					fp.write(chunk)

					if dp.iscanceled():
						raise Exception("Canceled")
						fp.close();	r.close(); dp.close()
						return 0
		except:pass
	fp.close()
	r.close()
	return 1

def AddonExtract(_in, _out, dp):
    zin = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except Exception, e:
        print str(e)
        return False

    return True
	
def GetRepoInfo(repo):
	global repo_addons
	repo_addons = {}
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+id+"/"+id+"-"+version+".zip"
	return 1

def SleepFor(timeS):
    while((not xbmc.abortRequested) and (timeS > 0)):
        xbmc.sleep(1000)
        timeS -= 1

def SetPVR():
	enable_pvr = json_query({"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":"toggle"},"id":1})
	xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
	SleepFor(2)
	xbmc.executebuiltin("XBMC.StartPVRManager()")
		
def CheckRun(addonID):
	target = xbmc.translatePath(os.path.join('special://userdata','addon_data',addonID)); 
	DoneFile = os.path.join(target,'done.txt')
	SettingFile = os.path.join(target,'settings.xml')
	if not os.path.isfile(SettingFile):
		SetPVR()
		Addon.openSettings()
	if not os.path.isfile(DoneFile):
		while True:
			if os.path.isfile(SettingFile):
				return 1
			SleepFor(4)
	else:
		return 0

def CheckRepo():
	folder = xbmc.translatePath(os.path.join('special://home','addons','repository.TheWiz'))
	if not os.path.isdir(folder):
		os.makedirs(folder)
		xml_file = xbmc.translatePath(os.path.join('special://home','addons','repository.TheWiz','addon.xml'))
		urllib.urlretrieve ("http://repo.thewiz.info/repository.TheWiz/addon.xml", xml_file)
	xbmc.executebuiltin("XBMC.UpdateAddonRepos()")

def OKmsg(title, line1, line2="", line3=""):
	xbmcgui.Dialog().ok(title, line1, line2, line3)

def json_query(query):
	xbmc_request = json.dumps(query)
	raw = xbmc.executeJSONRPC(xbmc_request)
	clean = unicode(raw, 'utf-8', errors='ignore')
	response = json.loads(clean)
	result = response.get('result', response)
	return result
	
global repo_addons, AddonName
addonID = "service.thewiz.wizard"
Addon = xbmcaddon.Addon(addonID)
AddonName = Addon.getAddonInfo("name")
localizedString = Addon.getLocalizedString 

xbmc.executebuiltin("XBMC.UpdateLocalAddons()")

CheckRepo()

if not CheckRun(addonID):
	sys.exit(1)

SkinToUse = Addon.getSetting("SkinToUse")
InstallSkin = None
if (SkinToUse=="Eminence Abeksis"):
	InstallSkin = "skin.eminence.heb"
if (SkinToUse=="Eminence Zeev"):
	InstallSkin = "skin.eminence.zeev"
if (SkinToUse=="Phenomenal"):
	InstallSkin = "skin.phenomenal"

GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/isengard/")
GetRepoInfo("http://repo.thewiz.info/")

AddonInstaller("service.subtitles.opensubtitles")
AddonInstaller("service.subtitles.podnapisi")
AddonInstaller("service.subtitles.subscenter")
AddonInstaller("service.subtitles.subtitle")

if InstallSkin is not None:
	AddonInstaller (InstallSkin)

if (SkinToUse=="Default"):
	AddonInstaller ("skin.confluence")

if Addon.getSetting("useMusic") == "true":
	AddonInstaller ("plugin.video.kmusictube")

if Addon.getSetting("useTheWizWall") == "true":
	AddonInstaller ("plugin.video.thewiz.wall")

if Addon.getSetting("useTV") == "true":
	AddonInstaller ("plugin.video.israelive")

if InstallSkin is not None:
	time.sleep(2)
	xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
	time.sleep(2)
	xbmc.executebuiltin("XBMC.ActivateWindow(appearancesettings)")
	time.sleep(2)
	OKmsg(localizedString(33002).encode('utf-8'),localizedString(33002).encode('utf-8'),localizedString(33003).encode('utf-8'),localizedString(33004).encode('utf-8')+SkinToUse.encode('utf-8'))
else:
	time.sleep(2)
	xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
	OKmsg(localizedString(33002).encode('utf-8'),localizedString(33002).encode('utf-8'))

addon_data = xbmc.translatePath(os.path.join('special://userdata','addon_data',addonID)); 
DoneFile = os.path.join(addon_data,'done.txt')
f = open(DoneFile, 'w');f.write(".");f.close();
print "*** {0}: Done!".format(AddonName)

if Addon.getSetting("useTheWizWall") == "true":
	time.sleep(30)
	xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,0)')

json_query({"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":addonID,"enabled":"toggle"},"id":1})

sys.exit(1)