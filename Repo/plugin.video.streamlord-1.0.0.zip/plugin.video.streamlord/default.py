import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
import urlresolver
import requests
from addon.common.addon import Addon
from addon.common.net import Net
from metahandler import metahandlers




#StreamLord - By Mucky Duck (10/2015)




addon_id='plugin.video.streamlord'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
Addon = xbmcaddon.Addon(addon_id)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
baseurl550 = 'http://www.streamlord.com/'
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData(preparezip=False)
net = Net()




def CAT():
        addDir('[COLOR cyan]Newest Movies[/COLOR]',baseurl550+'movies.html',1,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Movies By Rating[/COLOR]',baseurl550+'movies.php?sortby=rating',1,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Movies By Genre[/COLOR]',baseurl550+'movies.html',4,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Movies ABC[/COLOR]',baseurl550+'movies.html',3,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Newest TV Shows[/COLOR]',baseurl550+'tvshows.html',5,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]TV Shows By Rating[/COLOR]',baseurl550+'/series.php?sortby=rating',5,art+'sl.png',art+'f1.jpg','')
        addDir('[COLOR cyan]TV Shows ABC[/COLOR]',baseurl550+'tvshows.html',7,art+'sl.png',art+'f1.jpg','')




def BASE550MINDEX(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<li class="movie">', '<p')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<div class="movie-grid-title">\t\t\t\t\n\t\t\t\t\t\t\t', '\n\t').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
                year = regex_from_to(a, '<span class="movie-grid-floater movie-grid-year">', '<').replace("&amp;","&")
                addDir2(name+'('+year+')',baseurl550+url,2,'',items)
        try:
                nextp=re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(link)[0]
                nextp = nextp.replace('./',baseurl550)
                addDir('[COLOR cyan]Next Page>>>[/COLOR]',nextp,1,art+'sl.png',art+'f1.jpg','')
        except: pass
        setView('movies', 'movie-view')



def BASE550L(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        url=re.compile('"default": true, "file": "(.*?)"').findall(link)[0]
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




def BASE550MABC(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<a href="(.*?)".*?>(.*?)</a>').findall(link)
        for url,name in match:
                if './movies-' in url:
                        url = url.replace('./movies-','http://www.streamlord.com/movies-')
                        if '-genre-' not in url:
                                addDir('[COLOR cyan]%s[/COLOR]' %name,url,1,'',art+'f1.jpg','')
                                print url




def BASE550MGENRE(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<a href="(.*?)".*?>(.*?)</a>').findall(link)
        for url,name in match:
               if '-genre-' in url:
                       if './movies-' not in url:
                                addDir('[COLOR cyan]%s[/COLOR]' %name,url,1,'',art+'f1.jpg','')




def BASE550TVINDEX(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<li class="movie">', '<div class="movie-grid-starring">')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<div class="movie-grid-title">\t\t\t\t\n\t\t\t\t\t\t\t', '\n').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
                icon = regex_from_to(a, 'src="', '"')
                dis = regex_from_to(a, '<p>', '</p>').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                addDir('[COLOR white]%s[/COLOR]' %name,baseurl550+url,6,baseurl550+icon,art+'f1.jpg',dis)
        try:
                nextp=re.compile('<a href="(.*?)"> NEXT  &nbsp;&nbsp;&nbsp; &gt; </a>').findall(link)[0]
                nextp = nextp.replace('./',baseurl550)
                addDir('[COLOR cyan]Next Page>>>[/COLOR]',nextp,5,art+'sl.png',art+'f1.jpg','')
        except: pass
        setView('movies', 'movie-view')




def BASE550TVEP(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        all_videos = regex_get_all(link, '<a class="head">', '</p>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, '<span>', '</a>').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                name = name.replace('<ep>','').replace('</ep>',':').replace('</span>','  ')
                url = regex_from_to(a, 'href="', '"').replace("&amp;","&")
                icon = regex_from_to(a, 'src="', '"')
                dis = regex_from_to(a, '<p>', '</p>').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#039;',"'")
                addDir('[COLOR white]%s[/COLOR]' %name,baseurl550+url,2,icon,art+'f1.jpg',dis)
        setView('movies', 'movie-view')          




def BASE550TVABC(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<a href="(.*?)".*?>(.*?)</a>').findall(link)
        for url,name in match:
                if './tvshow' in url:
                        url = url.replace('./tvshow','http://www.streamlord.com/tvshow')
                        if '-genre-' not in url:
                                addDir('[COLOR cyan]%s[/COLOR]' %name,url,5,art+'sl.png',art+'f1.jpg','')




def regex_from_to(text, from_string, to_string, excluding=True):
        if excluding:
                try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
                except: r = ''
        else:
                try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
                except: r = ''
        return r




def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r            




def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description} )
        liz.setProperty('fanart_image', fanart)
        if mode==2:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def addDir2(name,url,mode,iconimage,itemcount):
        if metaset=='true':
                splitName=name.partition('(')
                simplename=""
                simpleyear=""
                if len(splitName)>0:
                        simplename=splitName[0]
                        simpleyear=splitName[2].partition(')')
                if len(simpleyear)>0:
                        simpleyear=simpleyear[0]
                meta = metaget.get_meta('movie', simplename ,simpleyear)
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
                liz.setInfo( type="Video", infoLabels= meta )
                contextMenuItems = []
                contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
                if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
                else: liz.setProperty('fanart_image', fanart)
                if mode==2:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok
        else:
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                liz.setProperty('fanart_image', fanart)
                if mode==2:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok




def OPEN_URL(url):
        headers = {}
        name = ''
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers).text
        return link




def setView(content, viewType):
        ''' Why recode whats allready written and works well,
        Thanks go to Eldrado for it '''

        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        #if addon.get_setting('auto-view') == 'true':

        #    print addon.get_setting(viewType)
        #    if addon.get_setting(viewType) == 'Info':
        #        VT = '515'
        #    elif addon.get_setting(viewType) == 'Wall':
        #        VT = '501'
        #    elif viewType == 'default-view':
        #        VT = addon.get_setting(viewType)

        #    print viewType
        #    print VT
        
        #    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

           
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
site=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
        
if mode==None or url==None or len(url)<1:
        CAT()

elif mode==1:
        BASE550MINDEX(url)

elif mode==2:
        BASE550L(url)

elif mode==3:
        BASE550MABC(url)

elif mode==4:
        BASE550MGENRE(url)

elif mode==5:
        BASE550TVINDEX(url)

elif mode==6:
        BASE550TVEP(url)

elif mode==7:
        BASE550TVABC(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
