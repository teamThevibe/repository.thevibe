Introduction
===================
This script makes some modifications to work well with tutvguia.com