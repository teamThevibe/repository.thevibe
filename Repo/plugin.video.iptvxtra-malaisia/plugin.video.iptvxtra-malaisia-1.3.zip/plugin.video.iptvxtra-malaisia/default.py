# denmark television plugin written by IPTVxtra
# -*- coding: utf-8 -*-

# for more info please visit http://www.iptvxtra.net

import xbmcgui,xbmcplugin,os,xbmc
plugin_handle = int(sys.argv[1])

def add_video_item(url, infolabels, img=''):
    if 'rtmp' not in url:
        url = url + "|X-Forwarded-For=42.154.55.155"
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty( "Fanart_Image", img )
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

def repo():
    record_folder = xbmc.translatePath("special://home/addons/repository.iptvxtra")
    if not os.path.isdir(record_folder):
        xbmc.executebuiltin('XBMC.Notification(IPTVxtra Repo missing , the Repo of IPTVxtra is not installed - the addon can not be executed ,15000,'+icon+')')
        sys.exit(0)


	
tv1 = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch001.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442372680&myTokenPrefixhash=Yw0lWZxbeYG1AUCiIh0nCeb_TkFVyV9L3VE7QWJ9SkM='
tv2 = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch003.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442373088&myTokenPrefixhash=Qw5ICPXwhqxgoqiFo_0piBFDL9TugqnF9p99cgB3DEA='
tv3 = 'http://tv3liveios-i.akamaihd.net/hls/live/205900/ios/tv3live/master002.m3u8'
RTMTVi = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch005.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442373378&myTokenPrefixhash=G_RfIYAEJi1qaWTUXgdrbxPYuaPvj2qxKzaFgrIL09Y='
einsnews = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch006.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442373506&myTokenPrefixhash=tbZEUxlij5AgrrqWJcx_jE54gJjjShbE7Vc27slt1x4='
RTMM = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch007.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442636347&myTokenPrefixhash=W5OIlM5Qs6BLF_lV06kUrYh-YgAYcDFxqsyu-TkjgU8='
AKSISUKAN = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch022.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442636916&myTokenPrefixhash=0wRyiNNDQErFSA88FE8mE50CdxbC7fXuqDT8tV4b0Bk='
RTMPARLIMEN = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch009.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1442637055&myTokenPrefixhash=PkXSnDtyZXie0iGGsLHdJQFJLdSVjGQ8j6ZJeLbNMqQ='
Bernama = 'http://d22b8vh21p20bg.cloudfront.net/mylive/smil:bernama2_all.smil/playlist.m3u8'
AstroAwani = 'rtmp://cp160334.live.edgefcs.net:1935/live?ovpfv=1.1/AstroAwani24x7_3@74937 live=1'


icondir = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-malaisia/icons/")
icon = xbmc.translatePath("special://home/addons/plugin.video.iptvxtra-malaisia/icon.png")
repo()

add_video_item(tv1,{ 'title': 'TV 1'},img = icondir + 'tv1.png')
add_video_item(tv2,{ 'title': 'TV 2'},img = icondir + 'tv2.png')
add_video_item(tv3,{ 'title': 'TV 3'},img = icondir + 'tv3.png')
add_video_item('http://ntv7liveios-i.akamaihd.net/hls/live/205902/ios/ntv7live/master002.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'NTV 7'},img = icondir + 'tv7.png')
add_video_item('http://8tvliveios-i.akamaihd.net/hls/live/205901/ios/8tvlive/master002.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': '8 TV'},img = icondir + 'tv8.png')
add_video_item('http://tv9liveios-i.akamaihd.net/hls/live/205903/ios/tv9live/master002.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'TV 9'},img = icondir + 'tv9.png')
add_video_item('http://d2f9tqsihrp4sc.cloudfront.net/livecf/smil:myStream.smil/playlist.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'Al-Hijrah'},img = icondir + 'alhi.png')
add_video_item(RTMTVi,{ 'title': 'RTM - TVi'},img = icondir + 'tvi.png')
add_video_item(RTMM,{ 'title': 'RTM - Muzik aktif'},img = icondir + 'muzik.png')
add_video_item(RTMPARLIMEN,{ 'title': 'RTM - Parliment TV'},img = icondir + 'parli.png')
add_video_item(einsnews,{ 'title': '1 news'},img = icondir + '1news.png')
add_video_item(Bernama,{ 'title': 'Bernama TV'},img = icondir + 'bern.png')
add_video_item(AKSISUKAN,{ 'title': 'Aksi Sukan'},img = icondir + 'sukan.png')
add_video_item(AstroAwani,{ 'title': 'Astro Awani'},img = icondir + 'astroawani.png')


#add_video_item('http://sat1liveios-i.akamaihd.net/hls/live/205904/ios/rtlive/master.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'RT Global'},img = icondir + 'rt.png')
#add_video_item('http://edge.nim.mivo.tv/kqcsmbqna6yg/trans72_all/playlist.m3u8',{ 'title': 'Indonesia Trans7'},img = icondir + 'trans7.png')
#add_video_item('http://d2r0h7tuevtvb8.cloudfront.net/live/ngrp:rtm-ch001.stream_all/playlist.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'RTM - TV 1'},img = icondir + 'tv1.png')
#add_video_item('http://d2r0h7tuevtvb8.cloudfront.net/live/ngrp:rtm-ch003.stream_all/playlist.m3u8|X-Forwarded-For=42.154.55.155',{ 'title': 'RTM - TV 2'},img = icondir + 'tv2.png')

xbmcplugin.endOfDirectory(plugin_handle)



















