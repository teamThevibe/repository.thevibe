'''
    Dovat.net (dovat.net) XBMC Plugin

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.		
'''

import os
import string
import sys
import re
import urlresolver
import xbmc, xbmcaddon, xbmcplugin, xbmcgui

from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

BASEURL = 'http://dovat.net'
MEDIA_REQ_URL = 'http://dovat.net/dovatnet/plugins/plugins_player.php'

addon_id = 'plugin.video.dovat'
addon = Addon(addon_id, sys.argv)

from xbmcads import ads
ads.ADDON_ADVERTISE(addon_id)

net = Net()


def AddSysPath(path):
    if path not in sys.path:
        sys.path.append(path)

#PATHS
AddonPath = addon.get_path()
LibsPath = os.path.join(AddonPath, 'resources', 'libs')
AddSysPath(LibsPath)

from ga import GA
ga = GA('plugin.video.dovat', 'UA-41026373-2')


mode = addon.queries['mode']
url = addon.queries.get('url', '')
title = addon.queries.get('title', '')
img = addon.queries.get('img', '')
typ = addon.queries.get('type', '')
historytitle = addon.queries.get('historytitle', '')
historylink = addon.queries.get('historylink', '')

def WatchedCallback():
    print 'Video completed successfully.'
    
def PlayUsingPBE(plugin, video_type, title, sourceurl, resolvedurl, watchedCallback,
                    img='', season='', episode='', year='', watch_percent=0.85, displayname=''):
                    
    import playbackengine
                    
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    
    if displayname == '':
        displayname = title
        
    listitem = xbmcgui.ListItem(displayname, iconImage=img, thumbnailImage=img)
    
    playlist.add(url=resolvedurl, listitem=listitem)
    
    player = playbackengine.Player(plugin=plugin, video_type=video_type, 
                            title=title,season=season, episode=episode, year=year,
                            watch_percent=watch_percent,watchedCallback=watchedCallback)
    
    player.play(playlist)
    while player._playbackLock.isSet():
        addon.log('Playback lock set. Sleeping for 250.')
        xbmc.sleep(250)
    

def unescape(text):
        try:            
            rep = {"&nbsp;": " ",
                   "\n": "",
                   "\t": "",                   
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            text = re.sub(r"<!--.+?-->", "", text)    
				
        except TypeError:
            pass

        return text



def MainMenu():  #home-page
    ga.GA("Main", "")
    
    addon.add_directory({'mode': 'Browse', 'url' : '', 'type' : 'Latest'}, {'title':  'Latest'})
    addon.add_directory({'mode': 'Menu', 'url': BASEURL, 'type' : 'WWE'}, {'title':  'WWE'})
    addon.add_directory({'mode': 'Menu', 'url': BASEURL, 'type' : 'Pay Per View'}, {'title':  'Pay Per View'})
    addon.add_directory({'mode': 'MenuLink', 'url': BASEURL, 'type' : 'UFC'}, {'title':  'UFC'})
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def Menu(url, typ):
    ga.GA(typ, "Main")
    
    url_content = net.http_GET(url).content
    
    rgxstr = r"(?s)>" + typ + "<.*?<ul>(.+?)</ul>"
    menu = re.search(rgxstr, url_content)
    if menu:
        menu = menu.group(1)
        menu = menu.decode('utf8')
        menu = addon.unescape(menu)
        menu = unescape(menu)		
        for item in re.finditer(r"<a.*?title=\"(.+?)\".*?href=\"(.+?)\".*?<img.*?src=\"(.+?)\" />", menu):
            item_title = item.group(1)
            item_url = item.group(2)
            item_img = item.group(3)
            item_img = item_img.replace("wwe_icon","wwe_logo")
            item_img = item_img.replace("wwesuperstars","wwe_superstars")
            item_img = item_img.replace(".png",".jpg")
            item_img = BASEURL + item_img
            addon.add_directory({'mode': 'Browse', 'url' : item_url, 'type' : typ}, {'title':  item_title}, img= item_img)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def MenuLink(url, typ):
    ga.GA(typ, "Main")
    
    url_content = net.http_GET(url).content
    
    rgxstr = r"<a.*?href=\"(.+?)\">" + typ + "<"
    menu = re.search(rgxstr, url_content)
    if menu:
        GetTitles(BASEURL + menu.group(1))


def GetTitles(url):
    ga.GA(typ, "Browse")
    
    url_content = net.http_GET(url).content
    
    items = re.search(r"(?s)<h3(.+?)footer", url_content)
    if items:
        items = items.group(1)
        
        #items = items.decode('utf8')
        #items = addon.unescape(items)
        items = unescape(items)		
        for item in re.finditer(r"<li> <a.*?href=\"(.+?)\".+?<img.*?src=\"(.+?)\".*?</a>.*?<h6.*?<a.*?title=\"(.+?)\".*?</a></h6>", items):
            item_url = BASEURL + item.group(1)
            item_img = BASEURL + item.group(2)
            item_title = item.group(3)
            addon.add_directory({'mode': 'GetLinks', 'url': item_url, 'title': item_title, 'img': item_img, 'type': typ }, {'title': item_title}, img= item_img)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def ReformatHostedMediaUrl(url):
    myurl = url

    myurl = myurl.replace("-nocookie", "")
    if re.search("\?", myurl):
        myurl = myurl[0:myurl.index('?')]

    return myurl

try:
    import watchhistory
except:
    import watchhistorydummy as watchhistory

wh = watchhistory.WatchHistory('plugin.video.dovat')

import playbackengine
        
def GetLinks(url):

    ga.GA(typ, "Links")
       
    url_content = net.http_GET(url).content

    check_for_hosted_media = re.search(r"(?s)large.*?<object.+?data=\"(.+?)\"", url_content)
    if check_for_hosted_media:        
        hosted_media_url = check_for_hosted_media.group(1)
        hosted_media_url = ReformatHostedMediaUrl(hosted_media_url)
        hosted_media = urlresolver.HostedMediaFile(url=hosted_media_url)
        if hosted_media:
            resolved_media_url = urlresolver.resolve(hosted_media_url)
            if resolved_media_url:
                ga.GA(typ, "Play")
                
                # add to watch history                               
                wh.add_directory(title, sys.argv[0]+sys.argv[2], img=img)
                if historylink:
                    wh.add_directory(historytitle, historylink, img=img, has_multiple_links=True)
                
                PlayUsingPBE('plugin.video.dovat', 'dovat', title, url, resolved_media_url, WatchedCallback, img=img)

    else:
        search_for_parts = re.search(r"(?s)<ul class=\"clearfix\">(.+?)ul>", url_content)
        if search_for_parts:
            parts = search_for_parts.group(1)
            parts = parts.decode('utf8')
            parts = addon.unescape(parts)
            parts = unescape(parts)			
            for part in re.finditer(r"<li.*?<a.*?href=\"(.+?)\".*?<span.*?>(.+?)</span>", parts):
                item_url = BASEURL + part.group(1)
                item_img = img
                item_title = title + " - " + part.group(2)
                addon.add_directory({'mode': 'GetMedia', 'url': item_url, 'title': item_title, 'img': item_img, 'type' : typ, 'historytitle': title, 'historylink': sys.argv[0]+sys.argv[2] }, {'title': item_title}, img= item_img)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        else:
            search_for_topdd = re.search(r"(?s)top-movies.*?<dd>(.+?)dd>", url_content)
            if search_for_topdd:
                dds = search_for_topdd.group(1)
                dds = dds.decode('utf8')
                dds = addon.unescape(dds)
                dds = unescape(dds)				
                for dd in re.finditer(r"<a.*?href=\"(.+?)\".*?>(.+?)</a>", dds):
                    item_url = BASEURL + dd.group(1)
                    item_img = img
                    item_title = title + " - " + dd.group(2)
                    addon.add_directory({'mode': 'GetLinks', 'url': item_url, 'title': item_title, 'img': item_img, 'type' : typ, 'historytitle': title, 'historylink': sys.argv[0]+sys.argv[2] }, {'title': item_title}, img= item_img)
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
            else:
                GetMedia(url)

def GetMedia(url):
    url_content = net.http_GET(url).content
    media_req_data = re.search(r"proxy\.link\=(.+?)\?feat\=directlink", url_content).group(1) + "?feat=directlink"
    media_response_data = net.http_POST(MEDIA_REQ_URL, {'url':media_req_data}).content

    media_url = ''
    media_size = 0
    
    media_content = re.search(r"(?s)\"media\":(.+?),\"description\":", media_response_data)
    if media_content:
        media_links = media_content.group(1)
        media_links = media_links.decode('utf8')
        media_links = addon.unescape(media_links)
        media_links = unescape(media_links)		
        for link in re.finditer("\"url\":\"(.+?)\",\"height\":(.+?),\"width\":(.+?),\"type\":\"(.+?)\"", media_links):

            if (link.group(4).startswith("image")):
                continue

            size = int(link.group(2)) + int(link.group(3))
            if (size <= media_size):
                continue

            media_url = link.group(1)
            media_size = size

    if media_url:
        ga.GA(typ, "Play")
        
        # add to watch history
        wh.add_directory(title, sys.argv[0]+sys.argv[2], img=img)
        if historylink:
            wh.add_directory(historytitle, historylink, img=img, has_multiple_links=True)
        
        PlayUsingPBE('plugin.video.dovat', 'dovat', title, url, media_url, WatchedCallback, img=img)
        
    
        
if mode == 'main': 
    MainMenu()
elif mode == 'Browse':
    if url:
        GetTitles(BASEURL + url)
    else:
        GetTitles(BASEURL)
elif mode == 'Menu':
    Menu(url, typ)
elif mode == 'MenuLink':
    MenuLink(url, typ)
elif mode == 'GetLinks':
    GetLinks(url)
elif mode == 'GetMedia':
    GetMedia(url)
elif mode == 'watchhistorysettings':    
    watchhistory.settings()