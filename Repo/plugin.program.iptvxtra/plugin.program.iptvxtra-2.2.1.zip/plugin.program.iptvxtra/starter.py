#!/usr/bin/python
# -*- coding: utf-8 -*-

import os,sys,xbmc,xbmcgui,xbmcaddon

xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.program.iptvxtra/?start)')

