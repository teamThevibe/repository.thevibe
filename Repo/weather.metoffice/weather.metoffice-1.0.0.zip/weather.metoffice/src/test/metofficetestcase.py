import os
from xbmctestcase import XBMCTestCase

class MetOfficeTestCase(XBMCTestCase):    

    TEST_FOLDER = os.path.dirname(__file__)
    RESULTS_FOLDER = os.path.join(TEST_FOLDER, 'results')
    DATA_FOLDER = os.path.join(TEST_FOLDER, 'data')

    def setUp(self):
        super(MetOfficeTestCase, self).setUp()

        from metoffice import constants
        self.constants = constants
        from metoffice import utilities
        self.utilities = utilities
        from metoffice import urlcache
        self.urlcache = urlcache        
        from metoffice import properties
        self.properties = properties
        from metoffice import setlocation
        self.setlocation = setlocation
        from metoffice import default
        self.default = default
        
        self.constants.ADDON_DATA_PATH = self.DATA_FOLDER        
        self.constants.API_KEY = '12345'
        self.constants.GEOIP = '0'
        self.constants.GEOIP_PROVIDER = self.constants.GEOIP_PROVIDERS[0]
        self.constants.FORECAST_LOCATION = 'CAMBRIDGE  NIAB'
        self.constants.FORECAST_LOCATION_ID = '99123'
        
    def mock_getSetting(self, s):
        return {'ApiKey' : '12345',
         'GeoIPProvider' : '0',
         'ForecastLocation' : 'CAMBRIDGE  NIAB',
         'ForecastLocationID' : '99123',
         'ObservationLocation' : '3560'}[s]
        