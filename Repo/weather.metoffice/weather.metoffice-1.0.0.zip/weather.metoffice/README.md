weather.metoffice
=================

Weather plugin for XBMC. Fetches data from the UK Met Office.
