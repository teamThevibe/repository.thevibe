# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''

__USERAGENT__ = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
__BASE_URL__ = 'http://switch248-01.castup.net/cunet/gm.asp?ai=385&ar=BipLiveFLV'
__NAME__ = 'bip'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_bip:
    
    def __init__(self):
        self.MODES = common.enum(GET_CHANNEL=1)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CHANNEL):
            self.getChannelStream()
            
    def getChannelStream(self):
        page = common.getData(__BASE_URL__)
        videoData = page.replace("rtmpt", "rtmp")       
        if len(videoData) > 0:
            videoUrl = videoData
            listItem = xbmcgui.ListItem(__NAME__, 'DefaultFolder.png', 'DefaultFolder.png', path=videoUrl)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            listItem.setInfo(type='Video', infoLabels={ "Title": __NAME__, "Plot": 'Live!!!'})
            listItem.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)