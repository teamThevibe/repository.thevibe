# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''

__BASE_URL__ = 'http://video.walla.co.il/'
__NAME__ = 'channel11'
__PATTERN__ = 'class="block w2b fclr1 mrg_t4" href="(.+?)"'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_channel11:
    
    def __init__(self):
        self.MODES = common.enum(GET_SERIES_LIST=1, GET_EPISODES_LIST=2)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_SERIES_LIST):
            self.getSeriesList()
        elif(mode==self.MODES.GET_EPISODES_LIST):
            common.getEpisodeList(__BASE_URL__, url, __PATTERN__, __NAME__, self.MODES.GET_EPISODES_LIST)
            
    def getSeriesList(self):
        ## get all the series from an array of series....
        series = (__BASE_URL__ + '?w=//1516077', 
                  __BASE_URL__ + '?w=//1505480',
                  __BASE_URL__ + '?w=//1600365',
                  __BASE_URL__ + '?w=//1615796',
                  __BASE_URL__ + '?w=//1644778',
                  __BASE_URL__ + '?w=//1508071',
                  __BASE_URL__ + '?w=//1666172',
                  __BASE_URL__ + '?w=//1741642',
                  __BASE_URL__ + '?w=//1741591',
                  __BASE_URL__ + '?w=//1731897',
                  __BASE_URL__ + '?w=//1736667',
                  __BASE_URL__ + '?w=//1744992',
                  __BASE_URL__ + '?w=//1737077',
                  __BASE_URL__ + '?w=//1742710',
                  __BASE_URL__ + '?w=//1739582',
                  __BASE_URL__ + '?w=//1739561',
                  __BASE_URL__ + '?w=//1730186',
                  __BASE_URL__ + '?w=//1791090',
                  __BASE_URL__ + '?w=//1761630')
        
        for seriesUrl in series:
            page = common.getData(seriesUrl)
            details = re.compile('class="w3" style="margin-left:288px;">(.*?)<span class="wcflow">').findall(page)
            if (len(details)) > 0:
                text = re.compile('<div>(.+?)</').findall(details[0])
                summary = ''
                for txtItem in text:
                    summary += ' ' + txtItem
            else:
                summary = ''
            image = re.compile('class="block zoom1 mediawrap".*?<img .*?src="(.+?)"').findall(page)
            if len(image) > 0:
                iconImage = image[0]
            else:
                iconImage = 'DefaultFolder.png'
                
            fanartImage = re.compile('class="vbox720x330" src="(.+?)" alt="(.*?)"').findall(page)            
            if not fanartImage == None:
                fanart = fanartImage[0][0]
                title = fanartImage[0][1]
                urlMatch = re.compile('class="right in_blk" style=.*?href="(.+?)"').findall(page)
                if (len(urlMatch)) > 0:
                    common.addDir(title, __BASE_URL__ + urlMatch[0], self.MODES.GET_EPISODES_LIST, iconImage, __NAME__, summary, fanart)                    
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')