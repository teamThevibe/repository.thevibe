##########test########

import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import urllib, urllib2
import re, string, sys, os
import urlresolver
from TheYid.common.addon import Addon
from TheYid.common.net import Net
from htmlentitydefs import name2codepoint as n2cp
import HTMLParser

addon_id = 'plugin.video.ZstreamingER'
plugin = xbmcaddon.Addon(id=addon_id)
DB = os.path.join(xbmc.translatePath("special://database"), 'ZstreamingER.db')
BASE_URL = 'http://www.ztreaming.net/'
BASE_URL1 = 'http://www.ztreamingseries.cf/'
net = Net()
addon = Addon('plugin.video.ZstreamingER', sys.argv)

###### PATHS ###########
AddonPath = addon.get_path()
IconPath = AddonPath + "/icons/"
FanartPath = AddonPath + "/icons/"

##### Queries ##########
mode = addon.queries['mode']
url = addon.queries.get('url', None)
content = addon.queries.get('content', None)
query = addon.queries.get('query', None)
startPage = addon.queries.get('startPage', None)
numOfPages = addon.queries.get('numOfPages', None)
listitem = addon.queries.get('listitem', None)
urlList = addon.queries.get('urlList', None)
section = addon.queries.get('section', None)
img = addon.queries.get('img', None)

################################################################################# Titles #################################################################################

def GetTitles(section, url, img): # Get Movie & tv show Titles
    try:
        pageUrl = url
        print pageUrl
        html = net.http_GET(pageUrl).content
        match = re.compile('''<h2 class='post-title entry-title'>\s*?<a href='(.+?)'>(.+?)</a>.+?.+? src="(.+?)"''', re.DOTALL).findall(html)
        match1 = re.compile("<a class='blog-pager-older-link' href='(.+?)' id='Blog1_blog-pager-older-link' title='Next Product'>Next Movie &#187;</a>", re.DOTALL).findall(html)
        for movieUrl, name, img in match:
                name = name.replace('Free Online Streaming', '')
                addon.add_directory({'mode': 'GetLinks', 'section': section, 'url': movieUrl, 'img': img}, {'title':  name.strip()}, img= img, fanart=FanartPath + 'fanart.jpg')
        for movieUrl in match1:
                addon.add_directory({'mode': 'GetTitles', 'section': section, 'url': movieUrl}, {'title': '[COLOR blue][B][I]Next page...[/B][/I][/COLOR]'}, img=IconPath + 'nextpage1.png', fanart=FanartPath + 'fanart.jpg')
        setView('tvshows', 'tvshows-view')
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red][B]Sorry site mite be down [/B][/COLOR],[COLOR blue][B]Please try later[/B][/COLOR],7000,"")")
       	xbmcplugin.endOfDirectory(int(sys.argv[1]))

#\s*?#
############################################################################### Get links #############################################################################################

def GetLinks(section, url, img):
    try:
        print 'GETLINKS FROM URL: '+url
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html
        match = re.compile('href="(https://openload.co.+?)"').findall(content)
        match1 = re.compile('src="(https://openload.co.+?)"').findall(content)
        match2 = re.compile('<a href="(.+?)">Trailer</a></div>').findall(content)
        listitem = GetMediaInfo(content)
        for url in match + match1 + match2:
                host = GetDomain(url)
                if 'Unknown' in host:
                                continue

                r = re.search('\.srt[(?:\.html|\.htm)]*', url, re.IGNORECASE)
                if r:
                        continue
                print '*****************************' + host + ' : ' + url
                if urlresolver.HostedMediaFile(url= url):
                        print 'in GetLinks if loop'
                        title = url.rpartition('/')
                        title = title[2].replace('.html', '')
                        title = title.replace('.htm', '')
                        title = title.replace('.', ' ')
                        title = title.replace('_', ' ')
                        title = title.replace('Trailer', '[COLOR lime]Trailer[/COLOR]')
                        host = host.replace('youtube.com','[COLOR red]YouTube Trailer[/COLOR]')
                        host = host.replace('youtu.be','[COLOR rsd]YouTube Trailer[/COLOR]')
                        host = host.replace('.net','')
                        host = host.replace('.com','')
                        addon.add_directory({'mode': 'PlayVideo', 'url': url, 'listitem': listitem}, {'title': '[B]' + title + '[/B]' + ' : ' + host}, img= img, fanart=FanartPath + 'fanart.jpg')
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red][B]Sorry no links [/B][/COLOR],[COLOR blue][B]Please try a different movie/tv show[/B][/COLOR],7000,"")")
       	xbmcplugin.endOfDirectory(int(sys.argv[1]))

############################################################################# Play Video #####################################################################################

def PlayVideo(url, listitem):
    try:
        print 'in PlayVideo %s' % url
        stream_url = urlresolver.HostedMediaFile(url).resolve()
        xbmc.Player().play(stream_url)
        addon.add_directory({'mode': 'help'}, {'title':  '[COLOR slategray][B]^^^ Press back ^^^[/B] [/COLOR]'},'','')
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red][B]Sorry Link may have been removed ![/B][/COLOR],[COLOR lime][B]Please try a different link/host !![/B][/COLOR],7000,"")")


def GetDomain(url):
        tmp = re.compile('//(.+?)/').findall(url)
        domain = 'Unknown'
        if len(tmp) > 0 :
            domain = tmp[0].replace('www.', '')
        return domain

def GetMediaInfo(html):
        listitem = xbmcgui.ListItem()
        match = re.search('og:title" content="(.+?) \((.+?)\)', html)
        if match:
                print match.group(1) + ' : '  + match.group(2)
                listitem.setInfo('video', {'Title': match.group(1), 'Year': int(match.group(2)) } )
        return listitem

###################################################################### menus ####################################################################################################

def MainMenu():    #homescreen
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/'}, {'title':  '[COLOR blue][B]Movies :[/B][/COLOR] Latest'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/compilation',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[COLOR blue][B]Movies :[/B][/COLOR] Compilation'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'menu1'}, {'title': '[COLOR blue][B]Movies :[/B][/COLOR] Movies Genres'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetSearchQuery1'},  {'title':  '[COLOR blue][B]Movies :[/B][/COLOR] [COLOR green]Search[/COLOR]'}, img=IconPath + 'movs.png', fanart=FanartPath + 'fanart.jpg')

        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL1 + '/',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[COLOR pink][B]Tv Shows :[/B][/COLOR] Latest Episodes'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'menu2'}, {'title': '[COLOR pink][B]Tv Shows :[/B][/COLOR] Seasons A/Z'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetSearchQuery'},  {'title':  '[COLOR pink][B]Tv Shows :[/B][/COLOR] [COLOR green]Search[/COLOR]'}, img=IconPath + 'tvs.png', fanart=FanartPath + 'fanart.jpg')

        addon.add_directory({'mode': 'ResolverSettings'}, {'title':  '[COLOR red]Resolver Settings[/COLOR]'}, img=IconPath + 'url1.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'ResolverSettings'}, {'title':  '[B][COLOR yellow] www.entertainmentrepo.com  [/B][/COLOR]'}, img=IconPath + 'newart.jpg', fanart=IconPath +  'newart.jpg')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))



def Menu1():
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/action',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Action[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/drama',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Drama[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/animation',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Animation[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/horror',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Horror[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/sci-fi',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]sci-fi[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL + '/search/label/comedy',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Comedy[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')

        addon.add_directory({'mode': 'GetLinks', 'section': 'ALL', 'url': BASE_URL + '/2015/11/compilation-movies-by-request-001.html',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Compilation Movies by Request - (001)[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetLinks', 'section': 'ALL', 'url': BASE_URL + '/2015/11/compilation-movies-by-request-002.html',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]Compilation Movies by Request - (002)[/B] >>'}, img=IconPath + 'mov.png', fanart=FanartPath + 'fanart.jpg')

        xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Menu2():
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL1 + '/search/label/ABCDEFG',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]ABCDEFG[/B] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL1 + '/search/label/HIJKLMN?max-results=9999',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]HIJKLMN[/B] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL1 + '/search/label/OPQRSTU?max-results=9999',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]OPQRSTU[/B] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles', 'section': 'ALL', 'url': BASE_URL1 + '/search/label/VWXYZNUMBER?max-results=9999',
                             'startPage': '1', 'numOfPages': '1'}, {'title':  '[B]VWXYZ & Numbers[/B] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

######################################################################## search #################################################################################################

def GetSearchQuery():            #tv
	last_search = addon.load_data('search')
	if not last_search: last_search = ''
	keyboard = xbmc.Keyboard()
        keyboard.setHeading('Search')
	keyboard.setDefault(last_search)
	keyboard.doModal()
	if (keyboard.isConfirmed()):
                query = keyboard.getText()
                addon.save_data('search',query)
                Search(query)
	else:
                return

def Search(query):
        url = 'http://www.ztreamingseries.cf/search?q=' + query
        url = url.replace(' ', '+')
        print url
        html = net.http_GET(url).content
        match = re.compile("<h2 class='post-title entry-title'>\s*?<a href='(.+?)'>(.+?)Free Online Streaming</a>").findall(html)
        for url, title in match:
                addon.add_directory({'mode': 'GetLinks', 'url': url, 'img': IconPath +  'newart.jpg'}, {'title':  title}, img=IconPath +  'newart.jpg', fanart=IconPath +  'newart.jpg')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

def GetSearchQuery1():            #movie
	last_search = addon.load_data('search')
	if not last_search: last_search = ''
	keyboard = xbmc.Keyboard()
        keyboard.setHeading('Search')
	keyboard.setDefault(last_search)
	keyboard.doModal()
	if (keyboard.isConfirmed()):
                query = keyboard.getText()
                addon.save_data('search',query)
                Search1(query)
	else:
                return

def Search1(query):
        url = 'http://www.ztreaming.net/search?q=' + query
        url = url.replace(' ', '+')
        print url
        html = net.http_GET(url).content
        match = re.compile("<h2 class='post-title entry-title'>\s*?<a href='(.+?)'>(.+?)Free Online Streaming</a>").findall(html)
        for url, title in match:
                addon.add_directory({'mode': 'GetLinks', 'url': url, 'img': IconPath +  'newart.jpg'}, {'title':  title}, img=IconPath +  'newart.jpg', fanart=IconPath +  'newart.jpg')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

#################################################################################################################################################################################

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )

#########################################################################################################################################################################

if mode == 'main': 
	MainMenu()
if mode == 'menu1':
       Menu1()
if mode == 'menu2':
       Menu2()
elif mode == 'GetTitles': 
	GetTitles(section, url, img)
elif mode == 'GetLinks':
	GetLinks(section, url, img)
elif mode == 'GetSearchQuery':
	GetSearchQuery()
elif mode == 'Search':
	Search(query)
elif mode == 'GetSearchQuery1':
	GetSearchQuery1()
elif mode == 'Search1':
	Search1(query)
elif mode == 'PlayVideo':
	PlayVideo(url, listitem)	
elif mode == 'ResolverSettings':
        urlresolver.display_settings()
xbmcplugin.endOfDirectory(int(sys.argv[1]))