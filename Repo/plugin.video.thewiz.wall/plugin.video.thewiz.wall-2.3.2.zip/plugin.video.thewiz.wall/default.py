#!/usr/bin/python
import urllib, sys, os
import xbmcaddon, xbmcplugin, xbmcgui
import updatesetting, sync

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources'))
from pyga.ga import track_event, track_page

addonID = "plugin.video.thewiz.wall"
Addon = xbmcaddon.Addon(addonID)
AddonName = Addon.getAddonInfo("name")

def getParams(arg):
	param=[]
	paramstring=arg
	if len(paramstring)>=2:
		params=arg
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:    
				param[splitparams[0]]=splitparams[1]
							
	return param

def getParam(name,params):
	try:
		return urllib.unquote_plus(params[name])
	except:
		pass

def PlayUrl(name, url, iconimage=None):
   listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
   listitem.setInfo(type="Video", infoLabels={ "Title": name })
   xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

wall=None
if len(sys.argv) >= 2:   
	params = getParams(sys.argv[2])
	wall=getParam("wall", params)

if wall is None:
	Addon.openSettings()
	updatesetting.main()
elif (wall == "update"):
	sync.main()
elif (wall == "movies"):
	imdb = getParam("imdb",params)
	trakt = getParam("trakt",params)
	year = getParam("year",params)
	name = getParam("name",params)
	title = getParam("title",params)
	url = getParam("url",params)
	slug = getParam("slug",params)

	streamAddon = Addon.getSetting("StreamMovies")
	directPlay = Addon.getSetting("DirectPlay")

	if (streamAddon=="Genesis"):
		stream ="plugin://plugin.video.genesis/?action=play&imdb={0}&year={1}&name={2}&title={3}&url={4}".format(imdb[2:],year,name.replace(' ','%20'),title.replace(' ','%20'),url)
	if (streamAddon=="Exodus"):
		stream ="plugin://plugin.video.exodus/?action=play&imdb={0}&year={1}&name={2}&title={3}&url={4}".format(imdb[2:],year,name.replace(' ','%20'),title.replace(' ','%20'),url)
	if (streamAddon=="Pulsar"):
		if (directPlay=="false"):
			stream ="plugin://plugin.video.pulsar/movie/{0}/play".format(imdb)
		else:
			stream ="plugin://plugin.video.pulsar/movie/{0}/links".format(imdb)
	if (streamAddon=="Quasar"):
		if (directPlay=="false"):
			stream ="plugin://plugin.video.quasar/movie/{0}/play".format(imdb)
		else:
			stream ="plugin://plugin.video.quasar/movie/{0}/links".format(imdb)
	if (streamAddon=="SALTS"):
		stream ="plugin://plugin.video.salts/?trakt_id={0}&dialog=True&mode=get_sources&video_type=Movie&title={1}&year={2}&slug={3}".format(trakt,title.replace(' ','+'),year,slug)
	if (streamAddon=="UMP"):
		stream ='plugin://plugin.program.ump/?info={"code": "'+format(imdb)+'","originaltitle": "'+title.replace(' ','%20')+'","title": "'+title.replace(' ','%20')+'"}&args={}&module=imdb&content_type=video&page=urlselect'
	PlayUrl(name, stream)
	print "*** {0}: Wall.Play: Movie({1} - {2}) {3} ".format(AddonName,imdb,title,streamAddon)
	track_event("movie", "play", title.replace("+", " "), streamAddon)
	track_page("/movie"+"/{0} ({1})/{2}".format(title.replace("+", " "),year,streamAddon))
	
elif (wall == "tv"):
	date = getParam("date",params)
	episode = getParam("episode",params)
	trakt = getParam("trakt",params)
	genre = getParam("genre",params)
	imdb = getParam("imdb",params)
	name = getParam("name",params)
	season = getParam("season",params)
	show = getParam("show",params)
	title = getParam("title",params)
	tvdb = getParam("tvdb",params)
	year = getParam("year",params)
	#title_salts = getParam("title_salts",params)
	year = getParam("year",params)
	slug = getParam("slug",params)
	
	streamAddon = Addon.getSetting("StreamTV")
	directPlay = Addon.getSetting("DirectPlay")

	if (streamAddon=="Genesis"):
		stream ="plugin://plugin.video.genesis/?action=play&alter=0&date={0}&episode={1}&imdb={2}&name={3}&season={4}&tvshowtitle={5}&tvdb={6}&year={7}".format(0,episode,imdb,name.replace(' ','%20'),season,title,tvdb,year)
	if (streamAddon=="Exodus"):
		stream ="plugin://plugin.video.exodus/?action=play&alter=0&date={0}&episode={1}&imdb={2}&name={3}&season={4}&tvshowtitle={5}&tvdb={6}&year={7}".format(0,episode,imdb,name.replace(' ','%20'),season,title,tvdb,year)
	if (streamAddon=="Pulsar"):
		if (directPlay=="false"):
			stream ="plugin://plugin.video.pulsar/show/{0}/season/{1}/episode/{2}/play".format(tvdb,season,episode)
		else:
			stream ="plugin://plugin.video.pulsar/show/{0}/season/{1}/episode/{2}/links".format(tvdb,season,episode)
	if (streamAddon=="Quasar"):
		if (directPlay=="false"):
			stream ="plugin://plugin.video.quasar/show/{0}/season/{1}/episode/{2}/play".format(tvdb,season,episode)
		else:
			stream ="plugin://plugin.video.quasar/show/{0}/season/{1}/episode/{2}/links".format(tvdb,season,episode)
	if (streamAddon=="SALTS"):
		stream ="plugin://plugin.video.salts/?ep_airdate=2012-05-14&episode={0}&dialog=True&title={1}&ep_title=NULL&season={2}&video_type=Episode&mode=get_sources&year={3}&trakt_id={4}".format(episode,title,season,year,trakt)
 
	PlayUrl(name, stream) 	
	print "*** {0}: Wall.Play: TV({1} - {2}) {3} ".format(AddonName,tvdb,name,streamAddon)
	track_event("tv", "play", name.replace("+", " ") ,streamAddon)
	track_page('/tv/{0}/S{1}/E{2}/{3}'.format(show.replace("+", " "),str(season).zfill(2),str(episode).zfill(2),streamAddon))
	