import urllib,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
import urlresolver
import requests
from addon.common.addon import Addon
from addon.common.net import Net
from metahandler import metahandlers




#badassmovies4u - By Mucky Duck (10/2015)




addon_id='plugin.video.badassmovies'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
Addon = xbmcaddon.Addon(addon_id)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
baseurl150 = 'http://www.badassmovies4u.com/'
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData(preparezip=False)
net = Net()




def CAT():
        addDir('[COLOR cyan]All-Sports[/COLOR]',baseurl150+'/forumdisplay.php?19-All-Sports',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Pay-Per-View-Free[/COLOR]',baseurl150+'/forumdisplay.php?6-Pay-Per-View-Free',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Horror-Movies-And-More-Section[/COLOR]',baseurl150+'/forumdisplay.php?21-Horror-Movies-And-More-Section',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Documentaries[/COLOR]',baseurl150+'/forumdisplay.php?14-Documentaries',151,art+'bad.png',art+'f1.jpg','')
        #addDir('TV-Shows-New-Seasons',baseurl150+'/forumdisplay.php?11-TV-Shows-New-Seasons',151,art+'badi.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Animation[/COLOR]',baseurl150+'/forumdisplay.php?15-Animation',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]2015-2014-Movies[/COLOR]',baseurl150+'/forumdisplay.php?3-2015-2014-Movies',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]2013-2010[/COLOR]',baseurl150+'/forumdisplay.php?7-2013-2010',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]2009-2000[/COLOR]',baseurl150+'/forumdisplay.php?8-2009-2000',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]90s-and-Older[/COLOR]',baseurl150+'/forumdisplay.php?9-90s-and-Older',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Badass-Movie-Boxsets[/COLOR]',baseurl150+'/forumdisplay.php?20-Badass-Movie-Boxsets',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Music-and-Concerts[/COLOR]',baseurl150+'/forumdisplay.php?10-Music-and-Concerts',151,art+'bad.png',art+'f1.jpg','')
        addDir('[COLOR cyan]Foreign-Movies[/COLOR]',baseurl150+'/forumdisplay.php?22-Foreign-Movies',151,art+'bad.png',art+'f1.jpg','')




def BADASSINDEX(url):
        link = OPEN_URL(url)
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('class="title" href="(.*?)" id=".*?">(.*?)</a>').findall(link)
        items = len(match)
        for url,name in match:
                if 'How To Watch' not in name:
                        if 'There is No Mal' not in name:
                                name = name.replace('Help Badassmovies Facebook Page Like Us Please!!!!!','[COLOR cyan]Help Badassmovies Facebook Page Like Us Please!!!!![/COLOR]')
                                name = name.replace('&amp;','&')
                                addDir2(name,baseurl150+url,152,'',items)
        try:
                url=re.compile('<span class="prev_next"><a rel="next" href="(.+?)" title=".+?">').findall(link)
                url = url[0]
                name=re.compile('<span class="prev_next"><a rel="next" href=".+?" title="(.+?)">').findall(link)
                name = name[0]
                addDir('[COLOR cyan]%s[/COLOR]' %name,baseurl150+url,151,art+'bad.png',art+'f1.jpg','')
        except: pass
        setView('movies', 'movie-view')




def BADASSLINKS(url,name):
        link = OPEN_URL(url)
        match = re.compile('<a href="(.+?)" target="_blank">.+?</a><br />').findall(link)
        match1 = re.compile('<IFRAME SRC="(.+?)" .+?></IFRAME>').findall(link)
        match2 = re.compile('<iframe src="(.+?)" .+?></iframe>').findall(link)
        try:
                for url in match1:
                        if 'youtube' not in url:
                                addDir2(name,url,1,'',len(match))
        except: pass
        try:
                for url in match2:
                        if 'youtube' not in url:
                                addDir2(name,url,1,'',len(match))
        except: pass
        for url in match:
                nono = 'www.imdb.com'
                nono2 = 'http://www.badassmovies4u.com/'
                if nono not in url:
                        print url
                        if nono2 not in url:
                                addDir2(name,url,1,'',len(match))




def regex_from_to(text, from_string, to_string, excluding=True):
        if excluding:
                try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
                except: r = ''
        else:
                try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
                except: r = ''
        return r




def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r            




def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot":description} )
        liz.setProperty('fanart_image', fanart)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def addDir2(name,url,mode,iconimage,itemcount):
        if metaset=='true':
                splitName=name.partition('(')
                simplename=""
                simpleyear=""
                if len(splitName)>0:
                        simplename=splitName[0]
                        simpleyear=splitName[2].partition(')')
                if len(simpleyear)>0:
                        simpleyear=simpleyear[0]
                meta = metaget.get_meta('movie', simplename ,simpleyear)
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
                liz.setInfo( type="Video", infoLabels= meta )
                contextMenuItems = []
                contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
                if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
                else: liz.setProperty('fanart_image', fanart)
                if mode==1:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok
        else:
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                liz.setProperty('fanart_image', fanart)
                if mode==1:
                        liz.setProperty("IsPlayable","true")
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
                else:
                        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
                return ok




def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok




def addLink2(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)




def OPEN_URL(url):
        headers = {}
        name = ''
        headers['User-Agent'] = User_Agent
        link = requests.get(url, headers=headers).text
        return link




def RESOLVE(name,url):
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




def setView(content, viewType):
        ''' Why recode whats allready written and works well,
        Thanks go to Eldrado for it '''

        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        #if addon.get_setting('auto-view') == 'true':

        #    print addon.get_setting(viewType)
        #    if addon.get_setting(viewType) == 'Info':
        #        VT = '515'
        #    elif addon.get_setting(viewType) == 'Wall':
        #        VT = '501'
        #    elif viewType == 'default-view':
        #        VT = addon.get_setting(viewType)

        #    print viewType
        #    print VT
        
        #    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

           
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
site=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
        
if mode==None or url==None or len(url)<1:
        CAT()

elif mode==1:
        RESOLVE(name,url)

elif mode==151:
        BADASSINDEX(url)

elif mode==152:
        BADASSLINKS(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
