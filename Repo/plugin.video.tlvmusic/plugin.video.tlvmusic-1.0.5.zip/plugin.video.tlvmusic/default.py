# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The TLVmusic Addon by TLVkodi | www.tlvkodi.com
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: TLV kodi 2016 © Tsvika Levy
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.tlvmusic'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "XFactorIsrael"
YOUTUBE_CHANNEL_ID_2 = "MiriMesikaOfficial"
YOUTUBE_CHANNEL_ID_3 = "IvriLiderOfficial"
YOUTUBE_CHANNEL_ID_4 = "idanraichelofficial"
YOUTUBE_CHANNEL_ID_5 = "DavidBrozaOfficial"
YOUTUBE_CHANNEL_ID_6 = "ShiriMaimonOfficial"
YOUTUBE_CHANNEL_ID_7 = "DuduAharonOfficiaI"
YOUTUBE_CHANNEL_ID_8 = "MoshePerezOfficial"
YOUTUBE_CHANNEL_ID_9 = "skaatharel"
YOUTUBE_CHANNEL_ID_10 = "UCnxi9xQjbnfZLm_gCHj_SEg"
YOUTUBE_CHANNEL_ID_11 = "peertasimizrahi"
YOUTUBE_CHANNEL_ID_12 = "EyalGolanOfficial"
YOUTUBE_CHANNEL_ID_13 = "KerenPelesOfficial"
YOUTUBE_CHANNEL_ID_14 = "ShlomoArtziOfficial"
YOUTUBE_CHANNEL_ID_15 = "Mashinaofficial"
YOUTUBE_CHANNEL_ID_16 = "OfficialKaveret"
YOUTUBE_CHANNEL_ID_17 = "ArikEinsteinOfficial"
YOUTUBE_CHANNEL_ID_18 = "SaritHadadOfficial"
YOUTUBE_CHANNEL_ID_19 = "UCpVnrlDrQzDpNeLWAXXaETQ"
YOUTUBE_CHANNEL_ID_20 = "UCA3PKEDZ9cEqpi6AnLImgJw"
YOUTUBE_CHANNEL_ID_21 = "ritaofficial"
YOUTUBE_CHANNEL_ID_22 = "RonaKenan"
YOUTUBE_CHANNEL_ID_23 = "Nuritgalron"
YOUTUBE_CHANNEL_ID_24 = "shlomishabatofficiaI"
YOUTUBE_CHANNEL_ID_25 = "TheKobiAflalo"
YOUTUBE_CHANNEL_ID_26 = "sagivoni"
YOUTUBE_CHANNEL_ID_27 = "YuvalDayanOfficial"
YOUTUBE_CHANNEL_ID_28 = "UCVwuUVYdMTKRWjT2xSPwUwQ"
YOUTUBE_CHANNEL_ID_29 = "EhudBanaiOfficial"
YOUTUBE_CHANNEL_ID_30 = "4tisTV"
YOUTUBE_CHANNEL_ID_31 = "BalkanBeatBoxChannel"
YOUTUBE_CHANNEL_ID_32 = "UCe4eKg7jM1iLKizaHXXatYw"
YOUTUBE_CHANNEL_ID_33 = "UC_sZP_Qv3gVUQjOtBqUkJtg"
YOUTUBE_CHANNEL_ID_34 = "YehuditRavitzChannel"
YOUTUBE_CHANNEL_ID_35 = "MoshBA1"
YOUTUBE_CHANNEL_ID_36 = "ArkadiDuchinOfficial"
YOUTUBE_CHANNEL_ID_37 = "Avivarchive"
YOUTUBE_CHANNEL_ID_38 = "ShalomHanoch"
YOUTUBE_CHANNEL_ID_39 = "sakharofficial"
YOUTUBE_CHANNEL_ID_40 = "UChV4_Q6R4edNRfMoQiOHa7A"
YOUTUBE_CHANNEL_ID_41 = "UCJY2GRQceo0i_zskTXs3pmg"
YOUTUBE_CHANNEL_ID_42 = "InternationalDana"
YOUTUBE_CHANNEL_ID_43 = "zilberariel"
YOUTUBE_CHANNEL_ID_44 = "MeirBanai"
YOUTUBE_CHANNEL_ID_45 = "TeapacksIL"
YOUTUBE_CHANNEL_ID_46 = "EthnixOfficial"
YOUTUBE_CHANNEL_ID_47 = "hadagnahashofficial"
YOUTUBE_CHANNEL_ID_48 = "danabergerofficial"
YOUTUBE_CHANNEL_ID_49 = "ayot718"
YOUTUBE_CHANNEL_ID_50 = "YardenaAraziMusic"
YOUTUBE_CHANNEL_ID_51 = "ChavaAlbersteinMusic"
YOUTUBE_CHANNEL_ID_52 = "LiorNarkisOfficial"
YOUTUBE_CHANNEL_ID_53 = "EviatarBanaiOfficial"
YOUTUBE_CHANNEL_ID_54 = "MusicKarolina"
YOUTUBE_CHANNEL_ID_55 = "UCt927ZDEsYMJL_8PXqMiVhg"
YOUTUBE_CHANNEL_ID_56 = "RamiKleinshteinMusic"
YOUTUBE_CHANNEL_ID_57 = "didapelledmusic"
YOUTUBE_CHANNEL_ID_58 = "mayabos"
YOUTUBE_CHANNEL_ID_59 = "idanyanivmusic"
YOUTUBE_CHANNEL_ID_60 = "TheYehudapoliker"
YOUTUBE_CHANNEL_ID_61 = "BenArtziChannel"
YOUTUBE_CHANNEL_ID_62 = "UCFAgeEWkjTrI_E47w7fO3xw"


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="X Factor Israel",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-HmlBbzZ1JQ8/AAAAAAAAAAI/AAAAAAAAAAA/EmBr1CVA29I/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מירי מסיקה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/i/7cwmZGtlWPDkkEWsxkZd-Q/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עברי לידר",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-dcDK_SlCZkg/AAAAAAAAAAI/AAAAAAAAAAA/FUC0PJKbieU/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עידן רייכל",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-vsBWN1RBQuk/AAAAAAAAAAI/AAAAAAAAAAA/SWZEbbG5oUY/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="דיויד ברוזה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-jqmb120ys0o/AAAAAAAAAAI/AAAAAAAAAAA/okV8-ozgQU8/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="שירי מימון",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-33p31sJqT88/AAAAAAAAAAI/AAAAAAAAAAA/taeHwLul6Io/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="דודו אהרון",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-0orZ08za-yw/AAAAAAAAAAI/AAAAAAAAAAA/5axG6k56St4/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="משה פרץ",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.ytimg.com/i/0ebT4a-IyuY61X8py3nzsg/mq1.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="הראל סקעת",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.ytimg.com/i/BbOw6LiHmj6L9o_HlMvKKg/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מוקי",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-AsTNHQK9-Eo/AAAAAAAAAAI/AAAAAAAAAAA/bSK6tfXXF1E/s176-c-k-no/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="פאר טסי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-XdArdL_W374/AAAAAAAAAAI/AAAAAAAAAAA/phGLZNk8iwU/s176-c-k-no/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="אייל גולן",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-PV5wpA_XiiY/AAAAAAAAAAI/AAAAAAAAAAA/XCOsoSqKASA/s176-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="קרן פלס",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-g-vBfZegycg/AAAAAAAAAAI/AAAAAAAAAAA/3_4Cd3tCOvM/s176-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="שלמה ארצי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.ytimg.com/i/QHzG2gtNfXp4yo6_I46eCw/mq1.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="משינה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-YMMH8p86Qgk/AAAAAAAAAAI/AAAAAAAAAAA/CgHtHDzT1L0/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="כוורת",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-GnJdbs1R77k/AAAAAAAAAAI/AAAAAAAAAAA/rMsr-BxeKqQ/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אריק אינשטיין",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-70TuUnUpj4I/AAAAAAAAAAI/AAAAAAAAAAA/ygRu0cv77QM/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="שרית חדד",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/-rirhhHRwKlU/AAAAAAAAAAI/AAAAAAAAAAA/sJyejBLp0fs/s176-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ריקי גל",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.ytimg.com/i/pVnrlDrQzDpNeLWAXXaETQ/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="יהורם גאון",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.ytimg.com/i/A3PKEDZ9cEqpi6AnLImgJw/mq1.jpg",
        folder=True )  

		
    plugintools.add_item( 
        #action="", 
        title="ריטה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://yt3.ggpht.com/-mWgBzYMaVyA/AAAAAAAAAAI/AAAAAAAAAAA/fCC_MbpehM0/s176-c-k-no/photo.jpg",
        folder=True )  	

    plugintools.add_item( 
        #action="", 
        title="רונה קינן",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://yt3.ggpht.com/-ghrjKXspM1s/AAAAAAAAAAI/AAAAAAAAAAA/2PRG4sK61Ek/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="נורית גלרון",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://i.ytimg.com/i/9Md5MQ5GTF0MYc-lOE__zw/mq1.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="שלומי שבת",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://i.ytimg.com/i/GaHPMv8YIv_0HfRDQQ44cA/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="קובי אפללו",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://yt3.ggpht.com/-W5wjK70SQ1U/AAAAAAAAAAI/AAAAAAAAAAA/Ibov9BPmodU/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="סגיב כהן",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://yt3.ggpht.com/-rG_Oeq8u13I/AAAAAAAAAAI/AAAAAAAAAAA/FEwo6HuzAJM/s176-c-k-no/photo.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="יובל דיין",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://i.ytimg.com/i/aoU3jCV2ViwIziQkO06a-Q/mq1.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="לאה שבת",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://yt3.ggpht.com/-ohRq-agRAoE/AAAAAAAAAAI/AAAAAAAAAAA/XnqTdGoERkw/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אהוד בנאי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://yt3.ggpht.com/-PEUc1dLRo-c/AAAAAAAAAAI/AAAAAAAAAAA/EHUJmoEG0ro/s176-c-k-no/photo.jpg",
        folder=True )	
    plugintools.add_item( 
        #action="", 
        title="רמי פורטיס",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://yt3.ggpht.com/-1Nc-g81Hs0o/AAAAAAAAAAI/AAAAAAAAAAA/qb5Q0TpYok8/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Balkan Beat Box",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://yt3.ggpht.com/-B7jVk2QUUvY/AAAAAAAAAAI/AAAAAAAAAAA/D5bJhE9GOSg/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אסף אבידן",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://i.ytimg.com/i/e4eKg7jM1iLKizaHXXatYw/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אחינועם ניני",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://i.ytimg.com/i/_sZP_Qv3gVUQjOtBqUkJtg/mq1.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="יהודית רביץ",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://yt3.ggpht.com/-8oDYKgR_EcY/AAAAAAAAAAI/AAAAAAAAAAA/qL-nzF-D5GA/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="מוש בן ארי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://yt3.ggpht.com/-kGMcrU7fFyU/AAAAAAAAAAI/AAAAAAAAAAA/gjdGe5E6PFQ/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ארקדי דוכין",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://yt3.ggpht.com/-MK1Yd6JAWRE/AAAAAAAAAAI/AAAAAAAAAAA/e4vLO42F_0c/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="אביב גפן",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://yt3.ggpht.com/-n9kLUZul28Q/AAAAAAAAAAI/AAAAAAAAAAA/O86BinP3aQw/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="שלום חנוך",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://yt3.ggpht.com/-6DiGw2l8Nrk/AAAAAAAAAAI/AAAAAAAAAAA/3qnrk75SjaA/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ברי סחרוף",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://yt3.ggpht.com/-vWq0Ei1WsRQ/AAAAAAAAAAI/AAAAAAAAAAA/5Y_fTrKAFoo/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="מתי כספי",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="https://i.ytimg.com/i/hV4_Q6R4edNRfMoQiOHa7A/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="נינט טייב",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="https://i.ytimg.com/i/JY2GRQceo0i_zskTXs3pmg/mq1.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="דנה אינטרנשיונל",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="https://yt3.ggpht.com/-mrXhP27w_Us/AAAAAAAAAAI/AAAAAAAAAAA/omGgmuQWDoc/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אריאל זילבר",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="https://yt3.ggpht.com/-BmKqVNPRv0U/AAAAAAAAAAI/AAAAAAAAAAA/u_qee3euwF4/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="מאיר בנאי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="https://yt3.ggpht.com/-WQglHjfoC4o/AAAAAAAAAAI/AAAAAAAAAAA/hMQUdsAQgxQ/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="טיפקס",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="https://yt3.ggpht.com/-g0tzoTXWJ6k/AAAAAAAAAAI/AAAAAAAAAAA/uP5aRLdVqn0/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אתניקס",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="https://i.ytimg.com/i/3x2sCUeEW4BidSBClBHchA/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="הדג נחש",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://yt3.ggpht.com/-p7M1mRBKD4A/AAAAAAAAAAI/AAAAAAAAAAA/uHxN4-rnvV4/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="דנה ברגר",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="https://yt3.ggpht.com/-gkbYjd0J0Zw/AAAAAAAAAAI/AAAAAAAAAAA/tw2WIW5qu-Q/s176-c-k-no/photo.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="איה כורם",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="https://yt3.ggpht.com/-IftJ9Qlz0O4/AAAAAAAAAAI/AAAAAAAAAAA/uJqk0yHGY0k/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ירדנה ארזי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="https://yt3.ggpht.com/-Qaq5WgP84jw/AAAAAAAAAAI/AAAAAAAAAAA/ANHwX9DVbX0/s176-c-k-no/photo.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="חוה אלברשטיין",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="https://i.ytimg.com/i/Q87KyUq4NtYi1NvC5rD5Vw/mq1.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="ליאור נרקיס",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="https://yt3.ggpht.com/-rty-RitLrSM/AAAAAAAAAAI/AAAAAAAAAAA/yjXa3UqBrlk/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אביתר בנאי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="https://yt3.ggpht.com/-Te7WcZKDLB4/AAAAAAAAAAI/AAAAAAAAAAA/WHNxjxRGCrg/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="קרולינה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="https://yt3.ggpht.com/-odfpSwG_OxA/AAAAAAAAAAI/AAAAAAAAAAA/FQozWRfo-Fk/s176-c-k-no/photo.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="עדן בן זקן",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="https://yt3.ggpht.com/-pGh03p0c_20/AAAAAAAAAAI/AAAAAAAAAAA/PXLB08tAKa8/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="רמי קלינשטיין",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="https://yt3.ggpht.com/-w0s7cBy2UZM/AAAAAAAAAAI/AAAAAAAAAAA/imwGV27TLck/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="דידה פלד",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="https://yt3.ggpht.com/-HZHp0wdEe5M/AAAAAAAAAAI/AAAAAAAAAAA/1V-k2jVMlfI/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מאיה בוסקילה",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="https://yt3.ggpht.com/-5PEvWjlVLN4/AAAAAAAAAAI/AAAAAAAAAAA/tNQGMUjQfxE/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עידן יניב",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="https://yt3.ggpht.com/-t6S0EuipGkA/AAAAAAAAAAI/AAAAAAAAAAA/nwz0JTWpzfA/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="יהודה פוליקר",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="https://yt3.ggpht.com/-kO_zYQwYNcs/AAAAAAAAAAI/AAAAAAAAAAA/e4rq8-PzCDc/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="בן ארצי",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="https://i.ytimg.com/i/8G3ncGuD8y7UOeEFU9O9jw/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מורין נהדר",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="https://yt3.ggpht.com/-JIWmmB6RDXg/AAAAAAAAAAI/AAAAAAAAAAA/xPLhdIn52Ec/s176-c-k-no/photo.jpg",
        folder=True )
						
		
run()
