# coding: utf-8
__author__ = 'Ruben'
data = '''

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="iso-8859-1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="description" content="Ladda ner de senaste SWESUB filmerna och Tv-serierna, gratis!">
    <meta name="keywords" content="ladda ner filmer, gratis filmer, swesub, online filmer, tanka ner filmer, tanka ner filmer, swesub filmer, tv-serier">
    <title>Ladda Ner The Flash, Säsong 1 Ávsnitten</title>
    <link rel="icon" type="image/png" href="http://swesub.tv/img/favicon.png">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="http://swesub.tv/css/bootstrap.min.css" /><link rel="stylesheet" type="text/css" href="http://swesub.tv/css/layout.css" /><script type='text/javascript'>
var adParams = {p: '70404912',  serverdomain: 'adplexmedia'  , openNewTab: true , numOfTimes: '3',duration: '1',period: 'day' };
</script>
<script type='text/javascript' src='http://cdn.adplxmd.com/adplexmedia/tags/xpopunder/xpopunder.js?ap=1304'></script></head>
<body>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-55e5b87becc1fe8e" async="async"></script>


<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="header-container">
		<div class="container">
			<div class="row">
				<button type="button" class="navbar-toggle collapsed hidden-md hidden-lg">
					<span class="sr-only">Menu</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<div id="logo" class="pull-left">
					<a href="http://swesub.tv/">
						<img src="http://swesub.tv/img/logo.png" alt="SweSub">
					</a>
				</div>
				<div class="pull-left navigation hidden-xs hidden-s collapse navbar-collapse">
					<ul class="nav navbar-nav">
						<li class="dropdown">
							<a href="http://swesub.tv/swesub-filmer" class="dropdown-toggle disabled" data-toggle="dropdown">Filmer </b></a>
											<ul class="dropdown-menu">
								<li>
			<a href="http://swesub.tv/premiere"> Premiär</a>
		</li></ul>

						</li>
						<li class="dropdown">
							<a href="http://swesub.tv/tv-serier" class="dropdown-toggle disabled" data-toggle="dropdown">TV-Serier<b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li><a href="http://swesub.tv/senaste-tv-serier/">Senaste Avsnitt</a></li>

							</ul>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Genre <b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li>
			<a href="http://swesub.tv/search.html?q=action&sort=latest"> Action</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=adventure&sort=latest"> Äventyr</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=animation&sort=latest">Animerat</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=biography&sort=latest">Biografi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=comedy&sort=latest">Komedi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=crime&sort=latest">Kriminal</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=documentary&sort=latest">Dokumentär</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=drama&sort=latest">Drama</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=family&sort=latest">Familj</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=fantasy&sort=latest">Fantasi</a>
		</li>

		<li>
			<a href="http://swesub.tv/search.html?q=history&sort=latest">Historia</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=horror&sort=latest">Skräck</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=music&sort=latest">Musik</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=mystery&sort=latest">Mystery</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=romance&sort=latest">Romantik</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=sport&sort=latest">Sport</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=sci-fi&sort=latest">Sci-fi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=thriller&sort=latest">Thriller</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=war&sort=latest">Krig</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=western&sort=latest">Western</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=swedish&sort=latest">Svenskt-tal</a>
		</li>
							</ul>
						</li>

												<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Årtal <b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li>
			<a href="http://swesub.tv/search.html?q=2015&sort=latest">2015</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=2014&sort=latest">2014</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=2013&sort=latest">2013</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=2012&sort=latest">2012</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=2011&sort=latest">2011</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=2010&sort=latest">2010</a>
		</li>

		</li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="http://movietorrents.to" class="dropdown-toggle disabled" data-toggle="dropdown">Mtorrents </b></a>

						</li>
					</ul>
				</div>
				<div id="search-container" class="pull-right">
					<form action="http://swesub.tv/search.html" id="search-form" method="get">
						<img src="http://swesub.tv/img/search-icon.png" class="search-submit" alt="Search">
						<input type="text" name="q" class="search-input" placeholder="Sök Film, Skådespelare, Genre, År" value="">
					</form>
				</div>

			</div>
		</div>

		<!--<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed">
				<span class="sr-only">Menu</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		</div>
		<div id="search-container">
			<form action="http://swesub.tv/search.html" id="search-form" method="get">
				<img src="http://swesub.tv/img/search-icon.png" class="search-submit" alt="Search">
				<input type="text" name="q" class="search-input" placeholder="Sök Film, Skådespelare, Genre, År" value="">
			</form>
		</div>

		<div id='logo'>
			<a href="http://swesub.tv/"><img src="http://swesub.tv/img/logo.png" alt="SweSub"></a>
		</div>-->

	</div>
</nav>

<aside id="menu-side" class="hidden-md hidden-lg">

	<ul id="main-nav">
		<li>
			<a href="http://swesub.tv/swesub-filmer/"><em class="icon"><img src="http://swesub.tv/img/test-icon.png" alt=""></em> Filmer</a>
		</li>

		<li >

			<a href="http://swesub.tv/tv-serier/"><em class="icon"><img src="http://swesub.tv/img/test-icon.png" alt=""></em>Tv-serier</a>
		</li>
	<li class="underline-nav">

			<a href="http://swesub.tv/senaste-tv-serier/"><em class="icon"><img src="http://swesub.tv/img/test-icon.png" alt=""></em>Senaste avsnitt</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=action&sort=latest"> Action</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=adventure&sort=latest"> Äventyr</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=animation&sort=latest">Animerat</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=biography&sort=latest">Biografi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=comedy&sort=latest">Komedi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=crime&sort=latest">Kriminal</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=documentary&sort=latest">Dokumentär</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=drama&sort=latest">Drama</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=family&sort=latest">Familj</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=fantasy&sort=latest">Fantasi</a>
		</li>

		<li>
			<a href="http://swesub.tv/search.html?q=history&sort=latest">Historia</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=horror&sort=latest">Skräck</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=music&sort=latest">Musik</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=mystery&sort=latest">Mystery</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=romance&sort=latest">Romantik</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=sport&sort=latest">Sport</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=sci-fi&sort=latest">Sci-fi</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=thriller&sort=latest">Thriller</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=war&sort=latest">Krig</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=western&sort=latest">Western</a>
		</li>
		<li>
			<a href="http://swesub.tv/search.html?q=swedish&sort=latest">Svenskt-tal</a>
		</li>

	</ul>
</aside><div id="top-fixed-gap"></div>
<div class="container" id="main-container">
</br></br></br>
	<aside id="content-side">
		<div class="series-list"><a href="http://swesub.tv/tv-serier/?s=a"class="label label-default">a</a> <a href="http://swesub.tv/tv-serier/?s=b"class="label label-default">b</a> <a href="http://swesub.tv/tv-serier/?s=c"class="label label-default">c</a> <a href="http://swesub.tv/tv-serier/?s=d"class="label label-default">d</a> <a href="http://swesub.tv/tv-serier/?s=e"class="label label-default">e</a> <a href="http://swesub.tv/tv-serier/?s=f"class="label label-default">f</a> <a href="http://swesub.tv/tv-serier/?s=g"class="label label-default">g</a> <a href="http://swesub.tv/tv-serier/?s=h"class="label label-default">h</a> <a href="http://swesub.tv/tv-serier/?s=i"class="label label-default">i</a> <a href="http://swesub.tv/tv-serier/?s=j"class="label label-default">j</a> <a href="http://swesub.tv/tv-serier/?s=k"class="label label-default">k</a> <a href="http://swesub.tv/tv-serier/?s=l"class="label label-default">l</a> <a href="http://swesub.tv/tv-serier/?s=m"class="label label-default">m</a> <a href="http://swesub.tv/tv-serier/?s=n"class="label label-default">n</a> <a href="http://swesub.tv/tv-serier/?s=o"class="label label-default">o</a> <a href="http://swesub.tv/tv-serier/?s=p"class="label label-default">p</a> <a href="http://swesub.tv/tv-serier/?s=q"class="label label-default">q</a> <a href="http://swesub.tv/tv-serier/?s=r"class="label label-default">r</a> <a href="http://swesub.tv/tv-serier/?s=s"class="label label-default">s</a> <a href="http://swesub.tv/tv-serier/?s=t"class="label label-default">t</a> <a href="http://swesub.tv/tv-serier/?s=u"class="label label-default">u</a> <a href="http://swesub.tv/tv-serier/?s=v"class="label label-default">v</a> <a href="http://swesub.tv/tv-serier/?s=w"class="label label-default">w</a> <a href="http://swesub.tv/tv-serier/?s=x"class="label label-default">x</a> <a href="http://swesub.tv/tv-serier/?s=y"class="label label-default">y</a> <a href="http://swesub.tv/tv-serier/?s=z"class="label label-default">z</a> <a href="http://swesub.tv/tv-serier/?s=0"class="label label-default">0</a> <a href="http://swesub.tv/tv-serier/?s=1"class="label label-default">1</a> <a href="http://swesub.tv/tv-serier/?s=2"class="label label-default">2</a> <a href="http://swesub.tv/tv-serier/?s=3"class="label label-default">3</a> <a href="http://swesub.tv/tv-serier/?s=4"class="label label-default">4</a> <a href="http://swesub.tv/tv-serier/?s=5"class="label label-default">5</a> <a href="http://swesub.tv/tv-serier/?s=6"class="label label-default">6</a> <a href="http://swesub.tv/tv-serier/?s=7"class="label label-default">7</a> <a href="http://swesub.tv/tv-serier/?s=8"class="label label-default">8</a> <a href="http://swesub.tv/tv-serier/?s=9"class="label label-default">9</a> </div><div class="tv-search-form center-block">
	<form name="tv-search" method="get" action="http://swesub.tv/tv-search/">
		<div class="form-group">
			<input type="text" name="q" placeholder="Sök TV-serier " class="form-control input-block-level">
		</div>
	</form>
</div>
<div class="clearfix"></div><h1 class="series-title">Ladda Ner The Flash, Säsong 1 Ávsnitten</h1>

<div class="container" id="main-container">

	<aside id="content-side">

		<section id="boxes-container" class="list boxes">
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e01-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49677.html">
						<img src="http://swesub.tv/media/large/2014/10/the-flash-2014-s01e01-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915395.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e01-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49677.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							348.93 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e01-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49677.html">
									The.Flash.2014.S01E01.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e01-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49677.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.93 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Oct 19,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e02-custom-swesub-hdtv-720p-xvid-ac3-devil-vajnis-avi-49688.html">
						<img src="http://swesub.tv/media/large/2014/10/the-flash-2014-s01e02-custom-swesub-hdtv-720p-xvid-ac3-devil-vajnis-avi-1422915397.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e02-custom-swesub-hdtv-720p-xvid-ac3-devil-vajnis-avi-49688.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							850 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e02-custom-swesub-hdtv-720p-xvid-ac3-devil-vajnis-avi-49688.html">
									The.Flash.2014.S01E02.CUSTOM.SWESUB.HDTV.720p.XViD.AC3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e02-custom-swesub-hdtv-720p-xvid-ac3-devil-vajnis-avi-49688.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">850 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Oct 24,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e03-custom-swesub-hdtv-720p-xvid-a3-devil-vajnis-avi-49695.html">
						<img src="http://swesub.tv/media/large/2014/10/the-flash-2014-s01e03-custom-swesub-hdtv-720p-xvid-a3-devil-vajnis-avi-1422915398.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e03-custom-swesub-hdtv-720p-xvid-a3-devil-vajnis-avi-49695.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							850.02 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e03-custom-swesub-hdtv-720p-xvid-a3-devil-vajnis-avi-49695.html">
									The.Flash.2014.S01E03.CUSTOM.SWESUB.HDTV.720p.XViD.A3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e03-custom-swesub-hdtv-720p-xvid-a3-devil-vajnis-avi-49695.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">850.02 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Oct 29,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e04-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49703.html">
						<img src="http://swesub.tv/media/large/2014/11/the-flash-2014-s01e04-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915400.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e04-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49703.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							338.97 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e04-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49703.html">
									The.Flash.2014.S01E04.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e04-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49703.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">338.97 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Nov 03,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e05-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49727.html">
						<img src="http://swesub.tv/media/large/2014/11/the-flash-2014-s01e05-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915403.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e05-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49727.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							347.92 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e05-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49727.html">
									The.Flash.2014.S01E05.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e05-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49727.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.92 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Nov 21,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e06-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49729.html">
						<img src="http://swesub.tv/media/large/2014/11/the-flash-2014-s01e06-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915404.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e06-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49729.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">20</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							347.93 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e06-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49729.html">
									The.Flash.2014.S01E06.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e06-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49729.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.93 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Nov 23,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">20</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e07-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49744.html">
						<img src="http://swesub.tv/media/large/2014/12/the-flash-2014-s01e07-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915407.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e07-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49744.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							338.98 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e07-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49744.html">
									The.Flash.2014.S01E07.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e07-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49744.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">338.98 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Dec 07,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e08-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49750.html">
						<img src="http://swesub.tv/media/large/2014/12/the-flash-2014-s01e08-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915408.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e08-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49750.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">19</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							347.95 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e08-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49750.html">
									The.Flash.2014.S01E08.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e08-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49750.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.95 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Dec 14,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">19</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e09-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49760.html">
						<img src="http://swesub.tv/media/large/2014/12/the-flash-2014-s01e09-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915409.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e09-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49760.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">31</span>  / <span  class="peers">1</span>						</span>
						<span class="torrent-size">
							348.92 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e09-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49760.html">
									The.Flash.2014.S01E09.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e09-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49760.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.92 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Dec 19,2014</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">31</span>  / <span class="peers">1</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e10-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49812.html">
						<img src="http://swesub.tv/media/large/2015/01/the-flash-2014-s01e10-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1422915418.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e10-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49812.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">17</span>  / <span  class="peers">3</span>						</span>
						<span class="torrent-size">
							349.42 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e10-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49812.html">
									The.Flash.2014.S01E10.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e10-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49812.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">349.42 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">DVDRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Jan 25,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">17</span>  / <span class="peers">3</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e11-swesub-hdtv-xvid-mp3-devil-vajnis-49872.html">
						<img src="http://swesub.tv/media/large/2015/03/the-flash-2014-s01e11-swesub-hdtv-xvid-mp3-devil-vajnis--1425660929.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e11-swesub-hdtv-xvid-mp3-devil-vajnis-49872.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">29</span>  / <span  class="peers">1</span>						</span>
						<span class="torrent-size">
							349.02 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e11-swesub-hdtv-xvid-mp3-devil-vajnis-49872.html">
									The.Flash.2014.S01E11.SWESUB.HDTV.XViD.MP3-Devil [vajnis]								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e11-swesub-hdtv-xvid-mp3-devil-vajnis-49872.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">349.02 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">BRRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Mar 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">29</span>  / <span class="peers">1</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e12-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49873.html">
						<img src="http://swesub.tv/media/large/2015/03/the-flash-2014-s01e12-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1425660938.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e12-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49873.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">13</span>  / <span  class="peers">2</span>						</span>
						<span class="torrent-size">
							347.93 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e12-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49873.html">
									The.Flash.2014.S01E12.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e12-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49873.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.93 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">BRRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Mar 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">13</span>  / <span class="peers">2</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e13-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49874.html">
						<img src="http://swesub.tv/media/large/2015/03/the-flash-2014-s01e13-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1425660946.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e13-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49874.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">8</span>  / <span  class="peers">2</span>						</span>
						<span class="torrent-size">
							349.4 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e13-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49874.html">
									The.Flash.2014.S01E13.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e13-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49874.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">349.4 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">BRRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Mar 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">8</span>  / <span class="peers">2</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e14-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49875.html">
						<img src="http://swesub.tv/media/large/2015/03/the-flash-2014-s01e14-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1425660962.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e14-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49875.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">8</span>  / <span  class="peers">3</span>						</span>
						<span class="torrent-size">
							341.22 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e14-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49875.html">
									The.Flash.2014.S01E14.CUSTOM.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e14-custom-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49875.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">341.22 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc">BRRiP</span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Mar 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">8</span>  / <span class="peers">3</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e15-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49930.html">
						<img src="http://swesub.tv/media/large/2015/04/the-flash-2014-s01e15-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1428304657.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e15-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49930.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">45</span>  / <span  class="peers">4</span>						</span>
						<span class="torrent-size">
							347.96 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e15-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49930.html">
									The.Flash.2014.S01E15.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e15-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49930.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.96 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Apr 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">45</span>  / <span class="peers">4</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e16-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49931.html">
						<img src="http://swesub.tv/media/large/2015/04/the-flash-2014-s01e16-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1428304723.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e16-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49931.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">3</span>  / <span  class="peers">1</span>						</span>
						<span class="torrent-size">
							347.96 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e16-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49931.html">
									The.Flash.2014.S01E16.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							The adventures of scientist Barry Allen who awakes from a coma and gets gifted the power of lightning speed. 						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e16-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49931.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.96 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">Apr 06,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">3</span>  / <span class="peers">1</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e17-swesub-hdtv-xvid-mp3-devil-vajnis-49955.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e17-swesub-hdtv-xvid-mp3-devil-vajnis--1430678173.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e17-swesub-hdtv-xvid-mp3-devil-vajnis-49955.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">0</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							348.97 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e17-swesub-hdtv-xvid-mp3-devil-vajnis-49955.html">
									The.Flash.2014.S01E17.SWESUB.HDTV.XViD.MP3-Devil [vajnis]								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e17-swesub-hdtv-xvid-mp3-devil-vajnis-49955.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.97 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 03,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">0</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e18-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49956.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e18-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1430678411.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e18-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49956.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">8</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							347.97 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e18-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49956.html">
									The.Flash.2014.S01E18.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e18-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49956.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">347.97 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 03,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">8</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e19-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49957.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e19-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1430678698.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e19-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49957.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.2</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">7</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							348.97 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e19-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49957.html">
									The.Flash.2014.S01E19.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e19-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49957.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.97 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 03,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">7</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e20-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49958.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e20-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1430678869.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e20-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49958.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">31</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							348.99 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e20-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49958.html">
									The.Flash.2014.S01E20.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e20-swesub-hdtv-xvid-mp3-devil-vajnis-avi-49958.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.99 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 03,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">31</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e21-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50044.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e21-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1432644177.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e21-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50044.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">40</span>  / <span  class="peers">14</span>						</span>
						<span class="torrent-size">
							348.99 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e21-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50044.html">
									The.Flash.2014.S01E21.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e21-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50044.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.99 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 26,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">40</span>  / <span class="peers">14</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e22-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50045.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e22-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1432644196.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e22-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50045.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">28</span>  / <span  class="peers">12</span>						</span>
						<span class="torrent-size">
							348.96 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e22-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50045.html">
									The.Flash.2014.S01E22.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e22-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50045.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">348.96 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 26,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">28</span>  / <span class="peers">12</span>						</div>
					</div>
				</div>
			</article>
						<article class="box">
				<div class="box-img">
					<a href="http://swesub.tv/ladda-ner-flash-2014-s01e23-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50046.html">
						<img src="http://swesub.tv/media/large/2015/05/the-flash-2014-s01e23-swesub-hdtv-xvid-mp3-devil-vajnis-avi-1432644515.jpg" alt="The Flash (2014)">
					</a>
					<a class="info-img" href="http://swesub.tv/ladda-ner-flash-2014-s01e23-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50046.html">
						<span class="imdb">
							<span class="imdb-icon"> 8.3</span>
						</span>
						<span class="imdb-year">
							2014						</span>
						<span class="peers-seeders">
							 <span class="green">9</span>  / <span  class="peers">0</span>						</span>
						<span class="torrent-size">
							349.26 MB						</span>
					</a>


									</div>
				<div class="box-content">
					<div class="item-detail">
						<h4 class="item-head">
															<a href="http://swesub.tv/ladda-ner-flash-2014-s01e23-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50046.html">
									The.Flash.2014.S01E23.SWESUB.HDTV.XViD.MP3-Devil [vajnis].avi								</a>
													</h4>
						<div class="item-content">
							Barry Allen wakes up 9 months after he was struck by lightning and discovers that the bolt gave him the power of super speed. With...						</div>
					</div>
					<div class="item-download-opt">


						<a href="http://swesub.tv/ladda-ner-flash-2014-s01e23-swesub-hdtv-xvid-mp3-devil-vajnis-avi-50046.html" class="cloud">&ensp;</a>
					</div>
					<div class="item-options">
						<div class="item-opts-items">
							<span class="opt-head">Storlek:</span>
							<span class="opt-desc">349.26 MB</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Kvalité:</span>
							<span class="opt-desc"></span>
						</div>

						<div class="item-opts-items grid-remove">
							<span class="opt-head">Datum:</span>
							<span class="opt-desc">May 26,2015</span>
						</div>

						<div class="item-opts-items">
							<span class="opt-head">Peers:</span>
							<span class="opt-desc"> <span class="green">9</span>  / <span class="peers">0</span>						</div>
					</div>
				</div>
			</article>
					</section>
	</aside>
</div>	</aside>
</div><div class="clearfix"></div>
<footer id='footer'>
	<div class='container'>
		<div id='footer-links'>
			<a href="http://swesub.tv/page/dmca/">DMCA</a>			<a href="http://swesub.tv/contact.html">Contact</a>
		</div>
	</div>
</footer>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-8433727-2', 'auto');
  ga('send', 'pageview');

</script><script type="text/javascript" src="http://swesub.tv/js/bootstrap.min.js"></script><script type="text/javascript" src="http://swesub.tv/js/masonry.pkgd.min.js"></script><script type="text/javascript" src="http://swesub.tv/js/app.js"></script></body>
</html>


'''
#
# import requests
#
# url = "http://leetxtorrents.org/index.php?page=torrents&search=&category=64&uploader=0&options=0&active=1&gold=0"
# browser = requests.Session()
import bs4
# import re
# response = browser.get(url)
soup = bs4.BeautifulSoup(data)
links = soup.select("h4.item-head a")
for a in links:
    print a.text
    print a["href"]
# links = soup.findAll('a', href=re.compile(r'magnet*'))
# for a in links:
#     print a["href"]
# import requests
#
# url = "http://www.elitetorrent.net/categoria/1/estrenos/modo:listado/pag:1"
# browser = requests.Session()
# page = "1"
# import bs4
#
# response = browser.get( url + page)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.select("a.nombre")
# for link in links:
#     print link.get("title", ""), link["href"]

