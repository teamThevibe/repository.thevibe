# coding: utf-8
__author__ = 'Ruben'
data = '''

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="download, bittorrent, torrent, torrents, movies, music, games, software, download, upload, porn torrents, music torrents, movies torrents, games torrents, software torrents, iPod torrents, anime torrents, torrent search, bittorrent search, upload torrents, download torrents" />
    <meta name="description" content="Anime Torrents - Page 1. ExtraTorrent.cc" />
    <meta name="robots" content="all" />
    <link rel="shortcut icon" type="image/ico" href="/images/favicon.ico" />
    <link type="application/opensearchdescription+xml" title="ExtraTorrent.cc Search" href="http://extratorrent.cc/opensearch.xml" rel="search" />
    <meta name="verify-v1" content="9BMORdF/gLH0rZ4tcXFDfY4DrhzwzN3+oQsgI03Hgys=" />
    <link rel="alternate" type="application/rss+xml" title="ExtraTorrent RSS feed: Today Torrents" href="/rss.xml?type=today" />
    <link rel="alternate" type="application/rss+xml" title="ExtraTorrent RSS feed: All Categories Torrents" href="/rss.xml?type=last&amp;cid=1" />    <title>Anime Torrents - Page 1 - ExtraTorrent.cc The World's Largest BitTorrent System</title>

    <script type="text/javascript">
        window.functions = new Array();
    </script>

    <script src="/scripts/script.js" type="text/javascript"></script>

    <style type="text/css" media="all">
        @import "/style/frontend.css?3";
    </style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
        <form action="/search/" method="get"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td width="293"><a href="/" title="ExtraTorrent.cc - The Largest Bittorent System"><img src="//static.extratorrent.cc/images/logo.gif" border="0" alt="ExtraTorrent.cc - The Largest Bittorent System" /></a></td><td width="250" class="h_search"><input type="text" class="stext" name="search" style="width:250px;" value="" /><input type="hidden" name="new" value="1" /> <a href="/advanced_search/" title="Advanced Torrents Search">Advanced Search</a></td><td class="h_search_btn"><input type="image" src="//static.extratorrent.cc/images/btn_search.png" alt="Search for Torrents" /></td><td class="h_top_r"><a href="/login/" class="menu" title="Login into ExtraTorrent.cc">Login</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="/register/" class="menu" title="Register now">Register</a></td></tr></table></form>
    </td>
</tr>
<tr>
    <td class="main_menu">
        <table width="100%" cellspacing="0" cellpadding="0"><tr><td width="6"><div class="menul"></div></td><td width="100%" class="td_menu"><table width="100%" cellspacing="0" cellpadding="0"><tr><td><a href="/category/" class="menu" title="Browse Torrents" onmouseover="javascript: document.getElementById('tbl').className='tablemenu show';" onmouseout="javascript: document.getElementById('tbl').className='tablemenu hide';">Browse&nbsp;Torrents</a><br /><div id="divmenu"><table width="185" cellspacing="1" id="tbl" class="tablemenu hide" onmouseover="javascript: document.getElementById('tbl').className='tablemenu show';" onmouseout="javascript: document.getElementById('tbl').className='tablemenu hide';"><tr><td class="submenu2"><a href="/" title="Popular Torrents">Popular Torrents</a></td></tr><tr><td class="submenu2"><a href="/today/" title="Today Torrents">Today Torrents</a></td></tr><tr><td class="submenu2"><a href="/yesterday/" title="Yesterday Torrents">Yesterday Torrents</a></td></tr><tr><td><div class="mi4"><a href="/category/4/Movies+Torrents.html" title="Browse Movies Torrents">Movies Torrents</a></div></td></tr><tr><td><div class="mi8"><a href="/category/8/TV+Torrents.html" title="Browse TV Torrents">TV Torrents</a></div></td></tr><tr><td><div class="mi5"><a href="/category/5/Music+Torrents.html" title="Browse Music Torrents">Music Torrents</a></div></td></tr><tr><td><div class="mi533"><a href="/category/533/Adult+-+Porn+Torrents.html" title="Browse Adult&nbsp;/&nbsp;Porn Torrents">Adult&nbsp;/&nbsp;Porn Torrents</a></div></td></tr><tr><td><div class="mi7"><a href="/category/7/Software+Torrents.html" title="Browse Software Torrents">Software Torrents</a></div></td></tr><tr><td><div class="mi3"><a href="/category/3/Games+Torrents.html" title="Browse Games Torrents">Games Torrents</a></div></td></tr><tr><td><div class="mi1"><a href="/category/1/Anime+Torrents.html" title="Browse Anime Torrents">Anime Torrents</a></div></td></tr><tr><td><div class="mi2"><a href="/category/2/Books+Torrents.html" title="Browse Books Torrents">Books Torrents</a></div></td></tr><tr><td><div class="mi6"><a href="/category/6/Pictures+Torrents.html" title="Browse Pictures Torrents">Pictures Torrents</a></div></td></tr><tr><td><div class="mi416"><a href="/category/416/Mobile+Torrents.html" title="Browse Mobile Torrents">Mobile Torrents</a></div></td></tr><tr><td><div class="mi9"><a href="/category/9/Other+Torrents.html" title="Browse Other Torrents">Other Torrents</a></div></td></tr></table></div></td><td class="ms">|</td><td><a href="/search_cloud/" class="menu" title="Search Cloud">Search&nbsp;Cloud</a></td><td class="ms">|</td><td class="menu_item"><a href="/stat/" class="menu" title="Site statistic" onmouseover="javascript: document.getElementById('div_stats').className='tablemenu show';" onmouseout="javascript: document.getElementById('div_stats').className='tablemenu hide';">Site&nbsp;Stats</a><br /><div id="divstats"><table cellspacing="1" id="div_stats" class="tablemenu hide" onmouseover="javascript: document.getElementById('div_stats').className='tablemenu show';" onmouseout="javascript: document.getElementById('div_stats').className='tablemenu hide';"><tr><td><a href="/stat/" title="statistic"><b>Site&nbsp;statistic</b></a></td></tr><tr><td><a href="/online/" title="Members online"><b>Members&nbsp;online</b></a></td></tr><tr><td><a href="/top_users/" title="Top members"><b>Top&nbsp;members</b></a></td></tr></table></div></td><td class="ms">|</td><td class="menu_item"><a href="/forum/" class="menu" title="Community" onmouseover="javascript: document.getElementById('div_community').className='tablemenu show';" onmouseout="javascript: document.getElementById('div_community').className='tablemenu hide';">Community</a><br /><div id="divcommunity"><table cellspacing="1" id="div_community" class="tablemenu hide" onmouseover="javascript: document.getElementById('div_community').className='tablemenu show';" onmouseout="javascript: document.getElementById('div_community').className='tablemenu hide';"><tr><td><a href="/forum/" title="forum"><b>Site&nbsp;Forum</b></a></td></tr><tr><td><a href="/articles/" title="articles"><b>Site&nbsp;Articles</b></a></td></tr><tr><td><a href="/et_chat/" title="chat"><b>ET Chat</b></a></td></tr></table></div></td><td class="ms">|</td><td><a href="/faq/" class="menu" title="ExtraTorrent.cc FAQ">FAQ</a></td><td width="100%">&nbsp;</td></tr></table></td><td width="6"><div class="menur"></div></td></tr></table>
    </td>
</tr>
<tr>
    <td style="padding-top:10px;">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td style="vertical-align:top;">
                                <div class="blog_left"></div><div class="blog_top"><div class="right"><a href="/articles/" title="Browse All Articles">view all &gt;</a></div>Latest Articles</div><div class="blog_right"></div><div class="blog_content"><ul class="ten_articles"><li><div>12</div><a href="/article/4749/british+snoopers+charter+will+be+reviewed+within+5+years.html" title="British Snoopers Charter Will Be Reviewed within 5 Years">British Snoopers Charter Will Be Reviewed within 5 Years</a></li><li><div>12</div><a href="/article/4748/older+versions+of+internet+explorer+lose+support.html" title="Older Versions of Internet Explorer Lose Support">Older Versions of Internet Explorer Lose Support</a></li><li><div>12</div><a href="/article/4747/power+blackout+in+ukraine+caused+by+hackers.html" title="Power Blackout in Ukraine Caused by Hackers">Power Blackout in Ukraine Caused by Hackers</a></li><li><div>12</div><a href="/article/4416/how+to+avoid+copyright+infringement+notices+from+isp+try+vpn.html" title="How to Avoid Tracking by Your Internet Service Provider?">How to Avoid Tracking by Your Internet Service Provider?</a></li><li><div>11</div><a href="/article/4746/david+bowie+dies+at+69.html" title="David Bowie dies at 69">David Bowie dies at 69</a></li><li><div>8</div><a href="/article/4745/anonymous+declares+war+on+thai+police.html" title="Anonymous Declares War on Thai Police">Anonymous Declares War on Thai Police</a></li><li><div>8</div><a href="/article/4743/swedish+private+torrent+site+was+run+%E2%80%9Cfor+fun%E2%80%9D.html" title="Swedish Private Torrent Site Was Run “for Fun”">Swedish Private Torrent Site Was Run “for Fun”</a></li><li><div>7</div><a href="/article/4742/netflix+is+now+available+in+india+pakistan+russia+and+other+countries.html" title="Netflix is Now Available in India, Pakistan, Russia and Other Countries">Netflix is Now Available in India, Pakistan, Russia and Other Countries</a></li><li><div>7</div><a href="/article/4739/copyright+holders+sued+star+trek+spin+off.html" title="Copyright Holders Sued Star Trek Spin-Off">Copyright Holders Sued Star Trek Spin-Off</a></li><li><div>7</div><a href="/article/4740/google+received+over+550m+dmca+notices+last+year.html" title="Google Received over 550m DMCA Notices Last Year">Google Received over 550m DMCA Notices Last Year</a></li></ul><div style="text-align: center; padding-top: 5px;">more p2p news on <a href="http://torrentfreak.com" target="_blank">torrentfreak</a></div></div>                <table cellspacing="0" cellpadding="0" width="239" border="0"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td width="6"><div class="menul"></div></td><td width="100%" class="td_menu">Recommend us with Google</td><td width="6"><div class="menur"></div></td></tr></table></td></tr><tr><td style="padding: 0px 5px 5px 2px;"><div class="borderdark" style="padding: 5px; text-align: center;"><g:plusone href="http://extratorrent.cc"></g:plusone></div></td></tr></table><br />                <div class="blog_left"></div><div class="blog_top"><div class="right"><a href="/hot_torrents/" title="View all">view all &gt;</a></div>Most searched</div><div class="blog_right"></div><div class="top_torr"><div class="top_cat"><div class="top_icon"><img src="//static.extratorrent.cc/images/hot_small.gif" alt="Hot torrents" /></div><div class="top_title"><b>First Cams</b></div><div class="top_more"><a href="/hot_torrents/1/First+Cams.html" title="View all First Cams Hot torrents">view&nbsp;all&nbsp;&gt;</a></div></div><div class="clear"></div><div class="top_pic"><a href="/torrent/4629033/Star+Wars+The+Force+Awakens+2015+HDTS+XviD-+INFERNO.html" title="View Torrent Info: Star Wars The Force Awakens 2015 HDTS XviD- INFERNO"><img src="//static.extratorrent.cc/images/torrents/4629033.jpg" width="100" height="140" alt="View Torrent Info: Star Wars The Force Awakens 2015 HDTS XviD- INFERNO" /></a></div><div class="top_pic"><a href="/torrent/4628587/Alvin+and+the+Chipmunks+The+Road+Chip+%282015%29+Cam-UnKnOwN.html" title="View Torrent Info: Alvin and the Chipmunks The Road Chip (2015) Cam-UnKnOwN"><img src="//static.extratorrent.cc/images/torrents/4628587.jpg" width="100" height="140" alt="View Torrent Info: Alvin and the Chipmunks The Road Chip (2015) Cam-UnKnOwN" /></a></div><div class="top_pic"><a href="/torrent/4582063/Point+Break+2015+CAMERA+x264-CPG.html" title="View Torrent Info: Point Break 2015 CAMERA x264-CPG"><img src="//static.extratorrent.cc/images/torrents/4582063.jpg" width="100" height="140" alt="View Torrent Info: Point Break 2015 CAMERA x264-CPG" /></a></div><div class="top_pic"><a href="/torrent/4561545/Victor+Frankenstein+%7B2015%7D+CAM+XVID+MP3-MURD3R.html" title="View Torrent Info: Victor Frankenstein {2015} CAM XVID MP3-MURD3R"><img src="//static.extratorrent.cc/images/torrents/4561545.jpg" width="100" height="140" alt="View Torrent Info: Victor Frankenstein {2015} CAM XVID MP3-MURD3R" /></a></div><div style="clear:left"></div><div class="top_cat"><div class="top_icon"><img src="//static.extratorrent.cc/images/hot_small.gif" alt="Hot torrents" /></div><div class="top_title"><b>XVID DIVX</b></div><div class="top_more"><a href="/hot_torrents/2/XVID+DIVX.html" title="View all XVID DIVX Hot torrents">view&nbsp;all&nbsp;&gt;</a></div></div><div class="clear"></div><div class="top_pic"><a href="/torrent/4641882/Life.2015.LIMITED.BRRip.XViD-ETRG.html" title="View Torrent Info: Life.2015.LIMITED.BRRip.XViD-ETRG"><img src="//static.extratorrent.cc/images/torrents/4641882.jpg" width="100" height="140" alt="View Torrent Info: Life.2015.LIMITED.BRRip.XViD-ETRG" /></a></div><div class="top_pic"><a href="/torrent/4641533/Lawless.Range.2016.HDRip.XviD.AC3-EVO.html" title="View Torrent Info: Lawless.Range.2016.HDRip.XviD.AC3-EVO"><img src="//static.extratorrent.cc/images/torrents/4641533.jpg" width="100" height="140" alt="View Torrent Info: Lawless.Range.2016.HDRip.XviD.AC3-EVO" /></a></div><div class="top_pic"><a href="/torrent/4641269/Legend.2015.HDRip.XviD.AC3-EVO.html" title="View Torrent Info: Legend.2015.HDRip.XviD.AC3-EVO"><img src="//static.extratorrent.cc/images/torrents/4641269.jpg" width="100" height="140" alt="View Torrent Info: Legend.2015.HDRip.XviD.AC3-EVO" /></a></div><div class="top_pic"><a href="/torrent/4640905/The.Last.Witch.Hunter.2015.HDRip.XViD-ETRG.html" title="View Torrent Info: The.Last.Witch.Hunter.2015.HDRip.XViD-ETRG"><img src="//static.extratorrent.cc/images/torrents/4640905.jpg" width="100" height="140" alt="View Torrent Info: The.Last.Witch.Hunter.2015.HDRip.XViD-ETRG" /></a></div><div style="clear:left"></div><div class="top_cat"><div class="top_icon"><img src="//static.extratorrent.cc/images/hot_small.gif" alt="Hot torrents" /></div><div class="top_title"><b>H264 X264</b></div><div class="top_more"><a href="/hot_torrents/4/H264+X264.html" title="View all H264 X264 Hot torrents">view&nbsp;all&nbsp;&gt;</a></div></div><div class="clear"></div><div class="top_pic"><a href="/torrent/4642500/Life.2015.720p.BRRip.x264.AAC-ETRG.html" title="View Torrent Info: Life.2015.720p.BRRip.x264.AAC-ETRG"><img src="//static.extratorrent.cc/images/torrents/4642500.jpg" width="100" height="140" alt="View Torrent Info: Life.2015.720p.BRRip.x264.AAC-ETRG" /></a></div><div class="top_pic"><a href="/torrent/4642517/The.Last.Castle.2001.720p.BRRip.x264.AAC-ETRG.html" title="View Torrent Info: The.Last.Castle.2001.720p.BRRip.x264.AAC-ETRG"><img src="//static.extratorrent.cc/images/torrents/4642517.jpg" width="100" height="140" alt="View Torrent Info: The.Last.Castle.2001.720p.BRRip.x264.AAC-ETRG" /></a></div><div class="top_pic"><a href="/torrent/4642204/Black.Mass.2015.1080p.WEBRip.AC3.x264-ETRG.html" title="View Torrent Info: Black.Mass.2015.1080p.WEBRip.AC3.x264-ETRG"><img src="//static.extratorrent.cc/images/torrents/4642204.jpg" width="100" height="140" alt="View Torrent Info: Black.Mass.2015.1080p.WEBRip.AC3.x264-ETRG" /></a></div><div class="top_pic"><a href="/torrent/4640853/Goosebumps.2015.720p.BRRip.x264.AAC-ETRG.html" title="View Torrent Info: Goosebumps.2015.720p.BRRip.x264.AAC-ETRG"><img src="//static.extratorrent.cc/images/torrents/4640853.jpg" width="100" height="140" alt="View Torrent Info: Goosebumps.2015.720p.BRRip.x264.AAC-ETRG" /></a></div><div style="clear:left"></div><div class="top_cat"><div class="top_icon"><img src="//static.extratorrent.cc/images/hot_small.gif" alt="Hot torrents" /></div><div class="top_title"><b>Television</b></div><div class="top_more"><a href="/hot_torrents/5/Television.html" title="View all Television Hot torrents">view&nbsp;all&nbsp;&gt;</a></div></div><div class="clear"></div><div class="top_pic"><a href="/torrent/4642759/Shadowhunters.S01E02.WEBRip.XviD-FUM%5Bettv%5D.html" title="View Torrent Info: Shadowhunters.S01E02.WEBRip.XviD-FUM[ettv]"><img src="//static.extratorrent.cc/images/torrents/4642759.jpg" width="100" height="140" alt="View Torrent Info: Shadowhunters.S01E02.WEBRip.XviD-FUM[ettv]" /></a></div><div class="top_pic"><a href="/torrent/4642336/The.Expanse.S01E06.HDTV.x264-FUM%5Bettv%5D.html" title="View Torrent Info: The.Expanse.S01E06.HDTV.x264-FUM[ettv]"><img src="//static.extratorrent.cc/images/torrents/4642336.jpg" width="100" height="140" alt="View Torrent Info: The.Expanse.S01E06.HDTV.x264-FUM[ettv]" /></a></div><div class="top_pic"><a href="/torrent/4642724/The+Curse+of+Oak+Island+S03E10+Silence+in+the+Dark++HDTV+x264-SPASM.html" title="View Torrent Info: The Curse of Oak Island S03E10 Silence in the Dark  HDTV x264-SPASM"><img src="//static.extratorrent.cc/images/torrents/4642724.jpg" width="100" height="140" alt="View Torrent Info: The Curse of Oak Island S03E10 Silence in the Dark  HDTV x264-SPASM" /></a></div><div class="top_pic"><a href="/torrent/4642328/Shadowhunters.S01E01.HDTV.x264-KILLERS%5Bettv%5D.html" title="View Torrent Info: Shadowhunters.S01E01.HDTV.x264-KILLERS[ettv]"><img src="//static.extratorrent.cc/images/torrents/4642328.jpg" width="100" height="140" alt="View Torrent Info: Shadowhunters.S01E01.HDTV.x264-KILLERS[ettv]" /></a></div><div style="clear:left"></div><div class="top_cat"><div class="top_icon"><img src="//static.extratorrent.cc/images/hot_small.gif" alt="Hot torrents" /></div><div class="top_title"><b>Foreign</b></div><div class="top_more"><a href="/hot_torrents/6/Foreign.html" title="View all Foreign Hot torrents">view&nbsp;all&nbsp;&gt;</a></div></div><div class="clear"></div><div class="top_pic"><a href="/torrent/4639637/Unfriended+%282014%29+720p+BDRip+Org+DD+2.0+Hindi+Audio+%7EInvincible.html" title="View Torrent Info: Unfriended (2014) 720p BDRip Org DD 2.0 Hindi Audio ~Invincible"><img src="//static.extratorrent.cc/images/torrents/4639637.jpg" width="100" height="140" alt="View Torrent Info: Unfriended (2014) 720p BDRip Org DD 2.0 Hindi Audio ~Invincible" /></a></div><div class="top_pic"><a href="/torrent/4641730/The+Gallows+%282015%29+720p+BluRay+x264+%5BDual-Audio%5D%5BEnglish+DD+5.1+Hindi+DD+5.1%5D+-+Mafiaking+-+M2Tv.html" title="View Torrent Info: The Gallows (2015) 720p BluRay x264 [Dual-Audio][English DD 5.1 Hindi DD 5.1] - Mafiaking - M2Tv"><img src="//static.extratorrent.cc/images/torrents/4641730.jpg" width="100" height="140" alt="View Torrent Info: The Gallows (2015) 720p BluRay x264 [Dual-Audio][English DD 5.1 Hindi DD 5.1] - Mafiaking - M2Tv" /></a></div><div class="top_pic"><a href="/torrent/4639899/Hero+%282015%29+-+WEBRip+-+1080p+-+x264+-+AAC+-+ESubs+-+Chaps+-+%5BDDR%5D.html" title="View Torrent Info: Hero (2015) - WEBRip - 1080p - x264 - AAC - ESubs - Chaps - [DDR]"><img src="//static.extratorrent.cc/images/torrents/4639899.jpg" width="100" height="140" alt="View Torrent Info: Hero (2015) - WEBRip - 1080p - x264 - AAC - ESubs - Chaps - [DDR]" /></a></div><div class="top_pic"><a href="/torrent/4640224/The.Wave.2015.1080p.BluRay.AC3.x264.Norwegian-ETRG.html" title="View Torrent Info: The.Wave.2015.1080p.BluRay.AC3.x264.Norwegian-ETRG"><img src="//static.extratorrent.cc/images/torrents/4640224.jpg" width="100" height="140" alt="View Torrent Info: The.Wave.2015.1080p.BluRay.AC3.x264.Norwegian-ETRG" /></a></div><div style="clear:left"></div></div>                <div style="margin-bottom: 10px;">
<iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fextratorrent&amp;width=235&amp;colorscheme=light&amp;show_faces=true&amp;stream=false&amp;header=true&amp;height=370" scrolling="no" frameborder="0" style="margin-left: 0; border:none; overflow:hidden; width:235px; height:370px;" allowTransparency="true"></iframe>
</div>                <div class="blog_left"></div><div class="blog_top"><div id="chat_timer" class="right">30s</div>Chat</div><div class="blog_right"></div><div class="blog_content" id="chat_body"><div id="chat"></div></div><div class="blog_content">To add new messages please <a href="/login/" title="Login into ExtraTorrent.cc">Login</a> or <a href="/register/" title="Register now">Register</a> for FREE</div><script type="text/javascript">var interval = sec = 30;simpleUpdate();</script>

    <div class="ads2" style="width:240px; overflow-x:hidden;">
<iframe src="http://ecpmrocks.com/ads?key=b92a9278ba6c115ed3d83cd3f04c579d" width="230" height="230" frameborder="0" scrolling="no"></iframe>
</div>
<br />
<div class="ads2"><a target="_blank" href="http://torrentz.com" title="torrentz.com">torrentz.com</a></div>
<div class="ads2"><a target="_blank" href="http://seedpeer.com">SeedPeer</a></div>



            </td>
            <td width="100%" style="vertical-align:top; padding: 3px 5px 0px 10px;">



        <div align="center"><a href="/article/4276/protect+yourself+with+vpn+while+torrenting+save+extratorrent.html" title="protect yourself with vpn while torrenting save extratorrent"><img src="https://affiliate.trust.zone/images/b/protect-your-torrenting-save-et.png" border="0" alt="save extratorrent with VPN" /></a></div>


    <br />


                <table width="100%" cellspacing="0" cellpadding="5" style="border: 1px #000 dashed;">
<tr><td><span style="padding: 0px 10px;">
<a href="/" title="ExtraTorrent.cc - The Biggest Bittorent System">ExtraTorrent.cc</a> &gt; <a href="/category/" title="Browse Torrents">Categories</a>  &gt; <a href="/category/1/Anime+Torrents.html" title="Browse Anime torrents">Anime torrents</a></span></td></tr></table>
<br />

    <table border="0" cellspacing="1" cellpadding="3">
    <tr>
        <td><img src="//static.extratorrent.cc/images/cat/1.gif" border="0" alt="Anime torrents" /></td>
        <td style="padding-bottom:20px;">
        <h1><b>Anime torrents</b> (total 101529 torrents in 45 Subcategories)
            <a href="/rss.xml?cid=1&amp;type=last" title="RSS: Anime Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Anime Torrents" /></a>
        </h1>
        </td>
    </tr>
    </table>
    <br /><br />

    <!-- SUBCATEGORIES -->
    <div style="padding-left:20px;">

    <table border="0" cellspacing="1" cellpadding="3">
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/963/Absolute+Duo+Torrents.html" title="Browse Absolute Duo torrents">Absolute Duo</a></td>
        <td class="tabledata1">28</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=963&amp;type=last" title="RSS: Absolute Duo Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Absolute Duo Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/951/Akame+ga+Kill+Torrents.html" title="Browse Akame ga Kill torrents">Akame ga Kill</a></td>
        <td class="tabledata1">29</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=951&amp;type=last" title="RSS: Akame ga Kill Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Akame ga Kill Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/959/Aldnoah+Zero+Torrents.html" title="Browse Aldnoah Zero torrents">Aldnoah Zero</a></td>
        <td class="tabledata1">34</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=959&amp;type=last" title="RSS: Aldnoah Zero Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Aldnoah Zero Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/99/Anime+-+Other+Torrents.html" title="Browse Anime - Other torrents">Anime - Other</a></td>
        <td class="tabledata1">84904</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=99&amp;type=last" title="RSS: Anime - Other Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Anime - Other Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/86/Battle+Programer+Shirase+Torrents.html" title="Browse Battle Programer Shirase torrents">Battle Programer Shirase</a></td>
        <td class="tabledata1">272</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=86&amp;type=last" title="RSS: Battle Programer Shirase Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Battle Programer Shirase Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/87/Big+O+Torrents.html" title="Browse Big O torrents">Big O</a></td>
        <td class="tabledata1">1</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=87&amp;type=last" title="RSS: Big O Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Big O Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/960/Binan+Koukou+Chikyuu+Bouei-bu+Love+Torrents.html" title="Browse Binan Koukou Chikyuu Bouei-bu Love torrents">Binan Koukou Chikyuu Bouei-bu Love</a></td>
        <td class="tabledata1">6</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=960&amp;type=last" title="RSS: Binan Koukou Chikyuu Bouei-bu Love Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Binan Koukou Chikyuu Bouei-bu Love Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/267/Bleach+Torrents.html" title="Browse Bleach torrents">Bleach</a></td>
        <td class="tabledata1">3251</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=267&amp;type=last" title="RSS: Bleach Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Bleach Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/88/Cardcaptor+Sakura+Torrents.html" title="Browse Cardcaptor Sakura torrents">Cardcaptor Sakura</a></td>
        <td class="tabledata1">33</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=88&amp;type=last" title="RSS: Cardcaptor Sakura Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Cardcaptor Sakura Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/89/Chobits+Torrents.html" title="Browse Chobits torrents">Chobits</a></td>
        <td class="tabledata1">28</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=89&amp;type=last" title="RSS: Chobits Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Chobits Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/142/Comics+Torrents.html" title="Browse Comics torrents">Comics</a></td>
        <td class="tabledata1">907</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=142&amp;type=last" title="RSS: Comics Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Comics Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/962/Death+Parade+Torrents.html" title="Browse Death Parade torrents">Death Parade</a></td>
        <td class="tabledata1">19</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=962&amp;type=last" title="RSS: Death Parade Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Death Parade Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/151/Dragon+ball+Torrents.html" title="Browse Dragon ball torrents">Dragon ball</a></td>
        <td class="tabledata1">136</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=151&amp;type=last" title="RSS: Dragon ball Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Dragon ball Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/90/Dragonball+GT+Torrents.html" title="Browse Dragonball GT torrents">Dragonball GT</a></td>
        <td class="tabledata1">48</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=90&amp;type=last" title="RSS: Dragonball GT Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Dragonball GT Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/91/Dragonball+Z+Torrents.html" title="Browse Dragonball Z torrents">Dragonball Z</a></td>
        <td class="tabledata1">304</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=91&amp;type=last" title="RSS: Dragonball Z Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Dragonball Z Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/156/DVD-R+Torrents.html" title="Browse DVD-R torrents">DVD-R</a></td>
        <td class="tabledata1">1377</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=156&amp;type=last" title="RSS: DVD-R Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: DVD-R Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/950/Fairy+Tail+Torrents.html" title="Browse Fairy Tail torrents">Fairy Tail</a></td>
        <td class="tabledata1">342</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=950&amp;type=last" title="RSS: Fairy Tail Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Fairy Tail Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/92/Flame+of+Recca+Torrents.html" title="Browse Flame of Recca torrents">Flame of Recca</a></td>
        <td class="tabledata1">1</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=92&amp;type=last" title="RSS: Flame of Recca Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Flame of Recca Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/93/Full+Metal+Alchemist+Torrents.html" title="Browse Full Metal Alchemist torrents">Full Metal Alchemist</a></td>
        <td class="tabledata1">829</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=93&amp;type=last" title="RSS: Full Metal Alchemist Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Full Metal Alchemist Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/95/Ghost+In+The+Shell+SAC+Torrents.html" title="Browse Ghost In The Shell SAC torrents">Ghost In The Shell SAC</a></td>
        <td class="tabledata1">138</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=95&amp;type=last" title="RSS: Ghost In The Shell SAC Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Ghost In The Shell SAC Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/94/Gundam+Torrents.html" title="Browse Gundam torrents">Gundam</a></td>
        <td class="tabledata1">1469</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=94&amp;type=last" title="RSS: Gundam Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Gundam Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/620/Hentai+Torrents.html" title="Browse Hentai torrents">Hentai</a></td>
        <td class="tabledata1">2840</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=620&amp;type=last" title="RSS: Hentai Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Hentai Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/145/Hunter+X+Hunter+Torrents.html" title="Browse Hunter X Hunter torrents">Hunter X Hunter</a></td>
        <td class="tabledata1">499</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=145&amp;type=last" title="RSS: Hunter X Hunter Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Hunter X Hunter Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/949/Inou+Battle+wa+Nichijou-kei+no+Naka+de+Torrents.html" title="Browse Inou Battle wa Nichijou-kei no Naka de torrents">Inou Battle wa Nichijou-kei no Naka de</a></td>
        <td class="tabledata1">0</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=949&amp;type=last" title="RSS: Inou Battle wa Nichijou-kei no Naka de Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Inou Battle wa Nichijou-kei no Naka de Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/96/InuYasha+Torrents.html" title="Browse InuYasha torrents">InuYasha</a></td>
        <td class="tabledata1">205</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=96&amp;type=last" title="RSS: InuYasha Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: InuYasha Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/524/Kiba+Torrents.html" title="Browse Kiba torrents">Kiba</a></td>
        <td class="tabledata1">0</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=524&amp;type=last" title="RSS: Kiba Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Kiba Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/97/Konkiki+No+Gash+Bell+Torrents.html" title="Browse Konkiki No Gash Bell torrents">Konkiki No Gash Bell</a></td>
        <td class="tabledata1">4</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=97&amp;type=last" title="RSS: Konkiki No Gash Bell Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Konkiki No Gash Bell Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/961/Kuroko+No+Basuke+Torrents.html" title="Browse Kuroko No Basuke torrents">Kuroko No Basuke</a></td>
        <td class="tabledata1">48</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=961&amp;type=last" title="RSS: Kuroko No Basuke Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Kuroko No Basuke Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/98/Last+Exile+Torrents.html" title="Browse Last Exile torrents">Last Exile</a></td>
        <td class="tabledata1">1</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=98&amp;type=last" title="RSS: Last Exile Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Last Exile Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/964/Log+Horizon+Torrents.html" title="Browse Log Horizon torrents">Log Horizon</a></td>
        <td class="tabledata1">30</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=964&amp;type=last" title="RSS: Log Horizon Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Log Horizon Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/952/Nanatsu+no+Taizai+Torrents.html" title="Browse Nanatsu no Taizai torrents">Nanatsu no Taizai</a></td>
        <td class="tabledata1">88</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=952&amp;type=last" title="RSS: Nanatsu no Taizai Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Nanatsu no Taizai Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/101/Naruto+Torrents.html" title="Browse Naruto torrents">Naruto</a></td>
        <td class="tabledata1">1923</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=101&amp;type=last" title="RSS: Naruto Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Naruto Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/508/One+Piece+Torrents.html" title="Browse One Piece torrents">One Piece</a></td>
        <td class="tabledata1">1243</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=508&amp;type=last" title="RSS: One Piece Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: One Piece Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/100/Onegai+Twins+Torrents.html" title="Browse Onegai Twins torrents">Onegai Twins</a></td>
        <td class="tabledata1">139</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=100&amp;type=last" title="RSS: Onegai Twins Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Onegai Twins Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/523/Ouran+High+School+Host+Club+Torrents.html" title="Browse Ouran High School Host Club torrents">Ouran High School Host Club</a></td>
        <td class="tabledata1">3</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=523&amp;type=last" title="RSS: Ouran High School Host Club Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Ouran High School Host Club Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/102/PlanetES+Torrents.html" title="Browse PlanetES torrents">PlanetES</a></td>
        <td class="tabledata1">4</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=102&amp;type=last" title="RSS: PlanetES Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: PlanetES Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/146/Prince+of+Tennis+Torrents.html" title="Browse Prince of Tennis torrents">Prince of Tennis</a></td>
        <td class="tabledata1">48</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=146&amp;type=last" title="RSS: Prince of Tennis Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Prince of Tennis Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/103/Ranma+1-2+Torrents.html" title="Browse Ranma 1/2 torrents">Ranma 1/2</a></td>
        <td class="tabledata1">139</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=103&amp;type=last" title="RSS: Ranma 1/2 Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Ranma 1/2 Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/104/Ruroni+Kenshin+Torrents.html" title="Browse Ruroni Kenshin torrents">Ruroni Kenshin</a></td>
        <td class="tabledata1">13</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=104&amp;type=last" title="RSS: Ruroni Kenshin Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Ruroni Kenshin Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/105/Samurai+Champloo+Torrents.html" title="Browse Samurai Champloo torrents">Samurai Champloo</a></td>
        <td class="tabledata1">8</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=105&amp;type=last" title="RSS: Samurai Champloo Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Samurai Champloo Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/107/Scrapped+Princess+Torrents.html" title="Browse Scrapped Princess torrents">Scrapped Princess</a></td>
        <td class="tabledata1">1</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=107&amp;type=last" title="RSS: Scrapped Princess Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Scrapped Princess Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/106/Stellvia+of+the+Universe+Torrents.html" title="Browse Stellvia of the Universe torrents">Stellvia of the Universe</a></td>
        <td class="tabledata1">0</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=106&amp;type=last" title="RSS: Stellvia of the Universe Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Stellvia of the Universe Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/525/Strawberry+Panic+Torrents.html" title="Browse Strawberry Panic torrents">Strawberry Panic</a></td>
        <td class="tabledata1">0</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=525&amp;type=last" title="RSS: Strawberry Panic Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Strawberry Panic Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/953/Sword+Art+Online+II+Torrents.html" title="Browse Sword Art Online II torrents">Sword Art Online II</a></td>
        <td class="tabledata1">44</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=953&amp;type=last" title="RSS: Sword Art Online II Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Sword Art Online II Torrents" /></a>
        </td>
    </tr>
        <tr>
        <td class="tabledata1">Anime &gt; <a href="/category/958/Tokyo+Ghoul+Torrents.html" title="Browse Tokyo Ghoul torrents">Tokyo Ghoul</a></td>
        <td class="tabledata1">93</td>
        <td class="tabledata1">
            <a href="/rss.xml?cid=958&amp;type=last" title="RSS: Tokyo Ghoul Torrents"><img src="//static.extratorrent.cc/images/rss.gif" height="14" width="32" border="0" alt="RSS: Tokyo Ghoul Torrents" /></a>
        </td>
    </tr>
        </table>

    <br />



    </div>


<br /><br />


<br />
<br /><h2>Recent Searches</h2><div class="borderdark" style="padding: 10px;"><a href="/search/?search=Breast%20Keep%20This%20Quiet" style="font-size: 13px;" title="Breast Keep This Quiet torrents download">Breast Keep This Quiet</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Spyhunter" style="font-size: 10px;" title="Spyhunter torrents download">Spyhunter</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=aakhri%20ghulam" style="font-size: 13px;" title="aakhri ghulam torrents download">aakhri ghulam</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=erasurte" style="font-size: 8px;" title="erasurte torrents download">erasurte</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=james%20bond%20skyfall" style="font-size: 11px;" title="james bond skyfall torrents download">james bond skyfall</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=milena%20devi" style="font-size: 9px;" title="milena devi torrents download">milena devi</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=The%20Goldbergs%20S03E08" style="font-size: 12px;" title="The Goldbergs S03E08 torrents download">The Goldbergs S03E08</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Tokyo%2070%20%282015%29" style="font-size: 12px;" title="Tokyo 70 (2015) torrents download">Tokyo 70 (2015)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=ninel%20showy" style="font-size: 14px;" title="ninel showy torrents download">ninel showy</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=ETTV" style="font-size: 11px;" title="ETTV torrents download">ETTV</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=da%20vinci%27s%20demons%20s03e10" style="font-size: 12px;" title="da vinci's demons s03e10 torrents download">da vinci's demons s03e10</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=S06E11" style="font-size: 12px;" title="S06E11 torrents download">S06E11</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Beethoven" style="font-size: 12px;" title="Beethoven torrents download">Beethoven</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=MISHA%20CROSS%20bbc" style="font-size: 12px;" title="MISHA CROSS bbc torrents download">MISHA CROSS bbc</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Myslenky%20zlocince%20S11E08" style="font-size: 8px;" title="Myslenky zlocince S11E08 torrents download">Myslenky zlocince S11E08</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=sanam%20re" style="font-size: 16px;" title="sanam re torrents download">sanam re</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Recuva" style="font-size: 16px;" title="Recuva torrents download">Recuva</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=S02E11" style="font-size: 15px;" title="S02E11 torrents download">S02E11</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=ts" style="font-size: 13px;" title="ts torrents download">ts</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=tiffany%20taylor" style="font-size: 13px;" title="tiffany taylor torrents download">tiffany taylor</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=younger%20s02e01" style="font-size: 13px;" title="younger s02e01 torrents download">younger s02e01</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Clandestino%20%2829%20Oct.%202015%29" style="font-size: 9px;" title="Clandestino (29 Oct. 2015) torrents download">Clandestino (29 Oct. 2015)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=god%20of%20war" style="font-size: 16px;" title="god of war torrents download">god of war</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=12%20january%202016" style="font-size: 8px;" title="12 january 2016 torrents download">12 january 2016</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=unzip%20for%20mac" style="font-size: 16px;" title="unzip for mac torrents download">unzip for mac</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=The.Last.Witch.Hunter" style="font-size: 14px;" title="The.Last.Witch.Hunter torrents download">The.Last.Witch.Hunter</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=music" style="font-size: 15px;" title="music torrents download">music</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=The%20Recipe%20%282015%29" style="font-size: 14px;" title="The Recipe (2015) torrents download">The Recipe (2015)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Supermodel%20%282016%29" style="font-size: 12px;" title="Supermodel (2016) torrents download">Supermodel (2016)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=quantico" style="font-size: 15px;" title="quantico torrents download">quantico</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=now%2092" style="font-size: 16px;" title="now 92 torrents download">now 92</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=windows%20xp%20ice" style="font-size: 8px;" title="windows xp ice torrents download">windows xp ice</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=YIFY" style="font-size: 9px;" title="YIFY torrents download">YIFY</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=life%20style" style="font-size: 12px;" title="life style torrents download">life style</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Tickle%20My%20Pink" style="font-size: 9px;" title="Tickle My Pink torrents download">Tickle My Pink</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Stonerz%20%282015%29" style="font-size: 13px;" title="Stonerz (2015) torrents download">Stonerz (2015)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=the%20blacklist%20s03e08" style="font-size: 14px;" title="the blacklist s03e08 torrents download">the blacklist s03e08</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=monica" style="font-size: 14px;" title="monica torrents download">monica</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=adult" style="font-size: 8px;" title="adult torrents download">adult</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Too%20Much%2C%20Too%20Soon%20%281958%29" style="font-size: 11px;" title="Too Much, Too Soon (1958) torrents download">Too Much, Too Soon (1958)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=tinkerbell%20and%20the%20legend%20of%20the%20neverbeast" style="font-size: 8px;" title="tinkerbell and the legend of the neverbeast torrents download">tinkerbell and the legend of the neverbeast</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=rachel%20starr" style="font-size: 12px;" title="rachel starr torrents download">rachel starr</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Open%20Your%20Eyes%20%282015%29" style="font-size: 15px;" title="Open Your Eyes (2015) torrents download">Open Your Eyes (2015)</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=singh%20is%20bing" style="font-size: 12px;" title="singh is bing torrents download">singh is bing</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Mario%20Salieri" style="font-size: 8px;" title="Mario Salieri torrents download">Mario Salieri</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=powers%20us" style="font-size: 16px;" title="powers us torrents download">powers us</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=movie" style="font-size: 12px;" title="movie torrents download">movie</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=Holly%20Halston" style="font-size: 8px;" title="Holly Halston torrents download">Holly Halston</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=S02E10" style="font-size: 14px;" title="S02E10 torrents download">S02E10</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=software" style="font-size: 9px;" title="software torrents download">software</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=hells.kitchen.us.1409" style="font-size: 13px;" title="hells.kitchen.us.1409 torrents download">hells.kitchen.us.1409</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=shawn%20mendes" style="font-size: 10px;" title="shawn mendes torrents download">shawn mendes</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=anime" style="font-size: 10px;" title="anime torrents download">anime</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=HUPKONZERT%20AUF%20DER%20AUTOBAHN%21%20DER%20BR%C3%9CCKENFICK%21" style="font-size: 12px;" title="HUPKONZERT AUF DER AUTOBAHN! DER BRÜCKENFICK! torrents download">HUPKONZERT AUF DER AUTOBAHN! DER BRÜCKENFICK!</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=DDR" style="font-size: 11px;" title="DDR torrents download">DDR</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=ETRG" style="font-size: 10px;" title="ETRG torrents download">ETRG</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=the%20haves%20and%20the%20have%20nots" style="font-size: 10px;" title="the haves and the have nots torrents download">the haves and the have nots</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=keri%20hilson" style="font-size: 9px;" title="keri hilson torrents download">keri hilson</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=porn" style="font-size: 8px;" title="porn torrents download">porn</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=spectre" style="font-size: 15px;" title="spectre torrents download">spectre</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=dvd" style="font-size: 8px;" title="dvd torrents download">dvd</a>&nbsp;&nbsp; &nbsp;&nbsp;<a href="/search/?search=sex" style="font-size: 8px;" title="sex torrents download">sex</a>&nbsp;&nbsp; &nbsp;&nbsp;</div><br />


        <div align="center">
<!-- MComposite Start -->
<div id="MarketGidComposite536"><center><a href="http://mgid.com" target="_blank">Loading...</a>
</center></div>
<script type="text/javascript">
var MGCD = new Date();
document.write('<scr'
+'ipt type="text/javascript"'
+' src="http://jsc.dt07.net/e/x/extratorrent.com.536.js?t='
+MGCD.getYear()
+MGCD.getMonth()
+MGCD.getDay()
+MGCD.getHours()
+'" charset="utf-8"></scr'+'ipt>');
</script>
<!-- MComposite End -->
</div>





    	    <script type='text/javascript' src='//pl105715.puhtml.com/0f/8b/73/0f8b73d477b554394e23077935e1fff4.js'></script>






    <br />


            </td>
        </tr>
        </table>
    </td>
</tr>
<tr>
    <td class="copyrights">
        <hr />
        <a href="/" title="ExtraTorrent.cc Home Page">Home</a> -
        <a href="/category/" title="Browse ExtraTorrent.cc Torrents">Browse&nbsp;Torrents</a> -
        <a href="/upload/" title="Upload Torrent">Upload&nbsp;Torrent</a> -
        <a href="/stat/" title="ExtraTorrent.cc stat">Stat</a> -
        <a href="/forum/" title="ExtraTorrent.cc Forum">Forum</a> -
        <a href="/faq/" title="ExtraTorrent.cc FAQ">FAQ</a> -
        <a href="/login/" title="Login into ExtraTorrent.cc">Login</a><br />
        ExtraTorrent.cc is in compliance with <a href="/copyrights/" title="Copyrights of ExtraTorrent.cc">copyrights</a><br />
                            <b><span class="error">BitCoin:</span> 12DiyqsWhENahDzdhdYsRrCw8FPQVcCkcm</b><br />
                        Can't load <a href="http://extratorrent.cc">ExtraTorrent</a>? Try our official mirrors: <a href="http://etmirror.com">etmirror.com</a> - <a href="http://etproxy.com">etproxy.com</a> - <a href="extratorrentonline.com">extratorrentonline.com</a> - <a href="extratorrentlive.com">extratorrentlive.com</a><br />
        2006-2016 ExtraTorrent.cc1
    </td>
</tr>
</table>


<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-3841675-6', 'extratorrent.cc');
ga('send', 'pageview');
</script>


<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>

</body>

</html>
'''
import bs4
soup = bs4.BeautifulSoup(data)
links = soup.select("td.tabledata1 a")
for link in links:
    if '/category/' in link["href"]:
        print link.text
        print link["href"]
        print '++++++++++++++++++'
# links = soup.select("td.title_td")
# for link in links:
#     print link.text