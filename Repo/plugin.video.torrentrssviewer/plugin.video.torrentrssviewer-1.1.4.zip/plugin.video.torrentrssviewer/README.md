Introduction
===================
This is addon which read torrrent RSS feed in Kodi and it allows to play directly with the help of Pulsar, KmediaTorrent, XBMCTorrent, Torrenter V2 and YATP.

It also integrates the feed in the local library allowing to use all the tools from local library as trailer, cinema experience, etc.

It is possible to write the list manually or create them from internet.

Requeriments
===================
It needs script.module.mctools installed 
https://github.com/mancuniancol/script.module.mctools/releases
