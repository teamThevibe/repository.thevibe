import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os

ADDON = xbmcaddon.Addon(id='context.mysubscriptions')
DATA_PATH = os.path.join(xbmc.translatePath('special://profile/addon_data/context.mysubscriptions'), '')

def addon():
    return ADDON
	
def select_mv_addon():
    option = ADDON.getSetting('select_mv_addon')
    if option == '0':
        return "video.whatthefurk"
    elif option == '1':
        return "video.genesis"
    elif option == '2':
        return "video.1channel"
    elif option == '3':
        return "video.salts"
    elif option == '4':
        return "video.yifymovies.hd"
    elif option == '5':
        return "program.super.favourites"
    elif option == '6':
        return "video.onlinemovies"
    elif option == '7':
        return "video.theroyalwe"
    elif option == '8':
        return "video.velocity"
    else:
        return "video.whatthefurk"
		
def select_tv_addon():
    option = ADDON.getSetting('select_tv_addon')
    if option == '0':
        return "video.whatthefurk"
    elif option == '1':
        return "video.genesis"
    elif option == '2':
        return "video.1channel"
    elif option == '3':
        return "video.salts"
    elif option == '4':
        return "program.super.favourites"
    elif option == '5':
        return "video.tv4me"
    elif option == '6':
        return "video.theroyalwe"
    elif option == '7':
        return "video.velocity"
    else:
        return "video.whatthefurk"

	
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

def create_file(dir_path, file_name=None):
    if file_name:
        file_path = os.path.join(dir_path, file_name)
    file_path = file_path.strip()
    if not os.path.exists(file_path):
        f = open(file_path, 'w')
        f.write('')
        f.close()
    return file_path
	
create_directory(DATA_PATH, "")
   
