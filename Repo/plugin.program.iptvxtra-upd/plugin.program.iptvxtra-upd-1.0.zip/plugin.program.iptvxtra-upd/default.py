#!/usr/bin/python
# -*- coding: utf-8 -*-

import os,sys,xbmcplugin,xbmcgui,xbmc,xbmcaddon
addonID = 'plugin.program.iptvxtra-upd'
addon = xbmcaddon.Addon(id = addonID)
addonPath = addon.getAddonInfo('path')
profilePath = addon.getAddonInfo('profile')

xbmc.executebuiltin( "Dialog.Close(all,true)" )
icon = xbmc.translatePath("special://home/addons/plugin.program.iptvxtra-upd/icon.png") 
xbmc.executebuiltin('XBMC.Notification(manuelles Update , die Suche kann bis zu 2 Minuten dauern bis alle Updates gefunden wurden ,30000,'+icon+')')
xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")