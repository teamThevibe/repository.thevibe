import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time
import net

from threading import Timer
import json



PLUGIN='plugin.video.offside'
ADDON = xbmcaddon.Addon(id=PLUGIN)
SETTINGS = xbmc.translatePath(os.path.join(ADDON.getAddonInfo('profile'),'settings.xml'))
image='http://xunitytalk.com/stvb/'

auth=ADDON.getSetting('authtoken')
ontapp1=int(ADDON.getSetting('ontapp_id_1'))
ontapp2=int(ADDON.getSetting('ontapp_id_2'))

USER='[COLOR yellow]'+ADDON.getSetting('user')+'[/COLOR]'

THESITE='offsidestreams.com'

UA='XBMC'

net=net.Net()

STVBINI = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'oss.ini')

try:
   filename = 'oss.ini' 
   import xbmcvfs
   ottv = xbmcaddon.Addon('script.tvguidedixie')
   path = ottv.getAddonInfo('profile')
   file = os.path.join(path, 'ini', filename)
   if not xbmcvfs.exists(file):
       stvb = xbmcaddon.Addon('plugin.video.offside')
       src = os.path.join(stvb.getAddonInfo('path'), 'resources', filename)
       xbmcvfs.copy(src, file)
except:
   pass
                

def OPEN_URL(url):
    req = urllib2.Request(url, headers={'User-Agent' : "Magic Browser"}) 
    con = urllib2.urlopen( req )
    link= con.read()
    return link

def EXIT():
        xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
        xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
    
    
if ADDON.getSetting('user')=='':
    ADDON.setSetting('resetpass','false')
    dialog = xbmcgui.Dialog()
    if dialog.yesno(THESITE.upper(), "If You Dont Have An Account", "Please Sign Up At",THESITE.upper(),"Exit","Carry On"):
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Username[/COLOR]")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('user',search_entered)
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Password[/COLOR]")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('pass',search_entered)
        ADDON.setSetting('login_time','2000-01-01 00:00:00')
    else:
        EXIT()

   
                   

        

def TryAgain():
     dialog = xbmcgui.Dialog()       
     dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Username[/COLOR]")
     search_entered = ''
     keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
     keyboard.doModal()
     if keyboard.isConfirmed():
         search_entered = keyboard.getText() 
     ADDON.setSetting('user',search_entered)
     
     dialog.ok(THESITE.upper(), "You Now Need To Input", "Your [COLOR yellow]Password[/COLOR]")
     search_entered = ''
     keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
     keyboard.doModal()
     if keyboard.isConfirmed():
         search_entered = keyboard.getText() 
     ADDON.setSetting('pass',search_entered)
     ADDON.setSetting('login_time','2000-01-01 00:00:00')
     try:
        Login()
        return server()
     except: 
        CATEGORIES()        
    
site='http://'+THESITE+'/site/live-tv/'


datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, THESITE+"_new_.lwp")
cookie_amember = os.path.join(cookie_path, THESITE+"_amember_.lwp")
channeljs=os.path.join(cookie_path, "channels.js")
paki=os.path.join(datapath, "paki")



#if  ADDON.getSetting('first_run')=='false':
    #os.remove(cookie_jar)
    #ADDON.setSetting('first_run','true')



      
def KICKOUT():
        try:
            checksub()
            
            try:os.remove(cookie_jar)
            except:pass
        except:
            pass   



  
packagesfolder = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
for root, dirs, files in os.walk(packagesfolder):
   for f in files:
        if 'plugin.video.offside' in f:
            try:os.unlink(os.path.join(root, f))
            except:pass

    
if ADDON.getSetting('byebye')=='false':
   print '###############    LOGIN TO OSS   #####################'
   loginurl = 'http://'+THESITE+'/site/wp-login.php'
   username = ADDON.getSetting('user')
   password = ADDON.getSetting('pass')
   
   data     = {'pwd': password,
                                         'log': username,
                                         'wp-submit': 'Log In','redirect_to':'http://'+THESITE+'/site','testcookie':'1','rememberme':'forever'}




   headers  = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
             'Accept-Encoding':'gzip, deflate',
             'Accept-Language':'en-US,en;q=0.8',
             'Cache-Control':'no-cache',
             'Connection':'keep-alive',
             'Content-Type':'application/x-www-form-urlencoded',
             'Host':'offsidestreams.com',
             'Origin':'http://'+THESITE,
             'Pragma':'no-cache',
             'Referer':'http://'+THESITE+'/site/wp-login.php',
             'Upgrade-Insecure-Requests':'1',
             'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'}


   html = net.http_POST(loginurl, data, headers).content

   #print html
   if os.path.exists(cookie_path) == False:
         os.makedirs(cookie_path)

   net.save_cookies(cookie_jar)
   net.set_cookies(cookie_jar)
   link=net.http_GET('http://offsidestreams.com/site/wp-admin/profile.php').content

   email=re.compile('id="email" value="(.+?)"').findall(link)[0]
   username = ADDON.getSetting('user')
   password = ADDON.getSetting('pass')

   def O0 ( heading , text ) :
    id = 10147
    if 70 - 70: oo0 . O0OO0O0O - oooo
    xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
    xbmc . sleep ( 100 )
    if 11 - 11: ii1I - ooO0OO000o
    ii11i = xbmcgui . Window ( id )
    if 66 - 66: iIiI * iIiiiI1IiI1I1 * o0OoOoOO00
    I11i = 50
    while ( I11i > 0 ) :
     try :
      xbmc . sleep ( 10 )
      I11i -= 1
      ii11i . getControl ( 1 ) . setLabel ( heading )
      ii11i . getControl ( 5 ) . setText ( text )
      return
     except :
      pass




   i1i1II = '''[COLOR red]IMPORTANT ANNOUNCEMENT !!![/COLOR]\n\n
   [COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk will not be supporting [COLOR red]Offsidestreams[/COLOR] anymore please visit the [COLOR red]Offsidestreams[/COLOR] website for more information...\n
   [COLOR green]Not All Is Lost....[/COLOR]\n\n
   [COLOR blue]StreamTvBox.club[/COLOR] is Offering all existing OSS users a Free 2 Day trial as a good will gesture\n\n
   Enjoy EPL , NHL , NBA , NFL, MLB\n\n
   Xunitytalk being Xunitytalk will make this a very smooth process if you would like to try [COLOR blue]StreamTvBox.club[/COLOR] for a free 2 day pass

   Just Click Yes On The Next Window and all your settings from [COLOR red]Offsidestreams[/COLOR] will be moved over to [COLOR blue]StreamTvBox.club[/COLOR]\n\n
   Your username and password will transfer over to [COLOR blue]StreamTvBox.club[/COLOR].\n'''



   O0 ( '[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk Repository' , i1i1II )

   I11i = 50
   while xbmc . getCondVisibility ( 'Window.IsActive(10147)' ) :
    try : p
    except : pass
   dialog = xbmcgui . Dialog ( )
   if dialog . yesno ( "Streamtvbox.Club" , "" , "Do you Want A free 2 Day Pass ?" , '' , 'NO' , 'YES' ) :



         loginurl = 'https://streamtvbox.club/payments/signup'
         #username = ADDON.getSetting('snusername')
         #password = ADDON.getSetting('snpassword')


         data    = {'product_id_page-0[]':'4-4',
                  'name_f':username,
                  'name_l':username,
                  'email':email,
                  'login':username,
                  'pass':password,
                  '_pass':password,
                  'coupon':'stvbfree',
                  '_qf_page-0_next':'Next',
                  '_save_':'page-0',
                  'paysys_id':'chris'}


         headers  ={'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                  'Accept-Encoding':'gzip, deflate',
                  'Accept-Language':'en-US,en;q=0.8',
                  'Cache-Control':'no-cache',
                  'Connection':'keep-alive',
                  #'Cookie':COOKIE,
                  'Content-Type':'application/x-www-form-urlencoded',
                  'Host':'streamtvbox.club',
                  'Origin':'https://streamtvbox.club',
                  'Pragma':'no-cache',
                  'Referer':'https://streamtvbox.club/payments/signup',
                  'Upgrade-Insecure-Requests':'1',
                  'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}

         html = net.http_POST(loginurl, data, headers).content
         ADDON.setSetting('byebye','true')
         STVB = xbmcaddon.Addon(id='plugin.video.streamtvbox')
         STVB.setSetting('user',ADDON.getSetting('user'))
         STVB.setSetting('pass',ADDON.getSetting('pass'))
         STVB.setSetting('resetpass','false')      
         dialog . ok ( "Streamtvbox.Club" , "" , "All Done" , "")
         time.sleep(2)
         
         if dialog . yesno ( "Streamtvbox.Club" , "" , "Do you Want Launch StreamTvBox ?" , '' , 'NO' , 'YES' ) :
            
             xbmc.executebuiltin('ActivateWindow(videos,plugin://plugin.video.streamtvbox)')
            

















def CATEGORIES():
    #CheckChannels()
    addDir('OffsideStreams is Closed','url',3,image+'fullmatch.png','','','')

 
         
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
                          
            
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage,play,date,description,page=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        #print name.replace('-[US]','').replace('-[EU]','').replace('[COLOR yellow]','').replace('[/COLOR]','').replace(' (G)','')+'='+u
        uniques=[]
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        menu=[]
        #menu.append(('[COLOR green]Reset Password[/COLOR]','XBMC.RunPlugin(%s?mode=2007&url=None)'% (sys.argv[0])))
        menu.append(('[COLOR red]Delete Cookie[/COLOR]','XBMC.RunPlugin(%s?mode=203&url=None&description=%s&name=%s&play=False&iconimage=%s)'% (sys.argv[0],description,name,iconimage)))
        menu.append(('[COLOR cyan]Log Out[/COLOR]','XBMC.RunPlugin(%s?mode=205&url=None&description=%s&name=%s&play=False&iconimage=%s)'% (sys.argv[0],description,name,iconimage)))
        liz.addContextMenuItems(items=menu, replaceItems=False)
        if mode == 2 or mode==7  or mode==2004:
            if not mode == 2000:           
                    liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
          
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def addLink(name,url,iconimage, fanart):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty("Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)


def addSUBLINK(name,url,mode,iconimage,play,date,description,page=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        #print name.replace('-[US]','').replace('-[EU]','').replace('[COLOR yellow]','').replace('[/COLOR]','').replace(' (G)','')+'='+u
        uniques=[]
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
date=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        play=urllib.unquote_plus(params["play"])
except:
        pass
try:
        date=urllib.unquote_plus(params["date"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        CATEGORIES()
               
elif mode==2:
        PLAY_STREAM(name,url,iconimage,play,description)
        
elif mode==3:
        REPLAY()
        
elif mode==4:
        GENRES(name,url)

elif mode==5:
        OnDemand(url)


elif mode==6:
        OnDemandLinks(url)

elif mode==7:
        PlayOnDemand(url)         
        
elif mode==200:
        schedule(name,url,iconimage)
        
elif mode==201:
        fullguide(name,url,iconimage,description)
        
elif mode==202:
        Login()
        Show_Dialog()
        
elif mode==203:
        os.remove(cookie_jar)
        Show_Dialog()

elif mode==204:
        downloadchannel()      
        
elif mode==205:
        LOGOUT()


elif mode==501:
        worldlinks(name,url)  
        

elif mode==1999:
        EVENTS()        
        
elif mode==2001:
        ADDON.openSettings()

elif mode==2003:
        GetMikey(url)     
        
elif mode==2004:
        PlayMikey(name,url,iconimage)

elif mode==2005:
        SportsOnDemand(url)             

elif mode==2006:
        checksub()

elif mode==2007:
     resetpass()        

elif mode==2008:
     TryAgain()
     
else:
        #just in case mode is invalid 
        CATEGORIES()

               
xbmcplugin.endOfDirectory(int(sys.argv[1]))

