# coding: utf-8

def getID(value=""):
    from re import search
    result = ""
    results = search("tt\\d{7}", value)
    if results <> None:
        result = results.group(0)
    return result


print getID("High-Rise /title/tt0462335/")
