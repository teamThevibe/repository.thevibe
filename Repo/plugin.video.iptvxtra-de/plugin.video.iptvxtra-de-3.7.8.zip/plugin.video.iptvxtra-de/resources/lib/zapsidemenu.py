#!/bin/python
import xbmcgui,xbmc,os,sys
xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.iptvxtra-de/?zapsidemenu)')