import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
#below you can add anything here just to keep your typing down to a minimum(shortcuts)


ADDON = xbmcaddon.Addon(id='plugin.video.saddoboxing')



 #      addDir('name','url','mode','iconimage','description') mode is where it tells the plugin where to go scroll to bottom to see where mode is
def CATEGORIES():
        addDir('Search Videos','url',2,'',0)
        url='http://www.saddoboxing.com/boxing-videos/Boxing/page1.html'
        html=OPEN_URL(url)
        link=html.split('</a></h3></div>')[1]
        match=re.compile('<h3><a href=".+?">(.+?)</a></h3>.+?<img src="(.+?)".+?<li><span>Length:</span> (.+?)</li>',re.DOTALL).findall(link)
        for name,iconimage,length in match:
            name='[COLOR yellow][%s][/COLOR] - %s' % (length,name)
            addLink(name,iconimage)
        
        addDir('Next Page >>','http://www.saddoboxing.com/boxing-videos/Boxing/page2.html',1,'',1)
        setView('movies', 'default') 
       #setView is setting the automatic view.....first is what section "movies"......second is what you called it in the settings xml  
       
       
                      												  
def NextPage(page):
        html=OPEN_URL(url)
        link=html.split('</a></h3></div>')[1]
        match=re.compile('<h3><a href=".+?">(.+?)</a></h3>.+?<img src="(.+?)".+?<li><span>Length:</span> (.+?)</li>',re.DOTALL).findall(link)
        for name,iconimage,length in match:
            name='[COLOR yellow][%s][/COLOR] - %s' % (length,name)
            addLink(name,iconimage)
        
        nextpage=re.compile('<p class="next_page"><a href="(.+?)">Next Page</a>',re.DOTALL).findall(link)
        
        addDir('Next Page >>','http://www.saddoboxing.com/boxing-videos/'+nextpage[0],1,'',0)
        
        
        
        
def SEARCH():
        keyboard = xbmc.Keyboard('', 'Search Saddo Boxing')
        keyboard.doModal()
        if keyboard.isConfirmed() and len(keyboard.getText())>0:
           html=OPEN_URL('http://www.saddoboxing.com/boxing-videos/list.php?q=%s&Submit=GO' % (keyboard.getText().replace(' ','+')))
        link=html.split('</a></h3></div>')[1]
        match=re.compile('<h3><a href=".+?">(.+?)</a></h3>.+?<img src="(.+?)".+?<li><span>Length:</span> (.+?)</li>',re.DOTALL).findall(link)
        for name,iconimage,length in match:
            name='[COLOR yellow][%s][/COLOR] - %s' % (length,name)
            addLink(name,iconimage)
            
        nextpage=re.compile('<p class="next_page"><a href="(.+?)">Next Page</a>',re.DOTALL).findall(link)
        
        addDir('Next Page >>','http://www.saddoboxing.com/boxing-videos/'+nextpage[0],1,'',0)
        
        
        
        
 
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

       
def addDir(name,url,mode,iconimage,page):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
        
        
def addLink(name,iconimage):
        url = iconimage.split('vi/')[1].replace('/0.jpg','')
        youtube = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % url
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=youtube,listitem=liz,isFolder=False)
        return ok 
 
        
#below tells plugin about the views                
def setView(content, viewType):
        # set content type so library shows more views and info
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
page=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        page=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        NextPage(page)
        
elif mode==2:
        print ""+url
        SEARCH()
        
       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
