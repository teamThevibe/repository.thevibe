# coding: utf-8
__author__ = 'Ruben'
data = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                            <html xmlns="http://www.w3.org/1999/xhtml"><head>
                                              <title>Index->Torrents</title>
                                              </head><body><if:seo_enabled>
                                              <tag:cano>
                                              <tag:meta>
                                              <tag:analytic>
                                              <tag:ggwebmaster>
                                              </tag:ggwebmaster></tag:analytic></tag:meta></tag:cano></if:seo_enabled>
                                              <meta content="text/html; charset=utf-8" http-equiv="content-type"/>
                                              <meta content="Search Discuss and Download verified torrents: movies, music, games, software" name="Description"/>
                                              <meta content="mp3, avi, bittorrent, torrent, torrents, movies, music, games, applications, apps, download, upload, share, magnets, magnet, leetxtorrents" name="Keywords"/>
                                              <link href="http://leetxtorrents.org/style/FS-022/main.css" rel="stylesheet" type="text/css"/>


                                                <!--[if lt IE 7.]>
                                                <script defer type="text/javascript" src="http://leetxtorrents.org/jscript/pngfix.js"></script>
                                                <![endif]-->
                                                <script src="http://leetxtorrents.org/jscript/ajax.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/ajax-poller.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/xbtit.js" type="text/javascript"></script>
                                            	<!-- these next 3 scripts are for the animated collapse -->
                                            	<script src="http://leetxtorrents.org/jscript/animatedcollapse.js" type="text/javascript"></script>
                                            	<script src="http://leetxtorrents.org/jscript/1.4.2_jquery.min.js" type="text/javascript"></script>
                                            	<script src="http://leetxtorrents.org/jscript/jquery.min.js" type="text/javascript"></script>
                                            	<!-- // -->
                                                <script src="http://leetxtorrents.org/jscript/jquery.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/interface.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/prototype.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/overlib.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/TorrentName.js" type="text/javascript"></script>
                                                <script src="http://leetxtorrents.org/jscript/marquee.js" type="text/javascript"></script>

                                                <script language="JavaScript" src="http://leetxtorrents.org/jscript/jq.js"></script>
                                                <script language="JavaScript" src="http://leetxtorrents.org/jscript/jq.color.js"></script>


                                            <!--[if lte IE 7]>
                                            <style type="text/css">
                                            #menu ul {display:inline;}
                                            </style>
                                            <![endif]-->

                                            <if:balloons_enabled>
                                              <script src="./jscript/overlib.js" type="text/javascript"></script>

                                              <div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
                                            <else:balloons_enabled>

                                            </else:balloons_enabled></if:balloons_enabled>

                                            <h1>Download verified torrents: movies, music, games, software | leetxtorrents</h1>
                                            <h2>Download verified torrents: movies, music, games, software</h2>


                                             <tag:season>
                                                <div id="main">

                                                <table align="center" border="0" cellpadding="0" cellspacing="0" height="170" width="100%">
                                                  <tbody><tr>
                                                  <td class="logo1"></td>
                                                  </tr>
                                                </tbody></table>




                                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tbody><tr>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  <td valign="top"><tag:main_adarea></tag:main_adarea></td>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  </tr>
                                                </tbody></table>

                                              <br/>
                                            	<table align="center" border="0" cellpadding="0" cellspacing="0">
                                                  <tbody><tr>
                                                  <td valign="top">
                                            	  <div id="dropdown">

                                                  </div></td>
                                                  </tr>
                                                </tbody></table>
                                            	<br/>

                                                <div id="header">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tbody><tr>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  <td valign="top"><div><div class="block">

                                            <div class="block-head">
                                            <div class="block-head-title"></div>
                                            </div>


                                            <div class="block-content">
                                            <div align="justify" class="b-content"><table align="center" border="0" cellpadding="1" cellspacing="1" width="100%">
                                              <tbody><tr>
                                            <td align="center" class="header"><a class="mainmenu" href="index.php">Index</a></td>
                                            <td align="center" class="header"><a class="mainmenu" href="index.php?page=viewnews">News</a></td>
                                            </tr><tr>
                                            <td align="center" class="header"><a class="mainmenu" href="index.php?page=torrents">Torrents</a></td>
                                              </tr>
                                               </tbody></table><script type="text/javascript">
                                            function newpm() {
                                            <!--
                                            var answer = confirm("You got unread mail ! , go to your inbox to read it before you proceed , else this popup will keep pestering you ;)")
                                            if (answer)
                                            window.location='index.php?page=usercp&uid=1&do=pm&action=list'
                                            // -->
                                            }
                                            </script>
                                            <link href="css_login.css" rel="stylesheet" type="text/css"/>

                                            <script type="text/javascript">

                                            animatedcollapse.addDiv('yupylogin','fade=1,height=auto')
                                            animatedcollapse.addDiv('yupyrecover','fade=1,height=auto')
                                            animatedcollapse.addDiv('yupysignup','fade=1,height=auto')


                                            animatedcollapse.ontoggle=function($, divobj, state){ }

                                            animatedcollapse.init()

                                            </script>
                                            <div align="center" style="margin-top:1%;">  

                                            <img alt="login" class="login" onclick="javascript:animatedcollapse.toggle('yupylogin'); javascript:animatedcollapse.hide('yupyrecover'); javascript:animatedcollapse.hide('yupysignup');javascript:animatedcollapse.hide('yupykontakt')" src="images/pic/blank.gif" style="cursor:pointer"/> 

                                            <img alt="recover" class="recover" onclick="javascript:animatedcollapse.toggle('yupyrecover'); javascript:animatedcollapse.hide('yupylogin');javascript:animatedcollapse.hide('yupysignup');javascript:animatedcollapse.hide('yupykontakt')" src="images/pic/blank.gif" style="cursor:pointer"/> 


                                            <a class="normal" href="index.php?page=signup" target="_parent"><img alt="signup" class="signup" src="images/pic/blank.gif" style="cursor:pointer"/></a> 
                                            <div id="yupylogin" style="display:none">
                                            <form action="index.php?page=login" method="post" name="login">

                                            <table border="0" cellpadding="10" class="lista">
                                            <tbody><tr><td class="tboxhead"></td></tr>
                                            <tr><td align="center" class="tboxmidd"><pre><font size="3">User Name</font>: <input maxlength="40" name="uid" size="40" type="text" value=""/></pre></td></tr>
                                            <tr><td align="center" class="tboxmidd"><pre><font size="3">Password</font>: <input maxlength="40" name="pwd" size="40" type="password"/></pre></td></tr>
                                            <tr><td align="center" class="tboxmidd" colspan="2"><input type="submit" value="Login"/></td></tr>
                                            <tr><td align="center" class="tboxmidd" colspan="2"><font size="2">You Need Cookies Enabled</font></td></tr>
                                            <tr><td class="tboxfoot"></td></tr>
                                            </tbody></table>
                                            </form>
                                            </div>
                                            <br/>
                                            <div id="yupyrecover" style="display:none">
                                            <div align="center">
                                            <form action="index.php?page=recover&amp;act=takerecover" method="post" name="recover">
                                            <table border="0" cellpadding="15" class="lista">
                                            <tbody><tr><td class="tboxhead"></td></tr>
                                            <tr><td align="center" class="tboxmidd"><pre><font size="3">Email:</font><input name="email" size="40" type="text"/></pre></td></tr>
                                            <tr>
                                            <td align="center" class="tboxmidd" colspan="2"><pre><pre><font size="3">Security code: <input name="public_key" type="hidden" value="37f241"/>
                                            <img alt="" src="access_code/37f241.png"/>
                                             </font><input id="captcha" maxlength="6" name="private_key" size="6" type="text" value=""/></pre></pre></td>
                                            </tr>

                                            <tr><td align="center" class="tboxmidd" colspan="2"><input type="submit" value="Send"/></td></tr>
                                            <tr><td class="tboxfoot"></td></tr>
                                            </tbody></table>
                                            </form>
                                            </div>
                                            <br/>
                                            </div>

                                            </div>
                                            </div>

                                            <div class="block-foot">
                                            </div>

                                            </div>
                                              </div></div></td>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  </tr>
                                                </tbody></table>
                                                </div>


                                                <div id="bodyarea" style="padding:4ex 0 0 0;">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tbody><tr>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  <td id="lcol" valign="top" width="180"><tag:main_left></tag:main_left></td>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  <td id="mcol" valign="top"><div class="block">

                                            <div class="block-head">
                                            <div class="block-head-title">Torrents</div>
                                            </div>


                                            <div class="block-content">
                                            <div align="center" class="b-content"><script type="text/javascript">
                                            function SetAllCheckBoxes(FormName, FieldName, CheckValue)
                                            {
                                            if(!document.forms[FormName])
                                            return;
                                            var objCheckBoxes = document.forms[FormName].elements[FieldName];
                                            if(!objCheckBoxes)
                                            return;
                                            var countCheckBoxes = objCheckBoxes.length;
                                            if(!countCheckBoxes)
                                            objCheckBoxes.checked = CheckValue;
                                            else
                                            // set the check value for all check boxes
                                            for(var i = 0; i < countCheckBoxes; i++)
                                            objCheckBoxes[i].checked = CheckValue;
                                            }
                                            </script>
                                            	<table align="center" width="90%">
                                              <tbody><tr>
                                                <td>
                                                  <table cellspacing="1" class="lista" width="100%">

                                                <tbody><tr><td align="center" class="block" colspan="10"><b>Our Team Recommend</b></td></tr>
                                                           <tr>
                                                      <td align="center" class="header" width="45">Cat.</td>
                                                      <td align="center" class="header">Filename</td>
                                                      <td align="center" class="header" width="20">DL</td>
                                                      <td align="center" class="header" width="85">Added</td>
                                                      <td align="center" class="header" width="70">Size</td>
                                                      <td align="center" class="header" width="100">Uploader</td>
                                                      <td align="center" class="header" width="30">S</td>
                                                      <td align="center" class="header" width="30">L</td>
                                                      <td align="center" class="header" width="100">Recommended by</td>
                                                      </tr>
                                                      <tr>
                                                      </tr>
                                                  </tbody></table><br/><tag:tora[].rp10>
                                                      </tag:tora[].rp10><tag:tora[].rp11>
                                                      <tag:tora[].rp12>
                                                      <tag:tora[].rp13>
                                                      <tag:tora[].rp14>
                                                      <tag:tora[].rp15>
                                                      <tag:tora[].rp16>
                                                      <tag:tora[].rp17>
                                                      <tag:tora[].rp18>
                                                      <tag:tora[].rp19>
                                                      <tag:tora[].rp20>
                                                           </tag:tora[].rp20></tag:tora[].rp19></tag:tora[].rp18></tag:tora[].rp17></tag:tora[].rp16></tag:tora[].rp15></tag:tora[].rp14></tag:tora[].rp13></tag:tora[].rp12></tag:tora[].rp11>
                                                </td>
                                              </tr>
                                            </tbody></table><br/>

                                            <div align="center">

                                            <form action="index.php" method="get" name="torrent_search">
                                              <input name="page" type="hidden" value="torrents"/>
                                              <table align="center" border="0" class="lista">
                                                <tbody><tr>
                                                  <td class="block">Search Torrents</td>
                                                  <td class="block">Category</td>
                                            <td class="block">Uploader</td>

                                            <td class="block">Search in</td>

                                                  <td class="block">Status</td>


                                                       <td class="block">Free</td>

                                                            <td class="block"> </td>
                                                </tr>
                                                <tr>
                                                  <td><input maxlength="50" name="search" size="25" type="text" value=""/></td>
                                                  <td>

                                            <select name="category"><option value="0">----</option>
                                            <optgroup label="Movies">
                                            <option value="31">Dubs/Dual Audio</option>
                                            <option value="32">DVD</option>
                                            <option value="33">h.264/x264</option>
                                            <option value="34">HD</option>
                                            <option value="35">Mp4</option>
                                            <option value="36">Divx/Xvid</option>
                                            <option value="37">PSP</option>
                                            <option value="38">SVCD/VCD</option>
                                            <option value="39">Album</option>
                                            <option value="65">Movies-BluRay</option>
                                            <option value="66">Movies-Asian</option>
                                            </optgroup>
                                            <optgroup label="Other">
                                            <option value="7">Other</option>
                                            <option value="8">E-Books</option>
                                            <option value="9">Tutorials</option>
                                            <option value="10">Images</option>
                                            <option value="11">Comics</option>
                                            <option value="12">Audiobook</option>
                                            <option value="13">Nulled Script</option>
                                            <option value="14">Emulation</option>
                                            <option value="15">Sounds</option>
                                            <option value="16">Divx/Xvid</option>
                                            <option value="17">PS1</option>
                                            <option value="18">Mobile Phone</option>
                                            </optgroup>
                                            <optgroup label="Games">
                                            <option value="20">PC Game</option>
                                            <option value="21">Images</option>
                                            <option value="22">Other</option>
                                            <option value="23">PS1</option>
                                            <option value="24">Xbox360</option>
                                            <option value="25">PS3</option>
                                            <option value="26">PS2</option>
                                            <option value="27">PSP</option>
                                            <option value="28">DS</option>
                                            <option value="29">Xbox</option>
                                            <option value="67">Games-Android</option>
                                            </optgroup>
                                            <optgroup label="TV">
                                            <option value="51">HD</option>
                                            <option value="52">Divx/Xvid</option>
                                            <option value="53">DVD</option>
                                            <option value="54">SVCD/VCD</option>
                                            </optgroup>
                                            <optgroup label="Music">
                                            <option value="41">MP3</option>
                                            <option value="42">Album</option>
                                            <option value="43">Lossless</option>
                                            <option value="44">Box Set</option>
                                            <option value="45">Video</option>
                                            <option value="46">Other</option>
                                            <option value="47">Single</option>
                                            <option value="48">Discography</option>
                                            <option value="49">DVD</option>
                                            </optgroup>
                                            <optgroup label="XXX">
                                            <option value="2">Video</option>
                                            <option value="3">Magazine</option>
                                            <option value="4">Hentai</option>
                                            <option value="5">Picture</option>
                                            </optgroup>
                                            <optgroup label="Documentaries">
                                            <option value="56">Documentary</option>
                                            </optgroup>
                                            <optgroup label="Apps">
                                            <option value="58">PC Software</option>
                                            <option value="59">Android</option>
                                            <option value="60">Mac</option>
                                            <option value="61">Linux</option>
                                            <option value="62">Other</option>
                                            </optgroup>
                                            <optgroup label="Anime">
                                            <option selected="selected" value="64">Anime</option></optgroup></select>
                                                  </td>
                                             <td>

                                            <select name="uploader"><option value="0">----</option>
                                            <option value="1">Anonymous</option>
                                            <option value="62">Blackjesus</option>
                                            <option value="83">Ex0duS5150</option>
                                            <option value="89">kawliga55</option>
                                            <option value="289">SaM</option>
                                            <option value="510">Thumper</option>
                                            <option value="4647">sundox</option>
                                            <option value="5287">deepstatus</option>
                                            <option value="5678">extremerules</option>
                                            <option value="7010">Azemone</option>
                                            <option value="7473">DivaXSaya53</option>
                                            <option value="10475">Strigoi</option>
                                            <option value="11862">Xpoz</option>
                                            <option value="11986">SkilletWarez</option>
                                            <option value="12156">TheGovernment</option>
                                            <option value="12278">HDD</option>
                                            <option value="12568">Aradrin</option>
                                            <option value="12575">SalMovies</option>
                                            <option value="12581">Slocate</option>
                                            <option value="12582">0xxx</option>
                                            <option value="12583">UplaoderKing</option>
                                            <option value="12587">CrystalTorrent</option>
                                            <option value="12588">CTShoN</option>
                                            <option value="12590">isoTropic</option>
                                            <option value="12593">sceneCD</option>
                                            <option value="12597">SriLinks</option>
                                            <option value="12603">TURG</option>
                                            <option value="12604">Gooner</option>
                                            <option value="12608">thLullaby</option>
                                            <option value="12795">AncientRome</option>
                                            <option value="13262">Ric</option>
                                            <option value="13686">anoXmous</option>
                                            <option value="13801">DarkUS3R</option>
                                            <option value="13863">godevskii</option>
                                            <option value="13927">BigJ0554</option>
                                            <option value="13968">TheDeath</option>
                                            <option value="14000">thePiratePimp</option>
                                            <option value="14130">piracylover</option>
                                            <option value="14188">IceBane</option>
                                            <option value="14264">madnort</option></select>
                                                  </td>

                                                  <td>
                                                    <select name="options" size="1">
                                                    <option selected="selected" value="0">Filename</option>
                                                    <option value="1">File &amp; Description</option>
                                                    <option value="2">Description</option>
                                                    </select>
                                                  </td>

                                                  <td>
                                                    <select name="active" size="1">
                                                    <option value="0">All</option>
                                                    <option selected="selected" value="1">Active only</option>
                                                    <option value="2">Dead only</option>
                                                    </select>
                                                  </td>
                                                       <td>
                                                    <select name="gold" size="1">
                                                    <option selected="selected" value="0">All</option>
                                                    <option value="1">Classic</option>
                                                    <option value="2">Silver</option>
                                                    <option value="3">Gold</option>
                                                    <option value="4">Silver &amp; Gold</option>

                                                    </select>
                                                  </td>


                                                  <td><input class="btn" type="submit" value="Search"/></td>
                                                 </tr>
                                              </tbody></table>
                                            </form>
                                            </div>

                                            <table width="100%">
                                              <tbody><tr>
                                                <td align="center" colspan="2">
                                            <form action="index.php" method="post" name="change_pagepages">
                                            <select class="drop_pager" name="pages" onchange="location=document.change_pagepages.pages.options[document.change_pagepages.pages.selectedIndex].value" size="1">
                                            <option selected="selected" value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=1">1</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2">2</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=3">3</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=4">4</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=5">5</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=6">6</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=7">7</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=8">8</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=9">9</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=10">10</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=11">11</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=12">12</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=13">13</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=14">14</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=15">15</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=16">16</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=17">17</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=18">18</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=19">19</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=20">20</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=21">21</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=22">22</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=23">23</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=24">24</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=25">25</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=26">26</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=27">27</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=28">28</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=29">29</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=30">30</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=31">31</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=32">32</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=33">33</option>
                                            </select>
                                             <span class="pagercurrent"><b>1</b></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2">2</a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=3">3</a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2"> ></a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=33"> »</a></span>
                                            </form></td>
                                              </tr><form action="index.php?page=torrents&amp;do=del" method="post" name="deltorrent"></form>
                                              <tr>
                                                <td>
                                                  <table class="lista" width="100%">
                                            	  <tbody><tr><td class="header" colspan="17"><tag:search_msg></tag:search_msg></td></tr>
                                                    <tr>
                                                      <td align="center" class="header" width="45"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=1&amp;by=1">Cat.</a></td>
                                                      <td align="center" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=2&amp;by=1">Name</a></td>


                                                      <td align="center" class="header" width="20">Dl</td>
                                                      <td align="center" class="header" width="30">Mag</td>
                                                      <td align="center" class="header" width="20">BM</td>
                                                      <td align="center" class="header" width="40"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=3&amp;by=1">Date</a> ↓</td>
                                                      <td align="center" class="header" width="30">Age</td>
                                                      <td align="center" class="header" width="30"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=5&amp;by=2">S</a></td>
                                                      <td align="center" class="header" width="30"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=6&amp;by=2">L</a></td>
                                                      <td align="center" class="header" width="30"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=7&amp;by=1">C</a></td>

                                                      <td align="center" class="header" width="30">Uploader</td>

                                                      <td align="center" class="header" width="30"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=4&amp;by=2">Size</a></td>

                                                      <td align="center" class="header" width="45"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;order=9&amp;by=1">Speed</a></td>

                                                      <td align="center" class="header" width="20">Lang</td>

                                                      <td align="center" class="header" width="45">Av.</td><td align="center" class="header" style="text-align: center;"></td>
                                                    </tr>

                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=70eecee644c520c6cda6dad9bec3d26c13f95ed7" onmouseout="return nd();" onmouseover=" return overlib('<center>[AnimeRG] BLEACH  (001 366) (10 bit)(480p 720p) [Complete] [KaMi]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 28.86 GB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 13<font color = red> Leechers: 128<font color = purple> Done: 590</font></center>', CENTER);" title="View details: [AnimeRG] BLEACH  (001-366) (10-bit)(480p-720p) [Complete] [KaMi]">[AnimeRG] BLEACH  (001 366) (10 bit)(480p 720p) [Complete] [KaMi]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=70eecee644c520c6cda6dad9bec3d26c13f95ed7&amp;f=%5BAnimeRG%5D+BLEACH++%28001-366%29+%2810-bit%29%28480p-720p%29+%5BComplete%5D+%5BKaMi%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:ODXM5ZSEYUQMNTNG3LM35Q6SNQJ7SXWX"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=70eecee644c520c6cda6dad9bec3d26c13f95ed7"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">13</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">128</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">590</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">28.86 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=5410cf356df671b75febcfd65296cd1154e5b60d" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG] Digimon Adventure Tri EP 01   04 [720p][Eng Subbed][Luc   </center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center&gt;&lt;center&gt;Category: Anime Size: 397.68 MB&lt;/center&gt;&lt;center&gt;Added:4 weeks ago&lt;/center><center><font color = green>Seeders: 15<font color = red> Leechers: 2<font color = purple> Done: 24</font></center>', CENTER);" title="View details: [ARRG] Digimon Adventure Tri EP 01 - 04 [720p][Eng Subbed][Luc...">[ARRG] Digimon Adventure Tri EP 01   04 [720p][Eng Subbed][Luc   </a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=5410cf356df671b75febcfd65296cd1154e5b60d&amp;f=%5BARRG%5D+Digimon+Adventure+Tri+EP+01+-+04+%5B720p%5D%5BEng+Subbed%5D%5BLuc....torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:KQIM6NLN6ZY3OX7LZ7LFFFWNCFKOLNQN"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=5410cf356df671b75febcfd65296cd1154e5b60d"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">15</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">2</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">24</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">397.68 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=268d2d84f72790c7c97dcd034c875e303ad66eeb" onmouseout="return nd();" onmouseover=" return overlib('<center>Fairy Tail S2   85 (260) [480p][EngSub][iORcHid]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 158.38 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 22<font color = red> Leechers: 0<font color = purple> Done: 289</font></center>', CENTER);" title="View details: Fairy Tail S2 - 85 (260) [480p][EngSub][iORcHid]">Fairy Tail S2   85 (260) [480p][EngSub][iORcHid]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=268d2d84f72790c7c97dcd034c875e303ad66eeb&amp;f=Fairy+Tail+S2+-+85+%28260%29+%5B480p%5D%5BEngSub%5D%5BiORcHid%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:E2GS3BHXE6IMPSL5ZUBUZB26GA5NM3XL"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=268d2d84f72790c7c97dcd034c875e303ad66eeb"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">22</td>
                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">289</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">158.38 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=d6751bd63562c10b8b208654c187df850f52d767" onmouseout="return nd();" onmouseover=" return overlib('<center>[USS] When Marnie Was There ? Omoide no Marnie (2014) (Dual    </center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 4.08 GB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 31<font color = red> Leechers: 4<font color = purple> Done: 20</font></center>', CENTER);" title="View details: [USS] When Marnie Was There ? Omoide no Marnie (2014) (Dual ...">[USS] When Marnie Was There ? Omoide no Marnie (2014) (Dual    </a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=d6751bd63562c10b8b208654c187df850f52d767&amp;f=%5BUSS%5D+When+Marnie+Was+There+%3F+Omoide+no+Marnie+%282014%29+%28Dual+....torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:2Z2RXVRVMLAQXCZAQZKMDB67QUHVFV3H"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=d6751bd63562c10b8b208654c187df850f52d767"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">31</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#00FF80" width="30">4</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">20</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">4.08 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=7e24e321b76c092ff72f6b64455e42cd46e3693a" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG]Fairy Tail (2014)   25 English Dubbed 720P [88MB] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 87.74 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 1<font color = red> Leechers: 0<font color = purple> Done: 11</font></center>', CENTER);" title="View details: [ARRG]Fairy Tail (2014) - 25 English Dubbed 720P [88MB] (Sehjada)">[ARRG]Fairy Tail (2014)   25 English Dubbed 720P [88MB] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=7e24e321b76c092ff72f6b64455e42cd46e3693a&amp;f=%5BARRG%5DFairy+Tail+%282014%29+-+25+English+Dubbed+720P+%5B88MB%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:PYSOGINXNQES75ZPNNSEKXSCZVDOG2J2"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=7e24e321b76c092ff72f6b64455e42cd46e3693a"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">11</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">87.74 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=0e2e39b709f1a06e390a481f32a2e31fbf7be359" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG]Fairy Tail (2014)   27 English Dubbed 720P [88MB] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 87.64 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 1<font color = red> Leechers: 1<font color = purple> Done: 11</font></center>', CENTER);" title="View details: [ARRG]Fairy Tail (2014) - 27 English Dubbed 720P [88MB] (Sehjada)">[ARRG]Fairy Tail (2014)   27 English Dubbed 720P [88MB] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=0e2e39b709f1a06e390a481f32a2e31fbf7be359&amp;f=%5BARRG%5DFairy+Tail+%282014%29+-+27+English+Dubbed+720P+%5B88MB%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:BYXDTNYJ6GQG4OIKJAPTFIXDD67XXY2Z"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=0e2e39b709f1a06e390a481f32a2e31fbf7be359"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">11</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">87.64 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=6a30ab20d5d8c861e633e0dd5db1a9018750861d" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG]Fairy Tail (2014)   31 English Dubbed 720P [88MB] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 87.63 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 1<font color = red> Leechers: 1<font color = purple> Done: 10</font></center>', CENTER);" title="View details: [ARRG]Fairy Tail (2014) - 31 English Dubbed 720P [88MB] (Sehjada)">[ARRG]Fairy Tail (2014)   31 English Dubbed 720P [88MB] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=6a30ab20d5d8c861e633e0dd5db1a9018750861d&amp;f=%5BARRG%5DFairy+Tail+%282014%29+-+31+English+Dubbed+720P+%5B88MB%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:NIYKWIGV3DEGDZRT4DOV3MNJAGDVBBQ5"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=6a30ab20d5d8c861e633e0dd5db1a9018750861d"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">10</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">87.63 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=bae518e6ea0788624830f26ede35c87b67e19274" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG]Fairy Tail (2014)   36 English Dubbed 720P [88MB] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 87.75 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 0<font color = red> Leechers: 1<font color = purple> Done: 11</font></center>', CENTER);" title="View details: [ARRG]Fairy Tail (2014) - 36 English Dubbed 720P [88MB] (Sehjada)">[ARRG]Fairy Tail (2014)   36 English Dubbed 720P [88MB] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=bae518e6ea0788624830f26ede35c87b67e19274&amp;f=%5BARRG%5DFairy+Tail+%282014%29+-+36+English+Dubbed+720P+%5B88MB%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:XLSRRZXKA6EGESBQ6JXN4NOIPNT6DETU"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=bae518e6ea0788624830f26ede35c87b67e19274"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">11</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">87.75 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=e532187c525a351c9df745be16ebd8d0a59ce6c8" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG]Fairy Tail (2014)   37 English Dubbed 720P [88MB] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 87.47 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 1<font color = red> Leechers: 0<font color = purple> Done: 11</font></center>', CENTER);" title="View details: [ARRG]Fairy Tail (2014) - 37 English Dubbed 720P [88MB] (Sehjada)">[ARRG]Fairy Tail (2014)   37 English Dubbed 720P [88MB] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=e532187c525a351c9df745be16ebd8d0a59ce6c8&amp;f=%5BARRG%5DFairy+Tail+%282014%29+-+37+English+Dubbed+720P+%5B88MB%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:4UZBQ7CSLI2RZHPXIW7BN26Y2CSZZZWI"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=e532187c525a351c9df745be16ebd8d0a59ce6c8"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">11</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">87.47 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=a2f6b0aaf935eb33a97cd713f932396b43f18f97" onmouseout="return nd();" onmouseover=" return overlib('<center>[ARRG] Fairy Tail (2014)   85 English Subbed [720P] (Sehjada)</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 133.68 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 1<font color = red> Leechers: 1<font color = purple> Done: 10</font></center>', CENTER);" title="View details: [ARRG] Fairy Tail (2014) - 85 English Subbed [720P] (Sehjada)">[ARRG] Fairy Tail (2014)   85 English Subbed [720P] (Sehjada)</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=a2f6b0aaf935eb33a97cd713f932396b43f18f97&amp;f=%5BARRG%5D+Fairy+Tail+%282014%29+-+85+English+Subbed+%5B720P%5D+%28Sehjada%29.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:UL3LBKXZGXVTHKL424J7SMRZNNB7DD4X"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=a2f6b0aaf935eb33a97cd713f932396b43f18f97"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">10</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">133.68 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=9276b217a461f7679e5a575c909e759bd73ed135" onmouseout="return nd();" onmouseover=" return overlib('<center>[HayaiSubs] Dragon Ball Super   019 (1080p x264 AAC) [rich jc]   </center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 611.85 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 110<font color = red> Leechers: 12<font color = purple> Done: 823</font></center>', CENTER);" title="View details: [HayaiSubs] Dragon Ball Super - 019 (1080p x264 AAC) [rich_jc]...">[HayaiSubs] Dragon Ball Super   019 (1080p x264 AAC) [rich jc]   </a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=9276b217a461f7679e5a575c909e759bd73ed135&amp;f=%5BHayaiSubs%5D+Dragon+Ball+Super+-+019+%281080p+x264+AAC%29+%5Brich_jc%5D....torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:SJ3LEF5EMH3WPHS2K5OJBHTVTPLT5UJV"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=9276b217a461f7679e5a575c909e759bd73ed135"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">110</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">12</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">823</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">611.85 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=d75da9adfa88544253fa559e23b2dba1d2e182a6" onmouseout="return nd();" onmouseover=" return overlib('<center>[HayaiSubs] Noragami Aragoto   07 (720p x264 AAC) [rich jc] mkv</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 181.88 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 16<font color = red> Leechers: 0<font color = purple> Done: 107</font></center>', CENTER);" title="View details: [HayaiSubs] Noragami Aragoto - 07 (720p x264 AAC) [rich_jc].mkv">[HayaiSubs] Noragami Aragoto   07 (720p x264 AAC) [rich jc] mkv</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=d75da9adfa88544253fa559e23b2dba1d2e182a6&amp;f=%5BHayaiSubs%5D+Noragami+Aragoto+-+07+%28720p+x264+AAC%29+%5Brich_jc%5D.mkv.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:25O2TLP2RBKEEU72KWPCHMW3UHJODAVG"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=d75da9adfa88544253fa559e23b2dba1d2e182a6"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">16</td>
                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">107</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">181.88 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=1ad0a91eb1f0aa7f7620884be0d2fc42c2c56ba1" onmouseout="return nd();" onmouseover=" return overlib('<center>[HayaiSubs] Dragon Ball Super   019 (720p x264 AAC) [rich jc] mkv</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 233.81 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 209<font color = red> Leechers: 24<font color = purple> Done: 1983</font></center>', CENTER);" title="View details: [HayaiSubs] Dragon Ball Super - 019 (720p x264 AAC) [rich_jc].mkv">[HayaiSubs] Dragon Ball Super   019 (720p x264 AAC) [rich jc] mkv</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=1ad0a91eb1f0aa7f7620884be0d2fc42c2c56ba1&amp;f=%5BHayaiSubs%5D+Dragon+Ball+Super+-+019+%28720p+x264+AAC%29+%5Brich_jc%5D.mkv.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:DLIKSHVR6CVH65RARBF6BUX4ILBMK25B"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=1ad0a91eb1f0aa7f7620884be0d2fc42c2c56ba1"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">209</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">24</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">1983</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">233.81 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=37720ef99586cb3b3deac617341ea0d4e6c0dbf7" onmouseout="return nd();" onmouseover=" return overlib('<center>[BTR] Shinmai Maou no Testament BURST   06 (720p x264 AAC) [ri   </center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 394.24 MB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 37<font color = red> Leechers: 3<font color = purple> Done: 206</font></center>', CENTER);" title="View details: [BTR] Shinmai Maou no Testament BURST - 06 (720p x264 AAC) [ri...">[BTR] Shinmai Maou no Testament BURST   06 (720p x264 AAC) [ri   </a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=37720ef99586cb3b3deac617341ea0d4e6c0dbf7&amp;f=%5BBTR%5D+Shinmai+Maou+no+Testament+BURST+-+06+%28720p+x264+AAC%29+%5Bri....torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:G5ZA56MVQ3FTWPPKYYLTIHVA2TTMBW7X"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=37720ef99586cb3b3deac617341ea0d4e6c0dbf7"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">37</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#00FF80" width="30">3</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">206</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">394.24 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=d808254f953bcd53be0a693115946c8ef87f3524" onmouseout="return nd();" onmouseover=" return overlib('<center>[Avalon] Infinite Stratos (BD 1080p x264 AAC) [rich jc]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 9.96 GB</center><center>Added:4 weeks ago</center><center><font color = green>Seeders: 11<font color = red> Leechers: 27<font color = purple> Done: 56</font></center>', CENTER);" title="View details: [Avalon] Infinite Stratos (BD 1080p x264 AAC) [rich_jc]">[Avalon] Infinite Stratos (BD 1080p x264 AAC) [rich jc]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=d808254f953bcd53be0a693115946c8ef87f3524&amp;f=%5BAvalon%5D+Infinite+Stratos+%28BD+1080p+x264+AAC%29+%5Brich_jc%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:3AECKT4VHPGVHPQKNEYRLFDMR34H6NJE"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=d808254f953bcd53be0a693115946c8ef87f3524"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">21/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">35 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">11</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">27</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">56</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">9.96 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=9318eb8cab5825fa9a56f02181f6ff8da61a1ed6" onmouseout="return nd();" onmouseover=" return overlib('<center>Dragon Ball Z Remastered [DUAL AUDIO] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 28.79 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 14<font color = red> Leechers: 121<font color = purple> Done: 170</font></center>', CENTER);" title="View details: Dragon Ball Z Remastered [DUAL-AUDIO] [HEVC]">Dragon Ball Z Remastered [DUAL AUDIO] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=9318eb8cab5825fa9a56f02181f6ff8da61a1ed6&amp;f=Dragon+Ball+Z+Remastered+%5BDUAL-AUDIO%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:SMMOXDFLLAS7VGSW6AQYD5X7RWTBUHWW"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=9318eb8cab5825fa9a56f02181f6ff8da61a1ed6"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">14</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">121</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">170</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">28.79 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=53bc73231141f825909481ca318c995d83381925" onmouseout="return nd();" onmouseover=" return overlib('<center>Dragon Ball GT [DUAL AUDIO] [480p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 6.66 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 80<font color = red> Leechers: 110<font color = purple> Done: 1158</font></center>', CENTER);" title="View details: Dragon Ball GT [DUAL-AUDIO] [480p] [HEVC]">Dragon Ball GT [DUAL AUDIO] [480p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=53bc73231141f825909481ca318c995d83381925&amp;f=Dragon+Ball+GT+%5BDUAL-AUDIO%5D+%5B480p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:KO6HGIYRIH4CLEEUQHFDDDEZLWBTQGJF"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=53bc73231141f825909481ca318c995d83381925"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">80</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">110</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">1158</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">6.66 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=8cfd73eaef36c520cb3231b0be1a91cfcee186cf" onmouseout="return nd();" onmouseover=" return overlib('<center>[PUNCH] Prison School (Drama)   04 (720p x264 AAC) [rich jc] mkv</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 417.61 MB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 20<font color = red> Leechers: 1<font color = purple> Done: 159</font></center>', CENTER);" title="View details: [PUNCH] Prison School (Drama) - 04 (720p x264 AAC) [rich_jc].mkv">[PUNCH] Prison School (Drama)   04 (720p x264 AAC) [rich jc] mkv</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=8cfd73eaef36c520cb3231b0be1a91cfcee186cf&amp;f=%5BPUNCH%5D+Prison+School+%28Drama%29+-+04+%28720p+x264+AAC%29+%5Brich_jc%5D.mkv.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:RT6XH2XPG3CSBSZSGGYL4GURZ7HODBWP"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=8cfd73eaef36c520cb3231b0be1a91cfcee186cf"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">20</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#A9F5D0" width="30">1</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">159</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">417.61 MB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=8f691f286762ed0798ff05ac9ac2298912845e19" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 01 (001 062) [DUAL AUDIO] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 7.94 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 22<font color = red> Leechers: 18<font color = purple> Done: 150</font></center>', CENTER);" title="View details: One Piece Season 01 (001-062) [DUAL-AUDIO] [720p] [HEVC]">One Piece Season 01 (001 062) [DUAL AUDIO] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=8f691f286762ed0798ff05ac9ac2298912845e19&amp;f=One+Piece+Season+01+%28001-062%29+%5BDUAL-AUDIO%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:R5UR6KDHMLWQPGH7AWWJVQRJREJIIXQZ"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=8f691f286762ed0798ff05ac9ac2298912845e19"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">22</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">18</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">150</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">7.94 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=797406df9cad86d3f7ad67db6ad49d924d2f33de" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 04 (093 130) [DUAL AUDIO] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 4.65 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 0<font color = red> Leechers: 21<font color = purple> Done: 60</font></center>', CENTER);" title="View details: One Piece Season 04 (093-130) [DUAL-AUDIO] [720p] [HEVC]">One Piece Season 04 (093 130) [DUAL AUDIO] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=797406df9cad86d3f7ad67db6ad49d924d2f33de&amp;f=One+Piece+Season+04+%28093-130%29+%5BDUAL-AUDIO%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:PF2ANX44VWDNH55NM7NWVVE5SJGS6M66"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=797406df9cad86d3f7ad67db6ad49d924d2f33de"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">21</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">60</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">4.65 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=fb145ec66cabdd049c247d2f18a8cd51d65e0aa6" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 05 (131 143) [DUAL AUDIO] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 1.56 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 5<font color = red> Leechers: 8<font color = purple> Done: 55</font></center>', CENTER);" title="View details: One Piece Season 05 (131-143) [DUAL-AUDIO] [720p] [HEVC]">One Piece Season 05 (131 143) [DUAL AUDIO] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=fb145ec66cabdd049c247d2f18a8cd51d65e0aa6&amp;f=One+Piece+Season+05+%28131-143%29+%5BDUAL-AUDIO%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:7MKF5RTMVPOQJHBEPUXRRKGNKHLF4CVG"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=fb145ec66cabdd049c247d2f18a8cd51d65e0aa6"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">5</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">8</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">55</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">1.56 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=da02f9efe4290aee3d2245de519a079a92c21492" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 08 (229 263) [DUAL AUDIO] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 4.81 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 0<font color = red> Leechers: 4<font color = purple> Done: 107</font></center>', CENTER);" title="View details: One Piece Season 08 (229-263) [DUAL-AUDIO] [720p] [HEVC]">One Piece Season 08 (229 263) [DUAL AUDIO] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=da02f9efe4290aee3d2245de519a079a92c21492&amp;f=One+Piece+Season+08+%28229-263%29+%5BDUAL-AUDIO%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:3IBPT37EFEFO4PJCIXPFDGQHTKJMEFES"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=da02f9efe4290aee3d2245de519a079a92c21492"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FF0000" style="text-align: center;background:#FF0000" width="30">0</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#00FF80" width="30">4</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">107</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">4.81 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=87fa08303b6d6e6d62552c0753ef98d0c96fbfc5" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 11 (382 407) [DUAL AUDIO] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 3.88 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 4<font color = red> Leechers: 12<font color = purple> Done: 182</font></center>', CENTER);" title="View details: One Piece Season 11 (382-407) [DUAL-AUDIO] [720p] [HEVC]">One Piece Season 11 (382 407) [DUAL AUDIO] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=87fa08303b6d6e6d62552c0753ef98d0c96fbfc5&amp;f=One+Piece+Season+11+%28382-407%29+%5BDUAL-AUDIO%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:Q75AQMB3NVXG2YSVFQDVH34Y2DEW7P6F"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=87fa08303b6d6e6d62552c0753ef98d0c96fbfc5"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#00FF80" width="30">4</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">12</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">182</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">3.88 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=8da0076954cd760d4e394be1e4ab7f7fddeb6b70" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 14 (459 516) [ENG SUB] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 5.20 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 9<font color = red> Leechers: 8<font color = purple> Done: 191</font></center>', CENTER);" title="View details: One Piece Season 14 (459-516) [ENG SUB] [720p] [HEVC]">One Piece Season 14 (459 516) [ENG SUB] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=8da0076954cd760d4e394be1e4ab7f7fddeb6b70&amp;f=One+Piece+Season+14+%28459-516%29+%5BENG+SUB%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:RWQAO2KUZV3A2TRZJPQ6JK37P7O6W23Q"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=8da0076954cd760d4e394be1e4ab7f7fddeb6b70"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">9</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">8</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">191</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">5.20 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                    <tr>
                                            	</tr><tr>
                                            		</tr>
                                            	<tr>
                                            		</tr>
                                                      <tr><td align="center" class="lista" style="text-align: center;" width="45"><a href="index.php?page=torrents&amp;category=64">Anime</a></td>
                                                      <td class="lista" onmouseout="this.className='lista'" onmouseover="this.className='post'" style="padding-left:10px;overflow:auto;" valign="middle"><a href="index.php?page=torrent-details&amp;id=3ecaec86d0aed4f910e0f777aaf07d992c8720fb" onmouseout="return nd();" onmouseover=" return overlib('<center>One Piece Season 15 (517 578) [ENG SUB] [720p] [HEVC]</center><center><img src=torrentimg/nocover.jpg  width=200 border=0></center><center>Category: Anime Size: 5.55 GB</center><center>Added:5 weeks ago</center><center><font color = green>Seeders: 6<font color = red> Leechers: 13<font color = purple> Done: 238</font></center>', CENTER);" title="View details: One Piece Season 15 (517-578) [ENG SUB] [720p] [HEVC]">One Piece Season 15 (517 578) [ENG SUB] [720p] [HEVC]</a>  <br/>      <img alt="Allready Grabbed !!" src="images/downloaded.gif" title="Allready Grabbed !!"/>     <img src="images/new.png"/>  </td>

                                                      <script>
                                            var g_nExpando=0;
                                            function putItemInState(n,bState)
                                            {
                                               var oItem,oGif;
                                                  oItem=document.getElementById("descr"+n);
                                               oGif=document.getElementById("expandoGif"+n);

                                               if (bState=='toggle')
                                                 bState=(oItem.style.display=='block');

                                               if(bState)
                                               {
                                                   bState=(oItem.style.display='none');
                                                   bState=(oGif.src='images/plus.gif');
                                               }
                                               else
                                               {
                                                   bState=(oItem.style.display='block');
                                                   bState=(oGif.src='images/minus.gif');
                                               }
                                            }

                                            function expand(nItem)
                                            {
                                                putItemInState(nItem,'toggle');
                                            }

                                            function expandAll()
                                            {
                                                if (!g_nExpando)
                                                {
                                                    document.all.chkFlag.checked=false;
                                                    return;
                                                }
                                                var bState=!document.all.chkFlag.checked;
                                                for(var i=0; i<g_nExpando; i++)
                                                    putItemInState(i,bState);
                                            }
                                            </script>



                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="download.php?id=3ecaec86d0aed4f910e0f777aaf07d992c8720fb&amp;f=One+Piece+Season+15+%28517-578%29+%5BENG+SUB%5D+%5B720p%5D+%5BHEVC%5D.torrent" target="_blank"><img alt="torrent" border="0" src="images/torrent.png"/></a>
                                            </td>
                                                       <td align="center" class="lista" style="text-align: center; background:" width="20"><a href="magnet:?xt=urn:btih:H3FOZBWQV3KPSEHA6532V4D5TEWIOIH3"><img alt="Magnet Link" border="0" src="images/magnet.png"/></a></td>
                                                      <td align="center" class="lista" style="text-align: center;" width="20"><a href="index.php?page=bookmark&amp;do=add&amp;torrent_id=3ecaec86d0aed4f910e0f777aaf07d992c8720fb"><img src="images/bookmark.png"/></a>
                                            </td>
                                                      <td align="center" class="lista" style="white-space:wrap; text-align:center;" width="40">20/11/2015</td>
                                            <td align="center" class="lista" style="text-align:center;" width="30">36 days</td>

                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">6</td>
                                                      <td align="center" class="#FFFF00" style="text-align: center;background:#04B404" width="30">13</td>
                                                      <td align="center" class="lista" style="text-align: center;" width="30">238</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="30">Anonymous</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">5.55 GB</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A</td>

                                                      <td align="center" class="lista" style="text-align: center;" width="20"><img alt="English" src="images/flag/gb.png" title="English"/></td>

                                                      <td align="center" class="lista" style="text-align: center;" width="45">N/A<br/></td><td align="center" class="lista" style="text-align: center;"></td>
                                                    </tr>
                                                    <tr>
                                            		</tr>
                                                  </tbody></table><if:uplo>
                                                      </if:uplo><tag:torrent_header_rec><tag:torrent_header_top></tag:torrent_header_top></tag:torrent_header_rec><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt><tag:torrents[].dt>
                                                </tag:torrents[].dt><tag:torrents[].dttt>
                                                </tag:torrents[].dttt><if:uploo>
                                                      </if:uploo><tag:torrents[].recommended><tag:torrents[].top></tag:torrents[].top></tag:torrents[].recommended><tag:torrents[].dtt>
                                                </tag:torrents[].dtt>
                                                </td></tr><tr>
                                              </tr>
                                              <tr>
                                                <td align="center" colspan="2">

                                            <select class="drop_pager" name="pages" onchange="location=document.change_page1pages.pages.options[document.change_page1pages.pages.selectedIndex].value" size="1">
                                            <option selected="selected" value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=1">1</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2">2</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=3">3</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=4">4</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=5">5</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=6">6</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=7">7</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=8">8</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=9">9</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=10">10</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=11">11</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=12">12</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=13">13</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=14">14</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=15">15</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=16">16</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=17">17</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=18">18</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=19">19</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=20">20</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=21">21</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=22">22</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=23">23</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=24">24</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=25">25</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=26">26</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=27">27</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=28">28</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=29">29</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=30">30</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=31">31</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=32">32</option>
                                            <option value="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=33">33</option>
                                            </select>
                                             <span class="pagercurrent"><b>1</b></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2">2</a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=3">3</a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=2"> ></a></span>
                                             <span class="pager"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=64&amp;options=0&amp;order=3&amp;by=2&amp;pages=33"> »</a></span>

                                            </td>
                                              </tr>
                                            </tbody></table></div>
                                            </div>

                                            <div class="block-foot">
                                            </div>

                                            </div>
                                              </td>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  <td id="rcol" valign="top" width="180"><tag:main_right></tag:main_right></td>
                                                  <td rowspan="2" valign="top" width="5"></td>
                                                  </tr>
                                                </tbody></table><if:has_left></if:has_left><if:has_right></if:has_right>


                                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tbody><tr>
                                                  <td rowspan="2" valign="top" width="10"></td>
                                                  <td id="fcol" valign="top"><br/>
                                            </td>
                                                  <td rowspan="2" valign="top" width="10"></td>
                                                  </tr>
                                                </tbody></table>
                                            		<if:has_dis><table align="center" border="0" cellpadding="5" cellspacing="1" width="100%">
                                              <tbody><tr>
                                            	  <td valign="top">
                                            <table align="center" cellpadding="0" cellspacing="0" width="100%">
                                              <tbody><tr>
                                                <td height="26" width="100%">  <b>Site Disclaimer</b></td>
                                              </tr></tbody></table>
                                            	<table align="center" border="0" cellpadding="0" cellspacing="0" height="70" width="100%">
                                               <tbody><tr><td align="center" class="lista" style="padding-left:20px; padding-right:20px;"><center>None of the files shown here are actually hosted on the server of (Download verified torrents: movies, music, games, software | leetxtorrents). The links are provided solely by this site's users. The administrator of this site cannot be held responsible for what its users post, or any other actions of its users. You may not use this site to distribute or download any material when you do not have the legal rights to do so. It is your own responsibility to adhere to these terms. By registering on and/or using this website, it is assumed that <u>you</u>, as the user, have read, understood, and agreed to all the terms and conditions set forth by the site's owner.</center></td>
                                                </tr>
                                              </tbody></table></td>
                                            </tr></tbody></table></if:has_dis>

                                                <table align="center" border="0" cellpadding="0" cellspacing="0" height="46" width="100%">
                                                  <tbody><tr>
                                                  <td align="center" valign="middle">[ Queries: 254|0 ] - [ Script Execution: 1.1351 sec. ] - [ GZIP: enabled ]</td>
                                                  </tr>
                                                </tbody></table>
                                                </div>

                                            </div></tag:season></body></html>
'''
#
# import requests
#
# url = "http://leetxtorrents.org/index.php?page=torrents&search=&category=64&uploader=0&options=0&active=1&gold=0"
# browser = requests.Session()
# import bs4
# import re
# response = browser.get(url)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.findAll("td", {"valign": "middle", "class": "lista"})
# for link in links:
#     print link.text
# links = soup.findAll('a', href=re.compile(r'magnet*'))
# for a in links:
#     print a["href"]
# import requests
#
# url = "http://www.elitetorrent.net/categoria/1/estrenos/modo:listado/pag:1"
# browser = requests.Session()
# page = "1"
# import bs4
#
# response = browser.get( url + page)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.select("a.nombre")
# for link in links:
#     print link.get("title", ""), link["href"]

import re
#titles = re.findall(r'<td.*?valign="middle"><a.*?>(.*?)</a>.*?</td>', data)
titles = re.findall(r'<td.*?valign="middle"><a.*?title=.*?>(.*?)</a>.*?</td>', data)
urlSources = re.findall(r'magnet:\?[^\'"\s<>\[\]]+', data)
print(titles)
print(urlSources)