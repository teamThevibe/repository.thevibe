# # coding: utf-8
# url = 'https://torrentz.eu/801b79cecfd6d04ba42dadea121dc6cd65363c88'
# hash = url[url.rfind('/')+1:]
# magnet = 'magnet:?xt=urn:btih:%s' % hash
# print magnet

import urlparse
s = "page=torrents&search=&category=64&uploader=0&options=0&active=1&gold=0"
print dict(urlparse.parse_qsl(s))