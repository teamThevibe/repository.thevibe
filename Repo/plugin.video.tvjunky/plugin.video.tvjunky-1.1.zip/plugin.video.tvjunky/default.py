import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,settings,urlresolver
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
from metahandler import metahandlers
from metahandler import metacontainers
from BeautifulSoup import BeautifulSoup
from universal import favorites
from universal import _common as univ_common
from universal import playbackengine
from settings import *
import time,datetime
import base64
try:
    from addon.common.addon import Addon
    from addon.common.net import Net
except:
    print 'Failed to import script.module.addon.common'
    xbmcgui.Dialog().ok("TV Channel Import Failure")

play = addon.queries.get('play', '')
############################################################################################################################################################

import threading

class Thread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)
    def run(self):
        self._target(*self._args)


icon = 'icon.png'
fanart = 'fanart.png'
fav = favorites.Favorites('plugin.video.tvjunky', sys.argv)
grab = metahandlers.MetaData(preparezip = False)
addon_id = 'plugin.video.tvjunky'
local = xbmcaddon.Addon(id=addon_id)
tvjunkypath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = tvjunkypath+'/art'
net = Net()
cookie_path = os.path.join(datapath, 'cookies')                 
cookie_jar = os.path.join(cookie_path, "cookiejar.lwp")
if os.path.exists(cookie_path) == False:                        
    os.makedirs(cookie_path)
#SUBSCRIPTION_FILE = settings.subscription_file()
#SUBSCRIPTIONS_ACTIVATED = settings.subscription_update()
strdomain ="http://www.vidics.ch"
############################################################################################################################################################

IMDb_url = 'http://akas.imdb.com'
IMDbIT_url = 'http://akas.imdb.com/movies-in-theaters/?ref_=nb_mv_2_inth'
IMDb250_url = 'http://akas.imdb.com/search/title?groups=top_250&sort=user_rating&my_ratings=exclude'
kidzone_url = 'http://akas.imdb.com/search/title?genres=animation,family&title_type=feature,tv_movie'
kidzonetv_url = 'http://akas.imdb.com/search/title?genres=animation,family&title_type=tv_series,tv_special,mini_series'
onechannel_base = 'http://www.primewire.ag'
onechannel_featuredtv = 'http://www.primewire.ag/?tv=&sort=featured'
onechannel_lastesttv = 'http://www.primewire.ag/?tv'
onechannel_populartv = 'http://www.primewire.ag/?tv=&sort=views'
onechannel_ratingstv = 'http://www.primewire.ag/?tv=&sort=ratings'
onechannel_releasedatetv = 'http://www.primewire.ag/?tv=&sort=release'
IMDBTV_WATCHLIST = settings.imdbtv_watchlist_url()
IMDB_LIST = settings.imdb_list_url()


tvjunky_url = 'http://tv-junky.eu/'


#Metahandler
def GRABMETA(name,types,year=None):
        type = types
        if year=='': year=None
        EnableMeta = local.getSetting('Enable-Meta')
        #
        if year==None:
                try: year=re.search('\s*\((\d\d\d\d)\)',name).group(1)
                except: year=None
        if year is not None: name=name.replace(' ('+year+')','').replace('('+year+')','')
        #
        if EnableMeta == 'true':
                if 'Movie' in type:
                        ### grab.get_meta(media_type, name, imdb_id='', tmdb_id='', year='', overlay=6)
                        meta = grab.get_meta('movie',name,'',None,year,overlay=6)
                        infoLabels = {'rating': meta['rating'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],'director': meta['director'],'cast': meta['cast'],'backdrop_url': meta['backdrop_url'],'backdrop_url': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
                elif 'tvshow' in type:
                        meta = grab.get_meta('tvshow',name,'','',year,overlay=6)
                        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'cast': meta['cast'],'studio': meta['studio'],'banner_url': meta['banner_url'],'backdrop_url': meta['backdrop_url'],'status': meta['status']}
        else: infoLabels=[]
        return infoLabels

def get_html(page_url):

        html = net.http_GET(page_url).content

        import HTMLParser
        h = HTMLParser.HTMLParser()
        html = h.unescape(html)
        return html.encode('utf-8')

def _FixText(t):
        if ("&amp;"  in t): t=t.replace('&amp;'  ,'&')#&amp;#x27;
        if ("&nbsp;" in t): t=t.replace('&nbsp;' ," ")
        if ('&#' in t) and (';' in t):
                t=t.replace("&#8211;",";").replace("&#8216;","'").replace("&#8217;","'").replace('&#8220;','"').replace('&#8221;','"').replace('&#215;' ,'x').replace('&#x27;' ,"'").replace('&#xF4;' ,"o").replace('&#xb7;' ,"-").replace('&#xFB;' ,"u").replace('&#xE0;' ,"a").replace('&#xE9;' ,"e").replace('&#xE2;' ,"a").replace('&#0421;',"")
                if ('&#' in t) and (';' in t):
                        try:            matches=re.compile('&#(.+?);').findall(t)
                        except: matches=''
                        if (matches is not ''):
                                for match in matches:
                                        if (match is not '') and (match is not ' ') and ("&#"+match+";" in t): t=t.replace("&#"+match+";" ,"")
        for i in xrange(127,256): t=t.replace(chr(i),"")
        try: t=t.encode('ascii', 'ignore'); t=t.decode('iso-8859-1')
        except: t=t
        return t



######################################################################################################################################################

 #      addDir(name,url,mode,iconimage,types,favtype) mode is where it tells the plugin where to go scroll to bottom to see where mode is
def CATEGORIES():
        addDir('Latest Added',onechannel_lastesttv,41,art_('Latest','Sub Menus'),None,'')
        #addDir('TV Schedule [COLOR red][B]Not working just yet[/B][/COLOR]',strdomain,57,'',None,'')
        addDir('Featured',onechannel_featuredtv,41,art_('Featured','Sub Menus'),None,'')
        addDir('Popular',onechannel_populartv,41,art_('Popular','Sub Menus'),None,'')
        addDir('Ratings',onechannel_ratingstv,41,art_('Ratings','Sub Menus'),None,'')
        addDir('Release Date',onechannel_releasedatetv,41,art_('Release Date','Sub Menus'),None,'')
        addDir('Genre','http://www.imdb.com/genre',43,art_('Genre','Sub Menus'),None,'')
        addDir('Kids Zone (TV)',kidzonetv_url,46,art_('Kids Zone','Sub Menus'),None,'')
        addDir('Tv-junky website',tvjunky_url,32,art_('Tv-Junky','Main Menu'),None,'')
        #addDir('IMDb',IMDb_url,53,art_('IMDb','Sub Menus'),None,'')
        addDir('Search',tvjunky_url,49,art_('Search','Sub Menus'),None,'')
        fav.add_my_fav_directory(img=art_('Favorites','Main Menu'))
        addDir('Settings','http://',309,art_('Settings','Main Menu'),None,'')
        addDir('Resolver Settings',tvjunky_url,310,art_('Resolver','Main Menu'),None,'')
        set_view('list')


        

################################################################################################################################################################
       
def onechannelindex(url):
        EnableMeta = local.getSetting('Enable-Meta')
        html = get_html(url)
        match =  re.compile('<a href="(.+?)" title="Watch (.+?)(\([\d]{4}\))"><img src="(.+?)" border="0" width="150" height="225" alt=".+?"><h2>.+?</h2></a>').findall(html)
        for url, name, year, thumbnail in match:
                name = str(name).replace('USA','US')
                #name = str(name).replace('(2000)','').replace('(2001)','').replace('(2002)','').replace('(2003)','').replace('(2004)','').replace('(2005)','').replace('(2006)','').replace('(2007)','').replace('(2008)','').replace('(2009)','').replace('(2010)','').replace('(2011)','').replace('(2012)','').replace('(2013)','').replace('(2014)','').replace('(2015)','')       
                if EnableMeta == 'true': addDir(name+' '+year,url,79,'','tvshow','TV-Shows')
                if EnableMeta == 'false': addDir(name+' '+year,url,79,'',None,'TV-Shows')
        nextpage = re.compile('<div class="pagination">.+?class=current>.+?href="(.+?)">.+?<a href=".+?">.+?</a>.+?<a href=".+?">.+?</div>',re.DOTALL).findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]','http://www.primewire.ag'+nextpage[0],41,'',None,'')
        set_view('tvshows')

def SEASONS(url):
        url1 = 'http://www.primewire.ag'+url
        html = get_html(url1)
        match=re.compile('<h2><a href="(.+?)">(.+?)</a></h2>').findall(html)
        for url,name in match:
                addDir(name,url,51,'',None,'TV-Shows')
        set_view('seasons')

def EPISODES1C(url):
        EnableMeta = local.getSetting('Enable-Meta')
        url1 = 'http://www.primewire.ag'+url
        html = get_html(url1)
        match = re.compile('<div class="tv_episode_item"> <a href="(.+?)">(.+?)                                <span class="tv_episode_name">(.+?)</span>',re.DOTALL).findall(html)
        match2 = re.compile('<h1 class="titles"><span>(.+?) Links</span></h1>').findall(html)
        for url,name1,name2 in match:
                for title in match2:
                        if EnableMeta == 'true':  addDirLinktv(title +': '+ name1 + name2,title,url,48,'','tvshow','TV-Shows')
                        if EnableMeta == 'false': addDirLinktv(title +': '+ name1 + name2,title,url,48,thumbnail,None,'TV-Shows')
                set_view('list')

### Tv Junkie ####################################################################################################################################################################

def tvjunkieIndex(url):
        html = get_html(url)
        match =  re.compile('<a href="(.+?)" rel=".+?" title=".+?">(.+?)</a>\n                        </div>').findall(html)
        for url, name in match:
                addDir(name,url,33,'',None,'Movies')
        nextpage = re.compile('<a href="(.+?)" >Next Page .+?</a>                </div>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],53,'',None,'')

def tvjunkieIndex2(url):
        html = get_html(url)
        match =  re.compile('<a href="(.+?)" rel=".+?" title=".+?">(.+?)</a>\n                        </div>').findall(html)
        for url, name in match:
                addDir(name,url,33,'',None,'Movies')
        nextpage = re.compile('<a href=".+?" >.+? Previous Page</a> .+? <a href="(.+?)" >Next Page .+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],53,'',None,'')
        
def URLLINKSTVJ(url,name):
        html = get_html(url)
        match=re.compile('<a href="(.+?)" rel="nofollow">(.+?)</a>',re.DOTALL).findall(html)
        for url, name in match:
            name=removeCollectiveText(name)
            addDir(name,url,31,'',None,'')

def tvjunkieSEARCH(url):
        searchStr = ''
        keyboard = xbmc.Keyboard(searchStr, "Search")
        keyboard.doModal()
        if (keyboard.isConfirmed() == False):
                return
        searchstring = keyboard.getText()
        if len(searchstring) == 0:
                return
        
        newStr = searchstring.replace(' ','+')
        html = get_html(tvjunky_url+'?s='+newStr)#http://tv-junky.eu/?s=storage+wars
        
        match =  re.compile('<a href="(.+?)" rel=".+?" title=".+?">(.+?)</a>\n                        </div>').findall(html)
        for url, name in match:
                addDir(name,url,33,'',None,'Tv-Shows')
        nextpage = re.compile('<a href="(.+?)" >Next Page .+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],49,'',None,'')

def CollectiveTJsearch(name):
        name=removeCollectiveText(name)
        newStr = name.replace(' ','+')
        html = get_html(tvjunky_url+'?s='+newStr)#http://tv-junky.eu/?s=storage+wars
        
        match =  re.compile('<a href="(.+?)" rel=".+?" title=".+?">(.+?)</a>\n                        </div>').findall(html)
        for url, name in match:
                addDir(name,url,33,'',None,'Tv-Shows')
        nextpage = re.compile('<a href="(.+?)" >Next Page .+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],49,'',None,'')





## Channel Cut index #######################################################################################################################################################################                

def CHANNELCUT():
        addDir('Most recent 150',channelcut_url,65,art_('TV Shows','Sub Menus'),None,'')
        addDir('Search',channelcut_url,67,art_('TV Shows','Sub Menus'),None,'')

def channelcutindex(url):
        html = get_html(url)
        match =  re.compile('<li>.+? : <a href="(.+?)">(.+?)</a> </li>').findall(html)
        for url, name in match:
                name = re.sub(' Episode ','x',name)
                show,sep,numbers = name.partition('Season')
                name = show + '' + numbers
                name = name.replace("&#8217;","")
                addDir(name,url,66,'',None,'Tv-Shows')
        nextpage = re.compile('<span class="prev"><a href="(.+?)" >Previous Posts</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],65,'',None,'')

def URLLINKSCC(url,name):
        html = get_html(url)
        match=re.compile('<p><a href="(.+?)" rel="nofollow">http://(.+?)</a></p>').findall(html)
        for url, name in match:
            name = name.split('/')[0]
            addDir(name,url,31,'',None,'')

def channelcutSEARCH(name):
        searchStr = ''
        keyboard = xbmc.Keyboard(searchStr, "Search")
        keyboard.doModal()
        if (keyboard.isConfirmed() == False):
                return
        searchstring = keyboard.getText()
        if len(searchstring) == 0:
                return
        newStr = searchstring.replace(' ','+')
        html = get_html('http://www.channelcut.me/?s='+newStr+'&searchsubmit=Search')#http://www.channelcut.me/?s=man+down&searchsubmit=Search
        match =  re.compile('<h2><a href="(.+?)" rel="bookmark" title="(.+?)">.+?</a> </h2>').findall(html)
        for url, name in match:
                name = re.sub(' Episode ','x',name)
                show,sep,numbers = name.partition('Season')
                name = show + '' + numbers
                name = name.replace("&#8217;","")
                addDir(name,url,66,'',None,'TV-Shows')
        nextpage = re.compile('<span class="prev"><a href="(.+?)" >Previous Posts</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],70,'',None,'')

def channelcutSEARCH2(url):
        html = get_html(url)
        match =  re.compile('<h2><a href="(.+?)" rel="bookmark" title="(.+?)">.+?</a> </h2>').findall(html)
        for url, name in match:
                name = re.sub(' Episode ','x',name)
                show,sep,numbers = name.partition('Season')
                name = show + '' + numbers
                name = name.replace("&#8217;","")
                addDir(name,url,66,'',None,'TV-Shows')
        nextpage = re.compile('<span class="prev"><a href="(.+?)" >Previous Posts</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],70,'',None,'')

def CollectiveCCsearch(name):
        name=removeCollectiveText(name)
        newStr = name.replace(' ','+')
        html = get_html('http://www.channelcut.me/?s='+newStr+'&searchsubmit=Search')#http://www.channelcut.me/?s=man+down&searchsubmit=Search
        match =  re.compile('<h2><a href="(.+?)" rel="bookmark" title="(.+?)">.+?</a> </h2>').findall(html)
        for url, name in match:
                name = re.sub(' Episode ','x',name)
                show,sep,numbers = name.partition('Season')
                name = show + '' + numbers
                name = name.replace("&#8217;","")
                addDir(name,url,66,'',None,'TV-Shows')
        nextpage = re.compile('<span class="prev"><a href="(.+?)" >Previous Posts</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],70,'',None,'')
        
## IMDB ###########################################################################################################################################################################

def ALLTIMEIMDB(url):
        req = urllib2.Request(url)
        link=OPEN_URL(url)
        match = re.compile('<img src="(.+?)" height="74" width="54" alt=".+?" title="(.+?)(\([\d]{4}\))"></a>\n  </td>\n  <td class="title">\n    \n\n<span class="wlb_wrapper" data-tconst="(.+?)" data-size="small" data-caller-name="search"></span>\n\n    <a href=".+?">.+?</a>\n    <span class="year_type">.+?</span><br>\n<div class="user_rating">\n\n\n<div class="rating rating-list" data-auth=".+?" id=".+?" data-ga-identifier="advsearch"\n title=".+?click stars to rate">\n<span class="rating-bg">&nbsp;</span>\n<span class="rating-imdb" style="width.+?">&nbsp;</span>\n<span class="rating-stars">\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>1</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>2</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>3</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>4</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>5</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>6</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>7</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>8</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>9</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>10</span></a>\n</span>\n<span class="rating-rating"><span class="value">.+?</span><span class="grey">/</span><span class="grey">10</span></span>\n<span class="rating-cancel"><a href=".+?" title="Delete" rel="nofollow"><span>X</span></a></span>\n&nbsp;</div>\n\n</div>\n<span class="outline">(.+?)</span>').findall(link)
        nextp=re.compile('<a href="(.+?)">Next&nbsp;').findall(link)
        try:
                nextp1=nextp[0]
        except:
                pass       
        for iconimage, name,year,url, description in match:
            name = str(name).replace('&#xB7;','').replace('&#x27;','').replace('&#x26;','And').replace('&#xE9;','e').replace('&amp;','And').replace(' TV Series','')
            iconimage1 = iconimage
            url = ' http://akas.imdb.com/title/'+str(url)+'/'
            regex=re.compile('(.+?)_V1.+?.jpg')
            regex1=re.compile('(.+?).gif')
            try:
                    match = regex.search(iconimage1)
                    iconimage= '%s_V1_.SX593_SY799_.jpg'%(match.group(1))
                    fanart= '%s_V1.jpg'%(match.group(1))
            except:
                    pass
            try:    
                    match= regex1.search(iconimage1)
                    iconimage= '%s.gif'%(match.group(1))
                    fanart= '%s_V1.jpg'%(match.group(1))
            except:
                    pass
                    addDirLink(name+' '+year,url,68,iconimage,None,description)   
                    set_view('list') 
        try:
                url=' http://akas.imdb.com'+str(nextp1)
                name= '[COLOR blue][B]Next Page >>[/B][/COLOR]'
                addDir(name+' '+year,url,45,'',None,'')
                set_view('list') 
        except:
                pass
        addDir('[COLOR red][B]<< Return To Main Menu[/B][/COLOR]','url','','',None,'')    
        set_view('list')

def ALLTIMEIMDBTV(url):
        req = urllib2.Request(url)
        link=OPEN_URL(url)
        match = re.compile('<img src="(.+?)" height="74" width="54" alt=".+?" title="(.+?)(\([\d]{4}\s\TV\s\Series\))"></a>\n  </td>\n  <td class="title">\n    \n\n<span class="wlb_wrapper" data-tconst="(.+?)" data-size="small" data-caller-name="search"></span>\n\n    <a href=".+?">.+?</a>\n    <span class="year_type">.+?</span><br>\n<div class="user_rating">\n\n\n<div class="rating rating-list" data-auth=".+?" id=".+?" data-ga-identifier="advsearch"\n title=".+?click stars to rate">\n<span class="rating-bg">&nbsp;</span>\n<span class="rating-imdb" style="width.+?">&nbsp;</span>\n<span class="rating-stars">\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>1</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>2</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>3</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>4</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>5</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>6</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>7</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>8</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>9</span></a>\n<a href=".+?" title="Register or login to rate this title" rel="nofollow"><span>10</span></a>\n</span>\n<span class="rating-rating"><span class="value">.+?</span><span class="grey">/</span><span class="grey">10</span></span>\n<span class="rating-cancel"><a href=".+?" title="Delete" rel="nofollow"><span>X</span></a></span>\n&nbsp;</div>\n\n</div>\n<span class="outline">(.+?)</span>').findall(link)
        nextp=re.compile('<a href="(.+?)">Next&nbsp;').findall(link)
        try:
                nextp1=nextp[0]
        except:
                pass       
        for iconimage, name, year, url, description in match:
            name = str(name).replace('&#xB7;','').replace('&#x27;','').replace('&#x26;','And').replace('&#xE9;','e').replace('&amp;','And').replace(' TV Series','')
            iconimage1 = iconimage
            url = ' http://akas.imdb.com/title/'+str(url)+'/'
            regex=re.compile('(.+?)_V1.+?.jpg')
            regex1=re.compile('(.+?).gif')
            try:
                    match = regex.search(iconimage1)
                    iconimage= '%s_V1_.SX593_SY799_.jpg'%(match.group(1))
                    fanart= '%s_V1.jpg'%(match.group(1))
            except:
                    pass
            try:    
                    match= regex1.search(iconimage1)
                    iconimage= '%s.gif'%(match.group(1))
                    fanart= '%s_V1.jpg'%(match.group(1))
            except:
                    pass
                    addDir(name,url,68,iconimage,None,description)   
                    set_view('list') 
        try:
                url='http://akas.imdb.com'+str(nextp1)
                name= '[COLOR blue][B]Next Page >>[/B][/COLOR]'
                addDir(name,url,47,'',None,'')
                set_view('list') 
        except:
                pass
        addDir('[COLOR red][B]<< Return To Main Menu[/B][/COLOR]','url','','',None,'')    
        set_view('list')

def IMDBGENRE(url):
        link=OPEN_URL(url)
        match = re.compile('<a href="/genre/(.+?)">(.+?)</a>').findall(link)
        for url1, name, in match:
                url=' http://akas.imdb.com/search/title?genres=%s&title_type=feature&sort=moviemeter,asc'% (url1)
                iconimage=art+url1+'.png'
                addDir(name,url,34,iconimage,None,'')
                set_view('list')

def IMDBGENRETV(url):
        link=OPEN_URL(url)
        match = re.compile('<a href="/genre/(.+?)">(.+?)</a>').findall(link)
        for url1, name, in match:
                url=' http://akas.imdb.com/search/title?genres=%s&title_type=tv_movie,tv_series,tv_special'% (url1)
                iconimage=art+url1+'.png'
                addDir(name,url,47,iconimage,None,'')
                set_view('list')

def IMDB_SEARCHTV(url):
        EnableMeta = local.getSetting('Enable-Meta')
        searchStr = ''
        keyboard = xbmc.Keyboard(searchStr, "Search")
        keyboard.doModal()
        if (keyboard.isConfirmed() == False):
                return
        searchstring = keyboard.getText()
        if len(searchstring) == 0:
                return
        newStr = searchstring.replace(' ','%20')
        #http://www.imdb.com/find?q='+newStr+'&s=all'
        html = get_html(url+'/search/title?title='+newStr+'&title_type=tv_movie,tv_series,tv_episode,tv_special,mini_series')
        
        match =  re.compile('<a href="(.+?)" title="(.+?)(\([\d]{4}\s\TV\s\Series\))"><img src="(.+?)" height="74" width="54" alt=".+?" title=".+?"></a>').findall(html)
        for url, name, year, thumbnail in match:
                name = str(name).replace('&#xB7;','').replace('&#x27;','').replace('&#x26;','And').replace('&#xE9;','e').replace('&amp;','And').replace(' TV Series','').replace('&#x22;','"')
                if EnableMeta == 'true':  addDirLink(name,url,68,'','tvshow','TV-Shows')
                if EnableMeta == 'false': addDirLink(name,url,68,thumbnail,None,'TV-Shows')
        set_view('list')

def KIDSzonetv(url):
        EnableMeta = local.getSetting('Enable-Meta')
        html = get_html(url)
        match =  re.compile('<a href="(.+?)" title="(.+?)(\([\d]{4}\s\TV\s\Series\))"><img src="(.+?)" height="74" width="54" alt=".+?" title=".+?"></a>').findall(html)
        for url, name, year, thumbnail in match:
                name = str(name).replace('USA','US').replace('&#xB7;','').replace('&#x27;','').replace('&#x26;','And').replace('&#xE9;','e').replace('&amp;','And').replace('&#x22;','"')
                if EnableMeta == 'true':  addDir(name,url,68,'','tvshow','TV-Shows')
                if EnableMeta == 'false': addDir(name,url,68,thumbnail,None,'TV-Shows')
        nextpage = re.compile('<a href="(.+?)">Next.+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',' http://akas.imdb.com/'+nextpage[0],50,'',None,'')


####################################################################################################################################################################################
                         
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link

def removeCollectiveText(text):
        text= re.sub('\[COLOR.*?\[/COLOR\]','',text,re.I|re.DOTALL).strip()
        return re.sub('[(\d{4})]','',text)#name=removeCollectiveText(name)

def add_contextsearchmenu(title, video_type):
    contextmenuitems = []

    if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.collective'):
        contextmenuitems.append(('Search [COLOR blue]The Collective[/COLOR] (Movies)', 'XBMC.Container.Update(%s?mode=12&url=url&name=%s)' % (
            'plugin://plugin.video.collective/', title)))
    if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.collective'):
        contextmenuitems.append(('Search [COLOR blue]The Collective[/COLOR] (TV)', 'XBMC.Container.Update(%s?mode=30&url=url&name=%s)' % (
            'plugin://plugin.video.collective/', title)))
        

    return contextmenuitems

###########################################################################################################################################################################

def resolve_url(url):
        return resolvers.resolve_url(url)

def STREAM(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
	print streamlink
	addLink('Click to [COLOR blue]Play[/COLOR]',streamlink,'')
	set_view('list')
	

##############################################################################################################################################################################

def add_executeaddonstv(name):
        name = name.split(':')[0]
        name=removeCollectiveText(name)
        search = name
        addons_name = []
        addons_context = []
        
        addons_name.append('[COLOR blue][B]Tv Junkie[/B][/COLOR]')
        addons_context.append('plugin://plugin.video.tvchannel/?mode=49&url=url&name='+urllib.quote_plus(search))
        addons_name.append('[COLOR blue][B]TV Release[/B][/COLOR]')
        addons_context.append('plugin://plugin.video.tvchannel/?mode=64&url=url&name='+urllib.quote_plus(search))
        addons_name.append('[COLOR blue][B]Channel Cut[/B][/COLOR]')
        addons_context.append('plugin://plugin.video.tvchannel/?mode=68&url=url&name='+urllib.quote_plus(search))
        
                
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Select"'+search.title()+'" one of the addons below', addons_name)
        if ret == -1:
                xbmcplugin.addDirectoryItem
        contextommand = addons_context[ret]
        xbmc.executebuiltin('Container.Update('+contextommand+')')
       

##############################################################################################################################################################################

        
def SEARCHTITLES(url):
        searchStr = ''
        keyboard = xbmc.Keyboard(searchStr, "Search")
        keyboard.doModal()
        if (keyboard.isConfirmed() == False):
                return
        searchstring = keyboard.getText()
        if len(searchstring) == 0:
                return
        newStr = searchstring.replace(' ','+')
        html = get_html(downtr_url+'?do=search&subaction=search&story='+newStr)#http://www.downtr.co/?do=search&subaction=search&story=man+of+steel
        
        match =  re.compile('<div class="name"><h2>.+?: <a href="(.+?)" >(.+?)</a></h2></div>.+?src=".+?" data-original="(.+?)"',re.DOTALL).findall(html)
        for url, name, iconimage in match:
                addDir(name,url,30,iconimage,None,'Movies')
        nextpage = re.compile('<span class="next"><a href="(.+?)">Next</a></span>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'',None,'')


def UNIVERSALSEARCH(name):
        EnableMeta = local.getSetting('Enable-Meta')
        newStr = searchstring.replace(' ','+')
        html = get_html(viooz_url+'?do=search&subaction=search&story='+newStr)#http://www.downtr.co/?do=search&subaction=search&story=man+of+steel
        
        match =  re.compile('<a href=".+?"><img src="(.+?)".+?<h3 class="title_grid" title="(.+?)">.+?</h3>.+?<span class="title_list"><a href="(.+?)" title=".+?">.+?</a></span>',re.DOTALL).findall(html)
        for iconimage, name, url in match:
                if EnableMeta == 'true':  addDir(name,url,25,'','Movie','Movies')
                if EnableMeta == 'false': addDir(name,url,25,iconimage,None,'Movies')
        nextpage = re.compile('<span class="pagination-actif">.+?</span> <a href="(.+?)">.+?</a>').findall(html)
        if nextpage:
                addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'',None,'')

def SEARCH():
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search Music...XBMCHUB.COM')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText() .replace(' ','+')  # sometimes you need to replace spaces with + or %20
                if search_entered == None:
                        return False
        return search_entered

def SUPERSEARCH():
        search = ''
        keyboard = xbmc.Keyboard(search,'Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search = keyboard.getText()
                search = search.replace(' ','+')

        threads = []

        threads.append(Addon.Thread(CollectiveTRsearch(search)))
        threads.append(Addon.Thread(CollectiveCCsearch(search)))
                
        [i.start() for i in threads]
        [i.join() for i in threads]

def tvreleaseSEARCH(search):
        url = 'http://tv-release.net/?s='+search+'&cat='
        INDEX(url)



#######################################################################################################################################################################

def create_strm_file(name, data, imdb_id, mode, dir_path):
    try:
        strm_string = create_url(name, mode, data=data, imdb_id=imdb_id)
        filename = clean_file_name("%s.strm" % name)
        path = os.path.join(dir_path, filename)
        stream_file = open(path, 'w')
        stream_file.write(strm_string)
        stream_file.close()
    except:
        xbmc.log("Error while creating strm file for : " + name)

def remove_strm_file(name, dir_path):
    try:
        filename = "%s.strm" % (clean_file_name(name, use_blanks=False))
        path = os.path.join(dir_path, filename)
        os.remove(path)
    except:
        xbmc.log("[Was unable to remove movie: %s" % (name)) 

#######################################################################################################################################################################

def smart_unicode(s):
        """credit : sfaxman"""
        if not s:
                return ''
        try:
                if not isinstance(s, basestring):
                        if hasattr(s, '__unicode__'):
                                s = unicode(s)
                        else:
                                s = unicode(str(s), 'UTF-8')
                elif not isinstance(s, unicode):
                        s = unicode(s, 'UTF-8')
        except:
                if not isinstance(s, basestring):
                        if hasattr(s, '__unicode__'):
                                s = unicode(s)
                        else:
                                s = unicode(str(s), 'ISO-8859-1')
                elif not isinstance(s, unicode):
                        s = unicode(s, 'ISO-8859-1')
        return s

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
	return ok

def RemoveHTML(strhtml):
            html_re = re.compile(r'<[^>]+>')
            strhtml=html_re.sub('', strhtml)
            return strhtml

def addDirContext(name,url,mode,iconimage,plot="",vidtype="", cm=[]):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&vidtype="+vidtype
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
        if(len(cm)==0):
                contextMenuItems = AddFavContext(vidtype, url, name, iconimage)
        else:
                contextMenuItems=cm
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDirsehedule(name,url,mode,iconimage,plot=""):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addDir(name,url,mode,iconimage,types,favtype):
        ok=True
        type = types
        if type != None: infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        try: liz.setProperty( "Fanart_Image", infoLabels['backdrop_url'] )
        except: t=''
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        #Universal Favorites
        if 'Movies' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Movies')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        elif 'TV-Shows' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='TV-Shows')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        else:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Other Favorites')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDirLink(name,url,mode,iconimage,types,favtype):
        ok=True
        type = types
        if type != None: infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        try: liz.setProperty( "Fanart_Image", infoLabels['backdrop_url'] )
        except: t=''
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        #Universal Favorites
        if 'Movies' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Movies')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        elif 'TV-Shows' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='TV-Shows')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        else:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Other Favorites')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
    
def addDirLinktv(name,title,url,mode,iconimage,types,favtype):
        ok=True
        type = types
        if type != None: infoLabels = GRABMETA(name,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&title="+str(title)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        try: liz.setProperty( "Fanart_Image", infoLabels['backdrop_url'] )
        except: t=''
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        #Universal Favorites
        if 'Movies' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Movies')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        elif 'TV-Shows' in favtype:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='TV-Shows')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        else:
                contextMenuItems.append(('Add to Favorites', fav.add_directory(name, u, section_title='Other Favorites')))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#####################################################################################################################################################################

params=get_params()
url=None; name=None; mode=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        downtrIndex(url)

elif mode==2:
        print ""+url
        Mostviewsmovies(url)
        
elif mode==3:
        print ""+url
        Randommovies(url)

elif mode==4:
        print ""+url
        OPEN_URL(url)

elif mode==5:
        print ""+url
        SEARCHTITLES(url)

elif mode==6:
        print ''+url
        add_executeaddons(name)

elif mode==7:
        print ''+url
        IMDB_LISTS(url)

elif mode==8:
        print ''+url
        WATCH_TV_LIST(url)

elif mode==9:
        print ''+url
        IMDbInTheaters(url)

elif mode==10:
        print ''+url
        IMDbcat()

elif mode==11:
        print ''+url
        add_executeaddonstv(name)

elif mode==12:
        print ''+url
        ALLTIMEIMDB(url)

elif mode==13:
        print ''+url
        WATCH_LIST_SEARCH(name,url)

elif mode==14:
        print ''+url
        IMDB_SEARCHTV(url)

elif mode==15:
        print ''+url
        IMDBGENRETV(url)

elif mode==16:
        print ''+url
        IMDbtvcat()

elif mode==17:
        print ''+url
        WATCH_MOVIE_LIST(url)

elif mode==18:
        print ''+url
        ALLTIMEIMDBTV(url)

elif mode==19:
        print ''+url
        UNIVERSALSEARCH(name)

elif mode==20:
        print ''+url
        UNIVERSALSEARCHTV(name)

elif mode==21:
        print ''+url
        IMDB_LISTSTV(url)

elif mode==22:
        print ''+url
        add_testexecuteaddons(name)

elif mode==23:
        print ''+url
        SEASONS(url)

elif mode==24:
        print ''+url
        EPISODES(url)

elif mode==25:
        print ''+url
        GetLinks(url)

elif mode==26:
        print ''+url
        STREAM(url)

elif mode==27:
        print ''+url
        WatchedCallback(name,url)

elif mode==28:
        print ''+url
        linkstr(url)

elif mode==29:
        print ''+url
        GetLinks3(name,url,infoLabels=None)

elif mode==30:
        print ''+url
        URLLINKS(url,name)

elif mode==31:
        print ''+url
        STREAM(url)

elif mode==32:
        print ''+url
        tvjunkieIndex(url)

elif mode==33:
        print ''+url
        URLLINKSTVJ(url,name)
        
elif mode==34:
	print ''+url
	divxcentreIndex(url)
	
elif mode==35:
	print ''+url
	URLLINKSDC(url,name)
	
elif mode==36:
	print ''+url
	thetvloversIndex(url)
	
elif mode==37:
	print ''+url
	URLLINKSTVL(url,name)
	
elif mode==38:
	print ''+url
	seriezdlIndex(url)
	
elif mode==39:
	print ''+url
	URLLINKSSDL(url,name)
	
elif mode==40:
	print ''+url
	tvonlineIndex(url)

elif mode==41:
        print ''+url
        onechannelindex(url)

elif mode==42:
        print ''+url
        IMDB_SEARCHTV(url)

elif mode==43:
        print ''+url
        IMDBGENRETV(url)

elif mode==44:
        print ''+url
        IMDBGENRE(url)

elif mode==45:
        print ''+url
        ALLTIMEIMDB(url)

elif mode==46:
        print ''+url
        KIDSzonetv(url)

elif mode==47:
        print ''+url
        ALLTIMEIMDBTV(url)

elif mode==48:
        print ''+url
        add_executeaddonstv(name)

elif mode==49:
        print ''+url
        tvjunkieSEARCH(url)

elif mode==50:
        print ''+url
        SEASONS(url)

elif mode==51:
        print ''+url
        EPISODES1C(url)

elif mode==52:
        print ''+url
        HOSTLIST()

elif mode==53:
        print ''+url
        tvjunkieIndex2(url)

elif mode==54:
        print ''+url
        PROJECTFREETV()

elif mode==55:
        print ''+url
        pftvIndex(url)

elif mode==56:
        print ''+url
        URLLINKSPFTV(url,name)

elif mode==57:
        print ''+url
        searchpftv(url)

elif mode==58:
        print ''+url
        pftvepsseason(url)

elif mode==59:
        print ''+url
        jannajivesIndex(url)

elif mode==60:
        print ''+url
        tvreleaseIndex(url)

elif mode==61:
        print ''+url
        URLLINKSTVR(url,name)

elif mode==62:
        print ''+url
        TVRELEASE()

elif mode==63:
        print ''+url
        tvreleaseSEARCH(name)

elif mode==64:
        print ''+url
        CollectiveTRsearch(name)

elif mode==65:
        print ''+url
        channelcutindex(url)

elif mode==66:
        print ''+url
        URLLINKSCC(url,name)

elif mode==67:
        print ''+url
        channelcutSEARCH(name)

elif mode==68:
        print ''+url
        CollectiveCCsearch(name)

elif mode==69:
        print ''+url
        CHANNELCUT()

elif mode==70:
        print ''+url
        channelcutSEARCH2(url)

elif mode==71:
        print ''+url
        tvreleaseSEARCH2(url)

elif mode==72:
        print ''+url
        onechannelindex1(url)

elif mode==73:
        print ''+url
        SEASONS1(url)

elif mode==74:
        print ''+url
        EPISODES1C1(url)

elif mode==75:
        print ''+url
        URLLINKS1CH(url)

elif mode==76:
        print ''+url
        ONECHANNEL()

elif mode==77:
        print ''+url
        URLLINKSJJ(url,name)

elif mode==78:
        print ''+url
        SUPERSEARCH()

elif mode==79:
        print ''+url
        CollectiveTJsearch(name)
	

elif mode==309:
        print ''+url
        addon.addon.openSettings()

elif mode==310:
        print ''+url
        urlresolver.display_settings()

                
xbmcplugin.endOfDirectory(int(sys.argv[1]))
