import time
import urllib, sys, os
import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
import downloader
from xml.dom.minidom import parse
import xml.etree.ElementTree
import extract
import zipfile

## Writen By Guy Almog From The-VIBE.CO.IL TEAM ##

addonID = "skin.phenomenal"
Addon = xbmcaddon.Addon(addonID)
AddonName = Addon.getAddonInfo("version")

def left(s, amount):
    return s[:amount]

def right(s, amount):
    return s[-amount:]

def mid(s, offset, amount):
    return s[offset:offset+amount]

def renameandext(czipfile,newname):
    source = zipfile.ZipFile(czipfile, 'r')
    target = zipfile.ZipFile(newname, 'w', compression=zipfile.ZIP_DEFLATED)
    for file in source.filelist:
        if not file.filename.startswith('skin.phenomenal-master'):
            target.writestr(file.filename, source.read(file.filename))
        elif file.filename.startswith('skin.phenomenal-master'):
            target.writestr(file.filename.replace("skin.phenomenal-master", "skin.phenomenal"), source.read(file.filename))
    target.close()
    source.close()
    return True

if __name__ == '__main__':
    monitor = xbmc.Monitor()
 
while not monitor.abortRequested():
    print "############   Checking For Fm Update - The Current Ver Is " + AddonName + "  #################"
    path=xbmc.translatePath(os.path.join('special://home','addons','packages'));
    url="https://github.com/tomer953/skin.phenomenal/raw/master/addon.xml"
    lib=os.path.join(path,'FMaddon.xml')
    try: os.remove(lib)
    except: pass
    downloader.download2(url,lib)
    skinshortcutspath = xbmc.translatePath(lib).decode("utf-8")
    if xbmcvfs.exists( skinshortcutspath ):
        e = xml.etree.ElementTree.parse(skinshortcutspath).getroot()
        print "############   Checking For FM Update - The UPDATE Ver Is " + e.attrib['version'] + "  #################"
        if (e.attrib['version']!=AddonName):
            print "####### NEED SKIN UPDATE !! #############"
            xbmc.sleep(5000)
            dialog = xbmcgui.Dialog()
            confirm = dialog.yesno('Skin Have Update ' + e.attrib['version'] + '', 'Do you wish to install it ? ')
            if confirm:
                print "####### Starting update !! #############"
                url="https://github.com/tomer953/skin.phenomenal/archive/master.zip"
                lib=os.path.join(path,'FMUPDATE.zip')
                libnew=os.path.join(path,'FMUPDATEnew.zip')
                try:
                    os.remove(lib)
                    os.remove(libnew)
                except: pass            
                downloader.download(url,lib)
                renameandext(lib,libnew)
                try: os.remove(lib)
                except: pass
                addonfolder=xbmc.translatePath(os.path.join('special://','home','addons'))
                try: extract.all(libnew,addonfolder)
                except:
                    print "####### ERROR UPDATE !! #############"
                    pass
                print "####### Finished update TO " + e.attrib['version'] + "!! #############"
                try: os.remove(libnew)
                except: pass            
                dialog.ok('Finished Update To ' + e.attrib['version'] + '','Please Restart Your Kodi','')
    if monitor.waitForAbort(14400):
      # Abort was requested while waiting. We should exit
      break
