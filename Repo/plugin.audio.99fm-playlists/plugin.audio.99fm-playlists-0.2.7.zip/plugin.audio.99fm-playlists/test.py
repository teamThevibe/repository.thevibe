# -*- coding: utf-8 -*-
import requests
import json
import urllib
from xbmcswift2 import Plugin, xbmcplugin, xbmc, actions
from bs4 import BeautifulSoup

def get_json():
    # req = requests.get('http://nirelbaz.com/kodi/data/playlists.json')
    req = requests.get('http://localhost:5555/playlists.json')
    return json.loads(req.text)

print get_json()[1]['playlists'][1]['songs']