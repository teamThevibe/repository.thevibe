# -*- coding: utf-8 -*-
import requests
import json
import urllib
from xbmcswift2 import Plugin, xbmcplugin, xbmc, actions


plugin = Plugin()


@plugin.cached()
def get_json():
    req = requests.get('http://nirelbaz.com/kodi/data/playlists.json')
    return json.loads(req.text)


def make_favorite_ctx(parent_title, item_title):
    label = u'הוסף לפלייליסטים שלי'
    new_url = plugin.url_for('add_to_favorites', parent_title=parent_title.encode('UTF-8'), item_title=item_title.encode('UTF-8'))
    return (label, actions.background(new_url))


def make_unfavorite_ctx(title):
    label = u'הסר מהפלייליסטים שלי'
    new_url = plugin.url_for('remove_from_favorites', title=title.encode('UTF-8'))
    return (label, actions.update_view(new_url))


@plugin.route('/')
def index():
    favorites = plugin.get_storage('favorites')
    categories = []
    index = 0

    # Add user's favorites category:
    if len(favorites.keys()) > 0:
        bg_image = 'special://home/addons/{}/resources/media/favorites.jpg'.format(plugin.id)
        categories.append({
            'label': u'\u2764 רשימת הפלייליסטים המועדפים שלי',
            'icon': bg_image,
            'thumbnail': bg_image,
            'path': plugin.url_for('show_favorites'),
            'is_playable': False,
            'properties': {
                'Fanart_Image': bg_image
            }
        })

    # Add native items
    for category in get_json():
        try:
            bg_image = urllib.quote(category['bgImage'], safe=':/?=')
        except:
            bg_image = plugin.addon.getAddonInfo('fanart')
            pass

        categories.append({
            'label': u'- {1}[B]{0}[/B]'.format(category['title'].upper(), category['slogan']),
            'icon': bg_image,
            'thumbnail': bg_image,
            'path': plugin.url_for('show_playlists', index=index),
            'is_playable': False,
            'properties': {
                'Fanart_Image': bg_image,
                'Artist_Description': category['slogan']
            }
        })
        index += 1


    return categories


@plugin.route('/playlists/<index>/')
def show_playlists(index):
    favorites = plugin.get_storage('favorites')
    playlists = []

    for playlist in get_json()[int(index)]['playlists']:
        try:
            bg_image = urllib.quote(playlist['bgImage'], safe=':/?=')
        except:
            bg_image = plugin.addon.getAddonInfo('fanart')
            pass

        playlists.append({
            'label': u'- {1}[B]{0}[/B]'.format(playlist['title'].upper(), playlist['slogan']),
            'icon': bg_image,
            'thumbnail': bg_image,
            'path': urllib.quote(playlist['audio'], safe=':/?='),
            'is_playable': True,
            'context_menu': [
                make_favorite_ctx(get_json()[int(index)]['title'], playlist['title']),
            ],
            # 'replace_context_menu': True,
            'properties': {
                'poster': bg_image,
                'thumb': bg_image,
                'fanart': bg_image,
                'Fanart_Image': bg_image,
                'mimetype': 'audio/mpeg',

            },
            'info': {
                'Title': playlist['title'],
                'Artist': playlist['slogan'],
                'Artist_Description': playlist['slogan']
            }
        })
    return plugin.finish(playlists)


@plugin.route('/show_favorites')
def show_favorites():
    favorites = plugin.get_storage('favorites')
    playlists = []

    for playlist in favorites.items():
        bg_image = urllib.quote(playlist[1]['icon'], safe=':/?=')
        playlists.append({
            'label': '[B]' + playlist[1]['title'] + '[/B] - ' + playlist[1]['slogan'],
            'icon': bg_image,
            'thumbnail': bg_image,
            'path': urllib.quote(playlist[1]['audio'], safe=':/?='),
            'is_playable': True,
            'context_menu': [
                make_unfavorite_ctx(playlist[1]['title']),
            ],
            # 'replace_context_menu': True,
            'properties': {
                'poster': bg_image,
                'thumb': bg_image,
                'fanart': bg_image,
                'Fanart_Image': bg_image,
                'mimetype': 'audio/mpeg',

            },
            'info': {
                'Title': playlist[1]['title'],
                'Artist': playlist[1]['slogan'],
                'Artist_Description': playlist[1]['slogan']
            }
        })
    return plugin.finish(playlists)


@plugin.route('/favorites/add/<parent_title>/<item_title>')
def add_to_favorites(parent_title, item_title):
    favorites = plugin.get_storage('favorites')
    if not favorites.get(item_title.decode('UTF-8')):
        playlists = [item for item in get_json() if item['title'] == parent_title.decode('UTF-8')][0]['playlists']
        playlist = [item for item in playlists if item['title'] == item_title.decode('UTF-8')][0]

        favorites[item_title.decode('UTF-8')] = {
            'title': playlist['title'],
            'slogan': playlist['slogan'],
            'icon': urllib.quote(playlist['bgImage'], safe=':/?='),
            'audio': playlist['audio']
        }

        plugin.notify('הפלייליסט התווסף לרשימת המועדפים')


@plugin.route('/favorites/remove/<title>')
def remove_from_favorites(title):
    favorites = plugin.get_storage('favorites')
    favorites.pop(title.decode('UTF-8'))
    plugin.redirect(plugin.url_for('index'))
    plugin.notify('הפלייליסט הוסר מרשימת המועדפים')


if __name__ == '__main__':
    plugin.run()
    xbmcplugin.setContent(plugin.handle, 'audio')
