#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcplugin,xbmcgui,xbmc,xbmcaddon,sys,os,shutil

addon = xbmcaddon.Addon('plugin.program.thaifont')
profile = xbmc.translatePath(addon.getAddonInfo('profile'))
icon = xbmc.translatePath("special://home/addons/plugin.program.thaifont/icon.png")
fromFile = xbmc.translatePath("special://home/addons/plugin.program.thaifont/arial.ttf")
toFile = xbmc.translatePath("special://home/media/fonts/arial.ttf")
directory = xbmc.translatePath("special://home/media/fonts")

try:
    if not os.path.exists(directory):
        os.makedirs(directory)
    shutil.copy2(fromFile,toFile)
    xbmc.executebuiltin('XBMC.Notification(Thai Font OK: , die Schriftart wurde korrekt kopiert,8000,'+icon+')')

except:
    xbmc.executebuiltin('XBMC.Notification(Thai Font Error: , ein Fehler ist aufgetreten - evtl. sind keine Zugriffsrechte vorhanden,8000)')

