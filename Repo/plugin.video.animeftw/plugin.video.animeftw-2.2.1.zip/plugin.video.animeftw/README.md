# plugin.video.animeftw
Official AnimeFTW.tv KODI addon

You must have an AnimeFTW.tv account to view videos, to view more than the first two, you will need an Advanced Member account.
