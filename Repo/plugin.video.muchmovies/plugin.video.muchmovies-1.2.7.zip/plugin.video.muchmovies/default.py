import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import datetime
import time

PLUGIN='plugin.video.muchmovies'

ADDON = xbmcaddon.Addon(id=PLUGIN)
BaseUrl='http://www.buzzfilms.co'
icon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.muchmovies', 'icon.png'))
library=xbmc.translatePath(ADDON.getAddonInfo('profile'))
from metahandler import metahandlers
 
from metahandler import metacontainers 
grab = metahandlers.MetaData()


 
def CATEGORIES():
        link = OPEN_URL(BaseUrl+'/movies').replace('\n','')
        match = re.compile('<h3>(.+?)<span class="count">(.+?)</span></h3>').findall(link)
        for name,total in match: 
            addDir(name+'[COLOR yellow]%s[/COLOR]'%total,'/movies',1,icon,'')
        addDir('Genre','/genres',3,icon,'')
        addDir('Search','/search',4,icon,'')
        addDir('Go To Page Number','/movies',1,icon,'')
        setView('movies', 'default') 
        

def getSession():
        from t0mm0.common.net import Net

        net = Net()
        #just to get a cookie
        
        OPEN_URL(BaseUrl+'/contact', net) 
        
        if ADDON.getSetting('sort_by')=='Release Date':
            data = {'sort_by':'release'}
            
        elif ADDON.getSetting('sort_by')=='Date Added':
            data = {'sort_by':'date_added'}
            
        elif ADDON.getSetting('sort_by')=='Alphabetical':
            data = {'sort_by':'title'}
            
        elif ADDON.getSetting('sort_by')=='Ratings':
            data = {'sort_by':'rating'}
        #these can be date_added year title rating
        #you need to add these options to the Settings 
        net.http_POST(BaseUrl + '/session/sort', data)

        return net
       
                                                                      
def Main(name,url):
        session = getSession()
        addDir('[COLOR red]<< Main Menu[/COLOR]','url',5,'','')
        if 'Go To Page' in name:
            for_url=[]
            page=[]
            link = OPEN_URL(BaseUrl+url, session).replace('\n','')
            link = link.split('Go to...')[2]
            match = re.compile('<option value="(.+?)".+?>(.+?)</option>').findall(link)
            for _url,name in match:
                for_url.append(_url)
                page.append(name)
            dialog=xbmcgui.Dialog()
            page_url=for_url[xbmcgui.Dialog().select('Please Select Page', page)]
            link = OPEN_URL(BaseUrl+page_url, session).replace('\n','')
            #print link
            links=link.split('data-icon="false"')
            for p in links:
                try:
                    url = re.compile('href="(.+?)">').findall(p)[0]
                    iconimage = re.compile('src="(.+?)"').findall(p)[0]
                    name = re.compile('<h2>(.+?)</h2>').findall(p)[0]
                    addDir(name,url,2,iconimage,'')
                except:pass
            try:
                next = link.split('<a href=')
                for p in next:
                    if '>Next<' in p:
                        nextpage = re.compile('"(.+?)"').findall(p)
                        addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'','')
                        break
            except:
                pass
            setView('movies', 'default') 
        else:
            #print url
            link = OPEN_URL(BaseUrl+url, session).replace('\n','')
            #print link
            links=link.split('data-icon="false"')
            for p in links:
                try:
                    url = re.compile('href="(.+?)">').findall(p)[0]
                    iconimage = re.compile('src="(.+?)"').findall(p)[0]
                    name = re.compile('<h2>(.+?)</h2>').findall(p)[0]
                    addDir(name,url,2,iconimage,'')
                except:pass
            try:
                next = link.split('<a href=')
                for p in next:
                    if '>Next<' in p:
                        nextpage = re.compile('"(.+?)"').findall(p)
                        addDir('[COLOR blue]Next Page >>[/COLOR]',nextpage[0],1,'','')
                        break
            except:
                pass
            setView('movies', 'movie') 
            
def LIBRARY_MOVIE(name,url,iconimage):#  cause mode is empty in this one it will go back to first directory
    strm='%s?mode=2001&url=%s&iconimage=%s&name=%s&'% (sys.argv[0],urllib.quote_plus(url), iconimage,name)
    foldername=os.path.join(library, 'Movies')
    if os.path.exists(foldername)==False:
        os.mkdir(os.path.join(library, 'Movies'))

    filename = str(name) + '.strm'
    filename = cleanFilename(filename)
    file     = os.path.join(foldername,filename)

    a = open(file, "w")
    a.write(strm)
    a.close()
    
def cleanFilename(filename):
    return re.sub('[:\\/*?\<>|"]+', '', filename)
    
    
def PLAY_LIBRARY_STREAM(name, url, iconimage):
        link = OPEN_URL(BaseUrl+url).replace('\n','')
        link=link.split('<a href')
        for p in link:
            if '.mp4' in p:
                match = re.compile('="(.+?)"').findall(p)[0]
                liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name} )
                liz.setProperty("IsPlayable","true")
                liz.setPath(match[0])
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    
            
        
def Genres(url):
        link = OPEN_URL(BaseUrl+url).replace('\n','')
        match = re.compile('<img src="(.+?)".+?<h2>(.+?)</h2>.+?<li><a href="(.+?)">').findall(link)
        for iconimage,name,url in match: 
            addDir(name,url,1,BaseUrl+iconimage,'')
        setView('movies', 'default') 
        
def Get_META_Trailer(name,url,iconimage):
        youtube='plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s'%name
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        liz.setProperty("IsPlayable","true")
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        pl.add(youtube, liz)
        xbmc.Player().play(pl)
        
        
def GetTrailer(name,url,iconimage):
        try:
            link = OPEN__TRAILER_URL(BaseUrl+url)
            match = re.compile('"http://www.youtube.com/embed/(.+?)"').findall(link)
            youtube='plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s'%match[0]
            liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name} )
            liz.setProperty("IsPlayable","true")
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            pl.add(youtube, liz)
            xbmc.Player().play(pl)
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok("Much Movies", "Sorry But The Trailer", "Cannot Be Played In Your Country")
        
        
def OPEN__TRAILER_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
        
        
def Search(url):
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search MuchMovies...XUNITYTALK.COM')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() .replace(' ','-')  # sometimes you need to replace spaces with + or %20#
            if search_entered == None:
                return False
        link = OPEN_URL(BaseUrl+url+'/'+search_entered).replace('\n','')
        links=link.split('data-icon="false"')
        for p in links:
            try:
                url = re.compile('href="(.+?)">').findall(p)[0]
                iconimage = re.compile('src="(.+?)"').findall(p)[0]
                name = re.compile('<h2>(.+?)</h2>').findall(p)[0]
                addDir(name,url,2,iconimage,'')
            except:pass
        setView('movies', 'default') 
        
        


        
        
def GetLinks(name,url,iconimage,infoLabels=None):
        link = OPEN_URL(BaseUrl+url).replace('\n','')
        link=link.split('<a href')
        for p in link:
            if '.mp4' in p:
                match = re.compile('="(.+?)"').findall(p)[0]
                #infoLabels=GRABMETA(name,'movie',year=None) <li><a href="(.+?)">Stream</a>
                liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels=infoLabels )
                liz.setProperty("IsPlayable","true")
                pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                pl.clear()
                pl.add(match, liz)
                xbmc.Player().play(pl)


def SearchTC(url,name):
        search_entered = name.replace(' ','-')  # sometimes you need to replace spaces with + or %20#
        link = OPEN_URL(BaseUrl+url+'/'+search_entered).replace('\n','')
        match = re.compile('data-icon="false"><a href="(.+?)"><img src="(.+?)"/><h2>(.+?)</h2>').findall(link)
        for url,iconimage,name in match:
            addDir(name,url,2,iconimage,'')
        setView('movies', 'default')   
        
 
def OPEN_URL(url, net = None):
    if net:
        net.set_user_agent('Apple-iPhone/')
        link = net.http_GET(url).content
        return link

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Apple-iPhone/')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
    
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
        
def GRABMETA(name,year=None):
        year=name.split('(')[1]
        year=year.split(')')[0]
        name=name.split(' (')[0]
        meta = grab.get_meta('movie',name,'',None,year,overlay=6)
        infoLabels = {'rating': meta['rating'],'trailer_url': meta['trailer_url'],'duration': meta['duration'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'writer': meta['writer'],'cover_url': meta['cover_url'],'director': meta['director'],'cast': meta['cast'],'fanart': meta['backdrop_url'],'tmdb_id': meta['tmdb_id'],'year': meta['year']}
        return infoLabels    

def addDir(name,url,mode,iconimage,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        menu=[]
        if (mode == 2) or (mode==6):
            menu.append(('[COLOR yellow]Add To Library[/COLOR]','XBMC.RunPlugin(%s?mode=2000&url=%s&iconimage=%s&name=%s)'% (sys.argv[0],urllib.quote_plus(url),iconimage,name)))
            _name=name.split('(')[0]
            liz=xbmcgui.ListItem(_name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            if ADDON.getSetting('meta')=='true':
                infoLabels=GRABMETA(name,year=None) 
                liz.setInfo( type="Video", infoLabels=infoLabels)
                trailer=infoLabels['trailer_url'].replace('http://www.youtube.com/watch?v=','')
                menu.append(('[COLOR yellow]Play Trailer[/COLOR]','XBMC.RunPlugin(%s?mode=6&url=%s&iconimage=%s&name=%s)'% (sys.argv[0],url,iconimage,trailer)))
                if ADDON.getSetting('fanart')=='true':
                    liz.setProperty( "Fanart_Image", infoLabels['fanart'] )
            else:
                liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
                menu.append(('[COLOR yellow]Play Trailer[/COLOR]','XBMC.RunPlugin(%s?mode=600&url=%s&iconimage=%s&name=%s)'% (sys.argv[0],url,iconimage,name)))
            liz.addContextMenuItems(items=menu, replaceItems=False)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
        
def addLink(name,url,iconimage,description):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels=infoLabels)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok 
 
        
def setView(content, viewType):
        # set content type so library shows more views and info
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
meta_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
 
        meta_name=urllib.unquote_plus(params["meta_name"])
 
except:
 
        pass 

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        Main(name,url)
        
elif mode==2:
        GetLinks(name,url,iconimage,infoLabels=None)
        
elif mode==3:
        Genres(url)
        
elif mode==4:
        Search(url)
        
elif mode==5:
        xbmc.executebuiltin('XBMC.Container.Update(%s?name=None&mode=None&url=None&iconimage=None,replace)'% (sys.argv[0]))
        
elif mode==6:
        Get_META_Trailer(name,url,iconimage)

elif mode==7:
        SearchTC(url,name)        
        
elif mode==600:
        GetTrailer(name,url,iconimage)
        
        
        
        
elif mode==2000:
        LIBRARY_MOVIE(name,url,iconimage)
        
elif mode==2001:
        PLAY_LIBRARY_STREAM(name,url,iconimage)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
